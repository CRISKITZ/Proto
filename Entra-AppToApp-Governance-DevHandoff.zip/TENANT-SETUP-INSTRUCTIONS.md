# Target Tenant Setup & Configuration Guide

There are **zero hardcoded tenant IDs, app GUIDs, or credentials** in this package. Use the table below to see **exactly which files to update (or create)** vs. which files should **not** be edited.

---

## Quick File-by-File Summary (What to Edit vs. Do Not Touch)

| File / Input | Action Needed for Another Tenant | Exact Line / Field to Update |
|---|---|---|
| **Environment Variables** *(Shell / CI)* | **Required for unattended SP auth** *(or leave unset for interactive Device Code login)* | Set `AZURE_TENANT_ID`, `AZURE_CLIENT_ID`, `AZURE_CLIENT_SECRET` |
| `terraform-bridge\qual.tfvars.example` *(copy to `terraform.tfvars`)* | **Pre-populated with QUAL Consumer IDs** *(add Producer SP Object ID once created)* | Fill in `producer_sp_object_id` & `requested_permissions` |
| `terraform-bridge\main.tf` | **Linux CI runners only** *(skip on Windows)* | Line 43: change `"powershell.exe"` -> `"pwsh"` |
| `state\dev-fixtures.json` *(auto-generated)* | **Auto-created by `01-Setup-DevEntra.ps1`** *(create manually ONLY if targeting pre-existing apps)* | `tenantId` + each app's `AppObjectId`, `AppId`, `ServicePrincipalId` |
| `01-Setup-DevEntra.ps1` | **Optional** *(only if you want custom test app Display Names)* | Lines 85–90 *(or keep untouched and pass `-Prefix "YourPrefix"`)* |
| `config\consumer-service.json`<br>`config\consumer-webapp.json`<br>`config\consumer-obo.json`<br>`config\consumer-spa.json`<br>`config\consumer-spa-demo.json` | **Optional** *(only if replacing sample `APP12301`–`APP12800` Unity identities)* | Line 3: `"consumerIdentity"` |
| `config\producer-managed.json` | **Optional** *(only if replacing sample `APP12301`–`APP12700` rules)* | Lines 10–30: `DefaultAppRole`, `AllowAppRole`, `DenyAppRole`, `DefaultScope`, `AllowScope`, `DenyScope` |
| `04-Run-LiveE2ETests.ps1` | **Optional** *(only if replacing sample `APP12301` / `APP12540` identities)* | Line 157 (`DenyScope`) & lines 172–173 (`AllowAppRole`/`DenyAppRole` revocation tests) |
| `00-Create-Schema-For-QA-PROD.ps1` | **Do NOT edit** | Pass `-UnityDeploySpObjectId` & `-EnterpriseSecurityPrincipalId` via CLI parameters |
| `02-Sync-ProducerRules.ps1`<br>`03-Invoke-ConsumerDeploy.ps1`<br>`05-Test-DelegatedScopeToken.ps1`<br>`06-Run-Demo.ps1` | **Do NOT edit** | Read tenant & app IDs dynamically from `state\dev-fixtures.json` |
| `modules\AppToAppGovernance.psm1`<br>`modules\EntraGraphClient.psm1`<br>`terraform-bridge\Evaluate-PolicyForTerraform.ps1`<br>`tests\Invoke-UnitTests.ps1` | **Do NOT edit** | Tenant-agnostic core engine, Graph client (global built-in role IDs only), and 40 offline unit tests |

---

## 1. Authentication (QUAL Tenant Credentials)

Configure target tenant credentials via **environment variables** (never hardcode client secrets in scripts or Git):

```powershell
# QUAL (stage) Tenant — Unity-Deploy-NP-App-Creation-APP02861
$env:AZURE_TENANT_ID     = "7931dc71-6c50-47d0-963e-b2efbc8b1a37"
$env:AZURE_CLIENT_ID     = "0767b0b1-ad21-4ab4-a08d-0cf247299b44"
$env:AZURE_CLIENT_SECRET = "<UNITY-DEPLOY-SP-CLIENT-SECRET-FROM-VAULT>"
```

- When these 3 variables are set, `EntraGraphClient.psm1` automatically uses unattended **OAuth 2.0 Client Credentials** against `$env:AZURE_TENANT_ID`.
- If running interactively in a DEV or sandbox tenant without a Service Principal, leave these variables unset — the scripts will prompt for interactive **OAuth 2.0 Device Code** login to whichever tenant you sign into.
- **Switching tenants interactively:** Delete `state\.token-cache.dat` and `state\dev-fixtures.json` before signing into a different tenant.

### Required Permissions on `Unity-Deploy-NP-App-Creation-APP02861` (QUAL Audit Status)
- **Entra ID Directory Role (To Assign via `00-Create-Schema-For-QA-PROD.ps1`):** `Attribute Assignment Administrator` (`58a13ea3-c632-46ae-9ee0-9c0d43cd7f3d`) scoped strictly to `/attributeSets/AppToAppAccess` on SP Object ID `cf0d72e1-4300-47a7-bd0e-1bb24000f5c6` *(do **not** assign `Attribute Definition Administrator` to the automation SP)*.
- **Microsoft Graph Application Permissions (Admin Consented):**
  - `CustomSecAttributeAssignment.ReadWrite.All` *(Verified Granted in QUAL)*
  - `Application.ReadWrite.All` *(Verified Granted in QUAL)*
  - `Directory.Read.All` *(Verified Granted in QUAL)*
  - `AppRoleAssignment.ReadWrite.All` *(ADD & Grant Admin Consent in QUAL — required for App Roles)*
  - `DelegatedPermissionGrant.ReadWrite.All` *(ADD & Grant Admin Consent in QUAL — required for API Scopes)*

---

## 2. What to Update Based on Your Use Case

### Option A: Terraform Integration (`terraform-bridge\main.tf`)
Copy `terraform-bridge\qual.tfvars.example` to `terraform.tfvars` (or pass Unity Deploy CI/CD pipeline variables). The QUAL sample consumer `identity-clientcredentials-stage-APP12540` is already pre-filled — just plug in `producer_sp_object_id` once the QUAL Producer app is created:

```hcl
consumer_identity     = "APP12540_identity_clientcredentials" # RFC format: APPID_project_component
consumer_app_type     = "Service"                             # Service | WebApp | MiddleTierApi | SPA
consumer_sp_object_id = "ebb7d280-640d-47a4-b838-a11df88ad1a0"
producer_sp_object_id = "<QUAL-PRODUCER-SP-OBJECT-ID>"        # Pending creation in QUAL
requested_permissions = ["documents.read"]
```

- **Linux CI/CD runners only:** On line 43 of `terraform-bridge\main.tf`, change `"powershell.exe"` to `"pwsh"` (if running on a Linux PowerShell 7 container), or swap in a Python/Go executable implementing the stdin/stdout JSON contract documented in `Terraform-Dev-Handoff.pdf`.

---

### Option B: Full Automated POC in a Fresh DEV / Sandbox Tenant (`01`–`06`)
**No file edits are required.** Run:

```powershell
# 1. Verify offline policy engine (40 unit tests, no Entra calls)
.\tests\Invoke-UnitTests.ps1

# 2. Create AppToAppAccess schema (DefaultAppRole/AllowAppRole/DenyAppRole/DefaultScope/AllowScope/DenyScope)
#    + 6 test apps & auto-generate state\dev-fixtures.json
.\01-Setup-DevEntra.ps1

# 3. Run full end-to-end live Entra ID test suite (40 unit tests + 21 live E2E checks)
.\06-Run-Demo.ps1

# Optional: Live delegated user token (scp claim) check
.\05-Test-DelegatedScopeToken.ps1 -ConsumerKey spaConsumer

# Cleanup test apps when finished (leaves permanent AppToAppAccess schema intact)
.\01-Setup-DevEntra.ps1 -Cleanup
```

- **Optional Display Name prefix:** Run `.\01-Setup-DevEntra.ps1 -Prefix "YourPrefix"` to customize the test app Display Name prefix without editing any files.

---

### Option C: Pointing `02`–`06` at Existing Manually Created Apps
If you create the Producer and Consumer apps manually in your target tenant instead of running `01-Setup-DevEntra.ps1`:

1. Create `state\dev-fixtures.json` with your target tenant's `tenantId` and each app's 3 Entra GUIDs (`AppObjectId`, `AppId`, `ServicePrincipalId`):

```json
{
  "tenantId": "<TARGET-TENANT-ID>",
  "adminAccount": "<ADMIN-UPN-OR-SP>",
  "createdUtc": "2026-01-01T00:00:00Z",
  "publishStrategyUsed": "MirroredExact",
  "scopeSuffix": "",
  "apps": {
    "managedProducer": { "DisplayName": "<Name>", "Kind": "Producer",       "AppObjectId": "<GUID>", "AppId": "<GUID>", "ServicePrincipalId": "<GUID>" },
    "legacyProducer":  { "DisplayName": "<Name>", "Kind": "LegacyProducer", "AppObjectId": "<GUID>", "AppId": "<GUID>", "ServicePrincipalId": "<GUID>" },
    "serviceConsumer": { "DisplayName": "<Name>", "Kind": "Service",        "AppObjectId": "<GUID>", "AppId": "<GUID>", "ServicePrincipalId": "<GUID>" },
    "webAppConsumer":  { "DisplayName": "<Name>", "Kind": "WebApp",         "AppObjectId": "<GUID>", "AppId": "<GUID>", "ServicePrincipalId": "<GUID>" },
    "oboConsumer":     { "DisplayName": "<Name>", "Kind": "MiddleTierApi",  "AppObjectId": "<GUID>", "AppId": "<GUID>", "ServicePrincipalId": "<GUID>" },
    "spaConsumer":     { "DisplayName": "<Name>", "Kind": "SPA",            "AppObjectId": "<GUID>", "AppId": "<GUID>", "ServicePrincipalId": "<GUID>" }
  }
}
```

2. *(Only if changing the sample `APP12301`–`APP12700` Unity consumer identities)* Update:
   - `"consumerIdentity"` in `config\consumer-service.json`, `config\consumer-webapp.json`, `config\consumer-obo.json`, and `config\consumer-spa.json`
   - Matching rule strings in `config\producer-managed.json` *(or use RFC-compliant `*:documents.*` / `<APPID>_*:documents.*` rules — partial `APP*` wildcards are rejected per ES naming standard)*
   - Hardcoded revocation test identities in `04-Run-LiveE2ETests.ps1` (lines 157 and 172–173)

> **Note on Naming & ES Wildcard Standard:** Entra ID Display Names (e.g. `MyApp-PROD-APP02830`) are independent of the RFC rule identity (`APPID_project_component`, e.g. `APP12540_portal_client-web`). Scripts target Entra apps by GUID, while the policy engine validates exact `consumerIdentity` against `^APP[0-9]{4,6}_[a-z0-9][a-z0-9\-]*_[a-z0-9][a-z0-9\-]*$` and requires any consumer wildcard to be **`*` alone** or start with a **complete `AppID` + `_`** (e.g. `APP12301_*`).

---

### Option D: One-Time Schema & Scoped RBAC Rollout in QUAL / PROD (Entra ID Admin Only)
**No file edits are required.** Run with `-WhatIf` first for peer review (QUAL SP Object ID for `Unity-Deploy-NP-App-Creation-APP02861` is pre-filled below):

```powershell
# Safe dry-run preview in QUAL (Tenant: 7931dc71-6c50-47d0-963e-b2efbc8b1a37)
.\00-Create-Schema-For-QA-PROD.ps1 `
    -UnityDeploySpObjectId "cf0d72e1-4300-47a7-bd0e-1bb24000f5c6" `
    -EnterpriseSecurityPrincipalId "<QUAL-ENTSEC-GROUP-OBJECT-ID>" `
    -WhatIf

# Live rollout in QUAL (remove -WhatIf once approved)
.\00-Create-Schema-For-QA-PROD.ps1 `
    -UnityDeploySpObjectId "cf0d72e1-4300-47a7-bd0e-1bb24000f5c6" `
    -EnterpriseSecurityPrincipalId "<QUAL-ENTSEC-GROUP-OBJECT-ID>"
```

---

## 3. Additional Documentation
See **`Terraform-Dev-Handoff.pdf`** in this package for full architecture details, Graph v1.0 payloads (`$select` / `@odata.type` gotchas), mirrored role/scope verification notes, and the QA sign-off checklist.
