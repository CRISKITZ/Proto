#Requires -Version 5.1
<#
.SYNOPSIS
    Live Delegated User Token (scp claim) verification for the QA POC.
.DESCRIPTION
    Proves the runtime delegated-scope flow (Steps A-D in RFC Phase 1) in pure PowerShell:
      1. Temporarily enables public client (device code) on the DEV WebApp or SPA test consumer
         so PowerShell can request a real delegated user access token for the Managed Producer API.
      2. Acquires a real Entra ID v2.0 delegated access token for 'api://<ProducerAppId>/documents.read'.
         Because tenant-wide admin consent (AllPrincipals) was already granted by the prototype,
         NO user consent prompt is shown at sign-in.
      3. Decodes the JWT and verifies:
           - 'scp' claim contains 'documents.read' (checked by splitting space-delimited tokens,
             NOT substring matching, per RFC guidance!)
           - 'azp' matches the Consumer AppId
           - 'oid' identifies the signed-in user
           - 'documents.admin' is ABSENT from the SPA token (blocked by SPA-NoAdmin policy)
      4. Restores isFallbackPublicClient to $false after testing.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [ValidateSet('spaConsumer', 'webAppConsumer')]
    [string]$ConsumerKey = 'spaConsumer'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
Import-Module (Join-Path $root 'modules\EntraGraphClient.psm1') -Force

$fixturePath = Join-Path $root 'state\dev-fixtures.json'
if (-not (Test-Path $fixturePath)) {
    throw "Fixture file not found at $fixturePath. Run 01-Setup-DevEntra.ps1 and 04-Run-LiveE2ETests.ps1 first."
}

$fixtures = Get-Content -Raw -Encoding UTF8 $fixturePath | ConvertFrom-Json
$consumer = $fixtures.apps.$ConsumerKey
$producer = $fixtures.apps.managedProducer
$tenantId = $fixtures.tenantId
$suffix   = [string]$fixtures.scopeSuffix

Connect-GovernanceGraph | Out-Null

Write-Host "=== Live Delegated User Token (scp Claim) Verification ===" -ForegroundColor Cyan
Write-Host "Consumer : $($consumer.DisplayName) (AppId=$($consumer.AppId))"
Write-Host "Producer : $($producer.DisplayName) (AppId=$($producer.AppId))"
Write-Host "Target   : api://$($producer.AppId)/documents.read$suffix`n"

# Enable public client temporarily so PowerShell can run Device Code against this DEV test app
Write-Host '[1/4] Enabling temporary Device Code capability on DEV consumer app...' -ForegroundColor Yellow
Invoke-Graph -Method PATCH -Uri "https://graph.microsoft.com/v1.0/applications/$($consumer.AppObjectId)" -Body @{
    isFallbackPublicClient = $true
} | Out-Null
Start-Sleep -Seconds 3

try {
    $requestedScope = "api://$($producer.AppId)/documents.read$suffix"
    Write-Host "[2/4] Requesting delegated user token for scope '$requestedScope'..." -ForegroundColor Yellow
    Write-Host '      (Notice: NO consent screen should appear because AllPrincipals admin consent is already in place!)' -ForegroundColor Gray

    $dcResp = Invoke-RestMethod -Method POST `
        -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/devicecode" `
        -Body @{
            client_id = $consumer.AppId
            scope     = $requestedScope
        } -ContentType 'application/x-www-form-urlencoded'

    [Console]::Out.WriteLine('')
    [Console]::Out.WriteLine($dcResp.message)
    [Console]::Out.WriteLine('')
    [Console]::Out.Flush()

    $interval = if ($dcResp.interval) { [int]$dcResp.interval } else { 5 }
    $deadline = (Get-Date).AddSeconds([int]$dcResp.expires_in)
    $tokenResp = $null

    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds $interval
        try {
            $tokenResp = Invoke-RestMethod -Method POST `
                -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
                -Body @{
                    grant_type  = 'urn:ietf:params:oauth:grant-type:device_code'
                    client_id   = $consumer.AppId
                    device_code = $dcResp.device_code
                } -ContentType 'application/x-www-form-urlencoded'
            break
        } catch {
            $errBody = if ($null -ne $_.ErrorDetails) { $_.ErrorDetails.Message } else { $_.Exception.Message }
            if ($errBody -match 'authorization_pending') { continue }
            elseif ($errBody -match 'slow_down') { $interval += 5; continue }
            else { throw "Token request failed: $errBody" }
        }
    }

    if ($null -eq $tokenResp) { throw 'Timed out waiting for delegated sign-in.' }

    # Decode JWT payload
    $payloadB64 = $tokenResp.access_token.Split('.')[1].Replace('-', '+').Replace('_', '/')
    switch ($payloadB64.Length % 4) { 2 { $payloadB64 += '==' } 3 { $payloadB64 += '=' } }
    $claims = ([System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($payloadB64)) | ConvertFrom-Json)

    Write-Host "`n[3/4] Decoded Live Delegated Access Token Claims:" -ForegroundColor Cyan
    $scpRaw = if ($claims.PSObject.Properties['scp']) { [string]$claims.scp } else { '' }
    $scpList = @($scpRaw.Trim() -split '\s+' | Where-Object { $_ -ne '' }) # RFC: ALWAYS split & exact match, never substring!
    $azp = if ($claims.PSObject.Properties['azp']) { [string]$claims.azp } else { '' }
    $oid = if ($claims.PSObject.Properties['oid']) { [string]$claims.oid } else { '' }
    $upn = if ($claims.PSObject.Properties['upn']) { [string]$claims.upn } elseif ($claims.PSObject.Properties['preferred_username']) { [string]$claims.preferred_username } else { '' }

    Write-Host "  aud (Producer API) : $($claims.aud)"
    Write-Host "  azp (Consumer App) : $azp"
    Write-Host "  oid (Signed-in Id) : $oid"
    Write-Host "  user               : $upn"
    Write-Host "  scp (raw string)   : '$scpRaw'"
    Write-Host "  scp (exact split)  : [$($scpList -join ', ')]"

    $expectedScope = "documents.read$suffix"
    $hasRead  = ($scpList -contains $expectedScope)
    $hasAdmin = ($scpList -contains "documents.admin$suffix")

    if ($hasRead) {
        Write-Host "`n  [PASS] Exact-split scp check confirms '$expectedScope' is present!" -ForegroundColor Green
    } else {
        Write-Host "`n  [FAIL] Expected '$expectedScope' in scp claim!" -ForegroundColor Red
    }

    if ($ConsumerKey -eq 'spaConsumer') {
        if (-not $hasAdmin) {
            Write-Host "  [PASS] SPA token does NOT contain 'documents.admin$suffix' (enforced by Policy:SPA-NoAdmin)." -ForegroundColor Green
        } else {
            Write-Host "  [FAIL] SPA token unexpectedly contained 'documents.admin$suffix'!" -ForegroundColor Red
        }
    }

    Write-Host "`n  [RFC Reminder] Producer API must STILL validate the signed-in user ($upn / oid=$oid)" -ForegroundColor DarkGray
    Write-Host "                 against its own user entitlements after validating scp." -ForegroundColor DarkGray
} finally {
    Write-Host "`n[4/4] Restoring isFallbackPublicClient=false on $($consumer.DisplayName)..." -ForegroundColor Yellow
    Invoke-Graph -Method PATCH -Uri "https://graph.microsoft.com/v1.0/applications/$($consumer.AppObjectId)" -Body @{
        isFallbackPublicClient = $false
    } | Out-Null
    Write-Host 'Done.' -ForegroundColor Green
}
