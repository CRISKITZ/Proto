#Requires -Version 5.1
<#
.SYNOPSIS
    Core policy engine, naming validator, and decision logic for
    "RFC - Governance of App to App permission granting in Entra ID (Phase 1)".
.DESCRIPTION
    Pure PowerShell module (no network calls) compatible with Windows PowerShell 5.1 and PowerShell 7+.
    Implements:
      - Naming convention & impact tiers (APPID_project_component:resource.verb)
      - Custom Security Attribute length (<=64) and budget (<=50) validation
      - Consumer APP_TYPE -> AppRole vs ApiScope derivation
      - Fixed 4-step decision order: Deny -> Admin (no SPA, exact Allow only) -> Allow -> Default / Legacy Allow
#>

Set-StrictMode -Version Latest

$script:AllowedVerbs = @('read', 'write', 'admin')
$script:MaxAttributeValueLength = 64
$script:MaxServicePrincipalAttributeValues = 50
$script:AttributeSetName = 'AppToAppAccess'

function Test-PermissionName {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$Permission
    )

    if ([string]::IsNullOrWhiteSpace($Permission)) {
        return [PSCustomObject]@{ IsValid = $false; Error = 'Permission name cannot be empty.'; Resource = $null; Verb = $null; Tier = $null }
    }

    # Format: resource.verb (e.g. documents.read, audit-reports.write, ledger.admin)
    if ($Permission -cnotmatch '^([a-z][a-z0-9\-]*)\.([a-z]+)$') {
        return [PSCustomObject]@{
            IsValid  = $false
            Error    = "Permission '$Permission' does not match required format 'resource.verb' (lowercase alphanumeric/hyphens)."
            Resource = $null
            Verb     = $null
            Tier     = $null
        }
    }

    $resource = $Matches[1]
    $verb = $Matches[2]

    if ($script:AllowedVerbs -notcontains $verb) {
        return [PSCustomObject]@{
            IsValid  = $false
            Error    = "Permission '$Permission' uses unsupported verb '$verb'. Allowed verbs: $($script:AllowedVerbs -join ', ')."
            Resource = $resource
            Verb     = $verb
            Tier     = $null
        }
    }

    $tier = switch ($verb) {
        'read'  { 'Read' }
        'write' { 'Write' }
        'admin' { 'Admin' }
    }

    return [PSCustomObject]@{
        IsValid  = $true
        Error    = $null
        Resource = $resource
        Verb     = $verb
        Tier     = $tier
    }
}

function Test-ConsumerIdentity {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$ConsumerIdentity
    )

    if ([string]::IsNullOrWhiteSpace($ConsumerIdentity)) {
        return [PSCustomObject]@{ IsValid = $false; Error = 'Consumer identity cannot be empty.' }
    }

    # Format: APPID_project_component (e.g. APP12540_portal_client-web)
    if ($ConsumerIdentity -cnotmatch '^APP[0-9]{4,6}_[a-z0-9][a-z0-9\-]*_[a-z0-9][a-z0-9\-]*$') {
        return [PSCustomObject]@{
            IsValid = $false
            Error   = "Consumer identity '$ConsumerIdentity' does not match 'APPID_project_component' (e.g. APP12540_portal_client-web)."
        }
    }

    return [PSCustomObject]@{ IsValid = $true; Error = $null }
}

function Test-GovernanceRule {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$Rule
    )

    if ([string]::IsNullOrWhiteSpace($Rule)) {
        return [PSCustomObject]@{ IsValid = $false; Error = 'Rule cannot be empty.'; HasWildcard = $false }
    }

    if ($Rule.Length -gt $script:MaxAttributeValueLength) {
        return [PSCustomObject]@{
            IsValid     = $false
            Error       = "Rule '$Rule' is $($Rule.Length) characters; Entra ID custom security attribute values cannot exceed $($script:MaxAttributeValueLength) characters."
            HasWildcard = $Rule.Contains('*')
        }
    }

    $colonCount = @($Rule.ToCharArray() | Where-Object { $_ -eq ':' }).Count
    if ($colonCount -ne 1) {
        return [PSCustomObject]@{
            IsValid     = $false
            Error       = "Rule '$Rule' must contain exactly one ':' separating consumer identity and producer permission (wildcards cannot span across ':')."
            HasWildcard = $Rule.Contains('*')
        }
    }

    $parts = $Rule.Split(':')
    $left = $parts[0]
    $right = $parts[1]

    if ([string]::IsNullOrWhiteSpace($left) -or [string]::IsNullOrWhiteSpace($right)) {
        return [PSCustomObject]@{
            IsValid     = $false
            Error       = "Rule '$Rule' has an empty consumer or permission segment."
            HasWildcard = $Rule.Contains('*')
        }
    }

    # Validate consumer half (left of ':'):
    # Per updated RFC / ES feedback: must be '*' alone, OR start with a complete AppID + '_' (e.g. APP12301_*),
    # OR be an exact APPID_project_component when no wildcard is present.
    if ($left -eq '*') {
        # Global consumer wildcard ('*') is explicitly allowed
    } elseif ($left.Contains('*')) {
        if ($left -cnotmatch '^APP[0-9]{4,6}_[a-z0-9_\-\*]+$') {
            return [PSCustomObject]@{
                IsValid     = $false
                Error       = "Rule '$Rule' has invalid consumer wildcard '$left'. Consumer half must be '*' alone or start with a complete AppID followed by '_' (e.g. 'APP12301_*')."
                HasWildcard = $true
            }
        }
    } else {
        $cCheck = Test-ConsumerIdentity -ConsumerIdentity $left
        if (-not $cCheck.IsValid) {
            return [PSCustomObject]@{ IsValid = $false; Error = $cCheck.Error; HasWildcard = $Rule.Contains('*') }
        }
    }

    if ($right -cnotmatch '^[a-z0-9\-\.\*]+$') {
        return [PSCustomObject]@{
            IsValid     = $false
            Error       = "Rule '$Rule' has invalid characters in permission segment '$right'."
            HasWildcard = $Rule.Contains('*')
        }
    }

    # If right side has no wildcard, enforce full permission syntax
    if (-not $right.Contains('*')) {
        $pCheck = Test-PermissionName -Permission $right
        if (-not $pCheck.IsValid) {
            return [PSCustomObject]@{ IsValid = $false; Error = $pCheck.Error; HasWildcard = $Rule.Contains('*') }
        }
    }

    return [PSCustomObject]@{
        IsValid          = $true
        Error            = $null
        ConsumerPattern  = $left
        PermissionPattern = $right
        HasWildcard      = $Rule.Contains('*')
    }
}

function Test-ProducerRuleConfig {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$Rules,

        [Parameter(Mandatory = $false)]
        [int]$ExistingOtherAttributeValueCount = 0
    )

    $errors = New-Object System.Collections.Generic.List[string]
    $valueCount = $ExistingOtherAttributeValueCount

    foreach ($legacyAttr in @('Default', 'Allow', 'Deny')) {
        if ($Rules.ContainsKey($legacyAttr)) {
            $errors.Add("Attribute '$legacyAttr' was renamed to '${legacyAttr}AppRole' per the updated RFC schema.")
        }
    }

    foreach ($singleAttr in @('DefaultAppRole', 'DefaultScope')) {
        if ($Rules.ContainsKey($singleAttr) -and -not [string]::IsNullOrWhiteSpace([string]$Rules[$singleAttr])) {
            $val = [string]$Rules[$singleAttr]
            if ($val -notin @('Allow', 'Deny')) {
                $errors.Add("Attribute '$singleAttr' must be 'Allow' or 'Deny' (got '$val').")
            }
            $valueCount++
        }
    }

    foreach ($listAttr in @('AllowAppRole', 'DenyAppRole', 'AllowScope', 'DenyScope')) {
        if ($Rules.ContainsKey($listAttr) -and $null -ne $Rules[$listAttr]) {
            foreach ($rule in @($Rules[$listAttr])) {
                $check = Test-GovernanceRule -Rule ([string]$rule)
                if (-not $check.IsValid) {
                    $errors.Add("[$listAttr] $($check.Error)")
                }
                $valueCount++
            }
        }
    }

    if ($valueCount -gt $script:MaxServicePrincipalAttributeValues) {
        $errors.Add("Total assigned custom security attribute values ($valueCount) exceeds Entra ID limit of $($script:MaxServicePrincipalAttributeValues) per service principal (including $ExistingOtherAttributeValueCount values from other attribute sets).")
    }

    return [PSCustomObject]@{
        IsValid         = ($errors.Count -eq 0)
        TotalValueCount = $valueCount
        RemainingBudget = ($script:MaxServicePrincipalAttributeValues - $valueCount)
        Errors          = @($errors)
    }
}

function Resolve-GrantType {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AppType
    )

    switch ($AppType.Trim().ToLowerInvariant()) {
        { $_ -in @('service', 'batch', 'daemon', 'clientcredentials', 'service_batch') } {
            return [PSCustomObject]@{
                AppType         = $AppType
                GrantType       = 'AppRole'
                Flow            = 'ClientCredentials'
                ActsAs          = 'Itself'
                DefaultAttr     = 'DefaultAppRole'
                AllowAttr       = 'AllowAppRole'
                DenyAttr        = 'DenyAppRole'
                IsSpa           = $false
                TokenClaim      = 'roles'
            }
        }
        { $_ -in @('webapp', 'web', 'serverweb', 'authcode') } {
            return [PSCustomObject]@{
                AppType         = $AppType
                GrantType       = 'ApiScope'
                Flow            = 'AuthorizationCode'
                ActsAs          = 'SignedInUser'
                DefaultAttr     = 'DefaultScope'
                AllowAttr       = 'AllowScope'
                DenyAttr        = 'DenyScope'
                IsSpa           = $false
                TokenClaim      = 'scp'
            }
        }
        { $_ -in @('middletierapi', 'obo', 'api', 'middle-tier') } {
            return [PSCustomObject]@{
                AppType         = $AppType
                GrantType       = 'ApiScope'
                Flow            = 'OnBehalfOf'
                ActsAs          = 'SignedInUser'
                DefaultAttr     = 'DefaultScope'
                AllowAttr       = 'AllowScope'
                DenyAttr        = 'DenyScope'
                IsSpa           = $false
                TokenClaim      = 'scp'
            }
        }
        { $_ -in @('spa', 'browser', 'singlepageapp', 'pkce') } {
            return [PSCustomObject]@{
                AppType         = $AppType
                GrantType       = 'ApiScope'
                Flow            = 'AuthorizationCodePKCE'
                ActsAs          = 'SignedInUser'
                DefaultAttr     = 'DefaultScope'
                AllowAttr       = 'AllowScope'
                DenyAttr        = 'DenyScope'
                IsSpa           = $true
                TokenClaim      = 'scp'
            }
        }
        default {
            throw "Unsupported consumer APP_TYPE '$AppType'. Expected one of: Service, WebApp, MiddleTierApi, SPA."
        }
    }
}

function ConvertTo-WildcardRegex {
    param([string]$Pattern)
    $escaped = [regex]::Escape($Pattern).Replace('\*', '.*')
    return "^$escaped$"
}

function Test-RuleMatch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Rule,

        [Parameter(Mandatory = $true)]
        [string]$ConsumerIdentity,

        [Parameter(Mandatory = $true)]
        [string]$Permission
    )

    $validation = Test-GovernanceRule -Rule $Rule
    if (-not $validation.IsValid) {
        return [PSCustomObject]@{ Matched = $false; IsExact = $false; InvalidRule = $true }
    }

    # Wildcards are evaluated separately on left and right of ':' so '*' never crosses ':'
    $leftRegex = ConvertTo-WildcardRegex -Pattern $validation.ConsumerPattern
    $rightRegex = ConvertTo-WildcardRegex -Pattern $validation.PermissionPattern

    $leftMatch = [regex]::IsMatch($ConsumerIdentity, $leftRegex, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    $rightMatch = [regex]::IsMatch($Permission, $rightRegex, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)

    $matched = $leftMatch -and $rightMatch
    $isExact = $matched -and (-not $validation.HasWildcard)

    return [PSCustomObject]@{
        Matched     = $matched
        IsExact     = $isExact
        InvalidRule = $false
    }
}

function Invoke-GovernanceDecision {
    <#
    .SYNOPSIS
        Evaluates a single consumer permission request against a producer's AppToAppAccess metadata.
    .DESCRIPTION
        Applies the RFC's fixed 4-step decision order:
          1. Deny rule matches -> DENY
          2. Admin tier -> SPA always DENY; otherwise exact non-wildcard Allow required
          3. Allow rule matches -> ALLOW
          4. Default rule -> Default Allow grants, Default Deny stops (missing metadata = Legacy Default Allow, excluding Admin)
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ConsumerIdentity,

        [Parameter(Mandatory = $true)]
        [string]$ConsumerAppType,

        [Parameter(Mandatory = $true)]
        [string]$ProducerDisplayName,

        [Parameter(Mandatory = $false)]
        [string]$ProducerAppId = '',

        [Parameter(Mandatory = $false)]
        [string]$ProducerOwnerContact = 'Producer Application Owner',

        [Parameter(Mandatory = $true)]
        [string]$Permission,

        [Parameter(Mandatory = $false)]
        [hashtable]$ProducerAttributes = $null
    )

    $timestamp = (Get-Date).ToUniversalTime().ToString('o')

    # Validate consumer identity & permission naming convention
    $consumerCheck = Test-ConsumerIdentity -ConsumerIdentity $ConsumerIdentity
    $permCheck = Test-PermissionName -Permission $Permission
    $grantInfo = Resolve-GrantType -AppType $ConsumerAppType

    if (-not $consumerCheck.IsValid) {
        return [PSCustomObject]@{
            ConsumerIdentity     = $ConsumerIdentity
            ConsumerAppType      = $ConsumerAppType
            ProducerDisplayName  = $ProducerDisplayName
            ProducerAppId        = $ProducerAppId
            Permission           = $Permission
            Tier                 = if ($permCheck.Tier) { $permCheck.Tier } else { 'Invalid' }
            GrantType            = $grantInfo.GrantType
            Decision             = 'DENY'
            DecidingStep         = '0-Validation'
            DecidingRule         = 'NamingConvention'
            Reason               = $consumerCheck.Error
            ContactGuidance      = 'Fix consumer identity naming (APPID_project_component) in your Unity project.'
            TimestampUtc         = $timestamp
        }
    }

    if (-not $permCheck.IsValid) {
        return [PSCustomObject]@{
            ConsumerIdentity     = $ConsumerIdentity
            ConsumerAppType      = $ConsumerAppType
            ProducerDisplayName  = $ProducerDisplayName
            ProducerAppId        = $ProducerAppId
            Permission           = $Permission
            Tier                 = 'Invalid'
            GrantType            = $grantInfo.GrantType
            Decision             = 'DENY'
            DecidingStep         = '0-Validation'
            DecidingRule         = 'NamingConvention'
            Reason               = $permCheck.Error
            ContactGuidance      = "Permission must follow 'resource.verb' (read, write, admin). Contact $ProducerOwnerContact."
            TimestampUtc         = $timestamp
        }
    }

    # Extract only the 3 attributes relevant to the derived GrantType (complete isolation between Role and Scope lists)
    $defaultAttrName = $grantInfo.DefaultAttr
    $allowAttrName = $grantInfo.AllowAttr
    $denyAttrName = $grantInfo.DenyAttr

    $denyRules = @()
    $allowRules = @()
    $defaultValue = $null
    $isLegacy = $false

    if ($null -eq $ProducerAttributes -or $ProducerAttributes.Count -eq 0) {
        $isLegacy = $true
    } else {
        if ($ProducerAttributes.ContainsKey($denyAttrName) -and $null -ne $ProducerAttributes[$denyAttrName]) {
            $denyRules = @($ProducerAttributes[$denyAttrName])
        }
        if ($ProducerAttributes.ContainsKey($allowAttrName) -and $null -ne $ProducerAttributes[$allowAttrName]) {
            $allowRules = @($ProducerAttributes[$allowAttrName])
        }
        if ($ProducerAttributes.ContainsKey($defaultAttrName) -and -not [string]::IsNullOrWhiteSpace([string]$ProducerAttributes[$defaultAttrName])) {
            $defaultValue = ([string]$ProducerAttributes[$defaultAttrName]).Trim()
        } else {
            # Missing or unreadable Default for this type -> Legacy fallback behavior
            $isLegacy = $true
        }
    }

    # STEP 1: Deny always prevails (overrides Allow, Default, and Legacy Default Allow)
    foreach ($rule in $denyRules) {
        $m = Test-RuleMatch -Rule ([string]$rule) -ConsumerIdentity $ConsumerIdentity -Permission $Permission
        if ($m.Matched) {
            return [PSCustomObject]@{
                ConsumerIdentity     = $ConsumerIdentity
                ConsumerAppType      = $ConsumerAppType
                ProducerDisplayName  = $ProducerDisplayName
                ProducerAppId        = $ProducerAppId
                Permission           = $Permission
                Tier                 = $permCheck.Tier
                GrantType            = $grantInfo.GrantType
                Decision             = 'DENY'
                DecidingStep         = '1-Deny'
                DecidingRule         = "$denyAttrName`:$rule"
                Reason               = "Blocked by producer $denyAttrName rule '$rule'."
                ContactGuidance      = "Contact $ProducerOwnerContact to discuss access exception."
                TimestampUtc         = $timestamp
            }
        }
    }

    # STEP 2: Admin tier guardrails
    if ($permCheck.Tier -eq 'Admin') {
        if ($grantInfo.IsSpa) {
            return [PSCustomObject]@{
                ConsumerIdentity     = $ConsumerIdentity
                ConsumerAppType      = $ConsumerAppType
                ProducerDisplayName  = $ProducerDisplayName
                ProducerAppId        = $ProducerAppId
                Permission           = $Permission
                Tier                 = 'Admin'
                GrantType            = $grantInfo.GrantType
                Decision             = 'DENY'
                DecidingStep         = '2-AdminSpaBlocked'
                DecidingRule         = 'Policy:SPA-NoAdmin'
                Reason               = 'Browser applications (SPA) can never receive Admin-tier permissions because tokens are exposed in the browser.'
                ContactGuidance      = 'Move privileged operations to a confidential server-side backend or middle-tier API.'
                TimestampUtc         = $timestamp
            }
        }

        foreach ($rule in $allowRules) {
            $m = Test-RuleMatch -Rule ([string]$rule) -ConsumerIdentity $ConsumerIdentity -Permission $Permission
            if ($m.Matched -and $m.IsExact) {
                return [PSCustomObject]@{
                    ConsumerIdentity     = $ConsumerIdentity
                    ConsumerAppType      = $ConsumerAppType
                    ProducerDisplayName  = $ProducerDisplayName
                    ProducerAppId        = $ProducerAppId
                    Permission           = $Permission
                    Tier                 = 'Admin'
                    GrantType            = $grantInfo.GrantType
                    Decision             = 'ALLOW'
                    DecidingStep         = '2-AdminExactAllow'
                    DecidingRule         = "$allowAttrName`:$rule"
                    Reason               = "Admin permission granted by exact (non-wildcard) $allowAttrName rule '$rule'."
                    ContactGuidance      = ''
                    TimestampUtc         = $timestamp
                }
            }
        }

        return [PSCustomObject]@{
            ConsumerIdentity     = $ConsumerIdentity
            ConsumerAppType      = $ConsumerAppType
            ProducerDisplayName  = $ProducerDisplayName
            ProducerAppId        = $ProducerAppId
            Permission           = $Permission
            Tier                 = 'Admin'
            GrantType            = $grantInfo.GrantType
            Decision             = 'DENY'
            DecidingStep         = '2-AdminRequiresExactAllow'
            DecidingRule         = "Policy:AdminRequiresExact$allowAttrName"
            Reason               = "Admin-tier permission '$Permission' requires an exact, non-wildcard rule '$ConsumerIdentity`:$Permission' in $allowAttrName. Wildcards and Default Allow never grant Admin."
            ContactGuidance      = "Request $ProducerOwnerContact to add exact rule '$ConsumerIdentity`:$Permission' to $allowAttrName."
            TimestampUtc         = $timestamp
        }
    }

    # STEP 3: Allow rule matches (exact or wildcard)
    foreach ($rule in $allowRules) {
        $m = Test-RuleMatch -Rule ([string]$rule) -ConsumerIdentity $ConsumerIdentity -Permission $Permission
        if ($m.Matched) {
            return [PSCustomObject]@{
                ConsumerIdentity     = $ConsumerIdentity
                ConsumerAppType      = $ConsumerAppType
                ProducerDisplayName  = $ProducerDisplayName
                ProducerAppId        = $ProducerAppId
                Permission           = $Permission
                Tier                 = $permCheck.Tier
                GrantType            = $grantInfo.GrantType
                Decision             = 'ALLOW'
                DecidingStep         = '3-Allow'
                DecidingRule         = "$allowAttrName`:$rule"
                Reason               = "Granted by producer $allowAttrName rule '$rule'."
                ContactGuidance      = ''
                TimestampUtc         = $timestamp
            }
        }
    }

    # STEP 4: Fallback to Default (or Legacy Default Allow when metadata is missing/unreadable)
    if ($isLegacy) {
        return [PSCustomObject]@{
            ConsumerIdentity     = $ConsumerIdentity
            ConsumerAppType      = $ConsumerAppType
            ProducerDisplayName  = $ProducerDisplayName
            ProducerAppId        = $ProducerAppId
            Permission           = $Permission
            Tier                 = $permCheck.Tier
            GrantType            = $grantInfo.GrantType
            Decision             = 'ALLOW'
            DecidingStep         = '4-LegacyDefaultAllow'
            DecidingRule         = "Legacy:$defaultAttrName=Allow (no metadata)"
            Reason               = "Legacy Entra application has no $defaultAttrName metadata; Phase 1 defaults to Allow (Admin excluded, valid Deny rules still enforced)."
            ContactGuidance      = ''
            TimestampUtc         = $timestamp
        }
    }

    if ($defaultValue -ieq 'Allow') {
        return [PSCustomObject]@{
            ConsumerIdentity     = $ConsumerIdentity
            ConsumerAppType      = $ConsumerAppType
            ProducerDisplayName  = $ProducerDisplayName
            ProducerAppId        = $ProducerAppId
            Permission           = $Permission
            Tier                 = $permCheck.Tier
            GrantType            = $grantInfo.GrantType
            Decision             = 'ALLOW'
            DecidingStep         = '4-DefaultAllow'
            DecidingRule         = "$defaultAttrName=Allow"
            Reason               = "No explicit rule matched; producer $defaultAttrName is Allow."
            ContactGuidance      = ''
            TimestampUtc         = $timestamp
        }
    }

    return [PSCustomObject]@{
        ConsumerIdentity     = $ConsumerIdentity
        ConsumerAppType      = $ConsumerAppType
        ProducerDisplayName  = $ProducerDisplayName
        ProducerAppId        = $ProducerAppId
        Permission           = $Permission
        Tier                 = $permCheck.Tier
        GrantType            = $grantInfo.GrantType
        Decision             = 'DENY'
        DecidingStep         = '4-DefaultDeny'
        DecidingRule         = "$defaultAttrName=$defaultValue"
        Reason               = "No explicit Allow rule matched and producer $defaultAttrName is '$defaultValue'."
        ContactGuidance      = "Contact $ProducerOwnerContact to add an $allowAttrName rule for '$ConsumerIdentity`:$Permission'."
        TimestampUtc         = $timestamp
    }
}

Export-ModuleMember -Function @(
    'Test-PermissionName',
    'Test-ConsumerIdentity',
    'Test-GovernanceRule',
    'Test-ProducerRuleConfig',
    'Resolve-GrantType',
    'Test-RuleMatch',
    'Invoke-GovernanceDecision'
)
