#Requires -Version 5.1
<#
.SYNOPSIS
    Peer-reviewable, one-time Entra ID Admin script for QA / PROD rollout.
.DESCRIPTION
    Per RFC ("Governance of App to App permission granting in Entra ID - Phase 1"):
      - Custom Security Attribute set & definitions are created ONCE by an Entra Attribute Definition Admin
        (NOT by Unity Deploy).
      - The 4 rule attributes (AllowAppRole, DenyAppRole, AllowScope, DenyScope) MUST be created with isCollection = true
        because Entra ID does not allow deleting definitions or changing isCollection afterward.
      - The 2 default posture attributes (DefaultAppRole, DefaultScope) MUST be created with usePreDefinedValuesOnly = true
        (allowed values: Allow, Deny) because Entra ID does not allow switching usePreDefinedValuesOnly from false to true afterward.
      - Optionally scopes 'Attribute Assignment Administrator' strictly to '/attributeSets/AppToAppAccess'
        for the Unity Deploy automation Service Principal (e.g. Unity-Deploy-NP-App-Creation-APP02861)
        and 'Attribute Assignment Reader' + 'Attribute Log Reader' for Enterprise Security.

.EXAMPLE
    # Dry-run preview in QUAL (makes NO changes in Entra ID):
    .\00-Create-Schema-For-QA-PROD.ps1 `
        -UnityDeploySpObjectId "cf0d72e1-4300-47a7-bd0e-1bb24000f5c6" `
        -EnterpriseSecurityPrincipalId "<QUAL-EntSec-Group-ObjectId>" `
        -WhatIf

    # Execute schema creation + least-privilege role scoping in QUAL (Tenant: 7931dc71-6c50-47d0-963e-b2efbc8b1a37):
    .\00-Create-Schema-For-QA-PROD.ps1 `
        -UnityDeploySpObjectId "cf0d72e1-4300-47a7-bd0e-1bb24000f5c6" `
        -EnterpriseSecurityPrincipalId "<QUAL-EntSec-Group-ObjectId>"
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [Parameter(Mandatory = $false)]
    [string]$AttributeSetName = 'AppToAppAccess',

    [Parameter(Mandatory = $false)]
    [string]$UnityDeploySpObjectId = '',

    [Parameter(Mandatory = $false)]
    [string]$EnterpriseSecurityPrincipalId = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
Import-Module (Join-Path $root 'modules\EntraGraphClient.psm1') -Force

# Built-in Entra ID Role Template IDs
$Role_AttrAssignAdmin  = '58a13ea3-c632-46ae-9ee0-9c0d43cd7f3d' # Attribute Assignment Administrator
$Role_AttrAssignReader = 'ffd52fa5-98dc-465c-991d-fc073eb59f8f' # Attribute Assignment Reader
$Role_AttrLogReader    = '9c99539d-8186-4804-835f-fd51ef9e2dcd' # Attribute Log Reader

$requiredDefs = Get-AppToAppAccessSchemaDefinition

$ctx = Connect-GovernanceGraph
Write-Host "=== Entra ID Schema & Scoped RBAC Setup ===" -ForegroundColor Cyan
Write-Host "Tenant : $($ctx.TenantId)"
Write-Host "Actor  : $($ctx.Account)"
Write-Host "Set    : $AttributeSetName"
Write-Host "Scope  : /attributeSets/$AttributeSetName`n"

# 1. Verify / Create Attribute Set
$sets = Invoke-Graph -Method GET -Uri 'https://graph.microsoft.com/v1.0/directory/attributeSets'
$setExists = ($sets.ContainsKey('value') -and @($sets['value'] | Where-Object { $_['id'] -eq $AttributeSetName }).Count -gt 0)

if ($setExists) {
    Write-Host "  [OK] Attribute Set '$AttributeSetName' already exists." -ForegroundColor Green
} elseif ($PSCmdlet.ShouldProcess("Attribute Set '$AttributeSetName'", 'Create in Entra ID')) {
    Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/directory/attributeSets' -Body @{
        id                  = $AttributeSetName
        description         = 'Producer-governed App-to-App permission rules (RFC Phase 1)'
        maxAttributesPerSet = 6
    } | Out-Null
    Write-Host "  [CREATED] Attribute Set '$AttributeSetName'." -ForegroundColor Green
}

# 2. Verify / Create Six Attribute Definitions
$defs = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/directory/customSecurityAttributeDefinitions?`$filter=attributeSet eq '$AttributeSetName'"
$existingDefs = @{}
if ($defs.ContainsKey('value') -and $null -ne $defs['value']) {
    foreach ($d in @($defs['value'])) { $existingDefs[$d['name']] = $d }
}

foreach ($rd in $requiredDefs) {
    if ($existingDefs.ContainsKey($rd.name)) {
        $cur = $existingDefs[$rd.name]
        if ([bool]$cur['isCollection'] -ne [bool]$rd.isCollection) {
            throw "CRITICAL SCHEMA MISMATCH: '$($rd.name)' exists with isCollection=$($cur['isCollection']), expected $($rd.isCollection)."
        }
        if ([bool]$cur['usePreDefinedValuesOnly'] -ne [bool]$rd.usePreDefinedValuesOnly) {
            throw "CRITICAL SCHEMA MISMATCH: '$($rd.name)' exists with usePreDefinedValuesOnly=$($cur['usePreDefinedValuesOnly']), expected $($rd.usePreDefinedValuesOnly)."
        }
        Write-Host "  [OK] Definition '$($rd.name)' verified (type=$($cur['type']), isCollection=$($cur['isCollection']), usePreDefinedValuesOnly=$($cur['usePreDefinedValuesOnly']), status=$($cur['status']))." -ForegroundColor Green
    } elseif ($PSCmdlet.ShouldProcess("Definition '$AttributeSetName.$($rd.name)' (isCollection=$($rd.isCollection), usePreDefinedValuesOnly=$($rd.usePreDefinedValuesOnly))", 'Create in Entra ID (IRREVERSIBLE)')) {
        $defBody = @{
            attributeSet            = $AttributeSetName
            name                    = $rd.name
            description             = $rd.description
            type                    = 'String'
            status                  = 'Available'
            isCollection            = [bool]$rd.isCollection
            isSearchable            = $true
            usePreDefinedValuesOnly = [bool]$rd.usePreDefinedValuesOnly
        }
        if ($null -ne $rd.allowedValues) {
            $defBody['allowedValues'] = $rd.allowedValues
        }
        Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/directory/customSecurityAttributeDefinitions' -Body $defBody | Out-Null
        Write-Host "  [CREATED] Definition '$($rd.name)' (isCollection=$($rd.isCollection), usePreDefinedValuesOnly=$($rd.usePreDefinedValuesOnly))." -ForegroundColor Green
    }
}

# Helper to grant a scoped Entra directory role idempotently
function Grant-ScopedRole {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param([string]$PrincipalId, [string]$RoleDefId, [string]$RoleName, [string]$DirectoryScopeId)
    $existing = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments?`$filter=principalId eq '$PrincipalId' and roleDefinitionId eq '$RoleDefId'"
    $alreadyAssigned = $false
    if ($existing.ContainsKey('value') -and $null -ne $existing['value']) {
        $alreadyAssigned = (@($existing['value'] | Where-Object { $_['directoryScopeId'] -eq $DirectoryScopeId }).Count -gt 0)
    }
    if ($alreadyAssigned) {
        Write-Host "  [OK] Principal '$PrincipalId' already holds '$RoleName' scoped to '$DirectoryScopeId'." -ForegroundColor Green
    } elseif ($PSCmdlet.ShouldProcess("Principal '$PrincipalId'", "Grant '$RoleName' scoped to '$DirectoryScopeId'")) {
        Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments' -Body @{
            '@odata.type'    = '#microsoft.graph.unifiedRoleAssignment'
            roleDefinitionId = $RoleDefId
            principalId      = $PrincipalId
            directoryScopeId = $DirectoryScopeId
        } | Out-Null
        Write-Host "  [ASSIGNED] '$RoleName' to '$PrincipalId' on scope '$DirectoryScopeId'." -ForegroundColor Green
    }
}

$attrSetScope = "/attributeSets/$AttributeSetName"

# 3. Least-Privilege Role Scoping for Unity Deploy SP
if (-not [string]::IsNullOrWhiteSpace($UnityDeploySpObjectId)) {
    Write-Host "`n=== Scoping Unity Deploy Automation SP ===" -ForegroundColor Cyan
    Grant-ScopedRole -PrincipalId $UnityDeploySpObjectId -RoleDefId $Role_AttrAssignAdmin -RoleName 'Attribute Assignment Administrator' -DirectoryScopeId $attrSetScope
}

# 4. Least-Privilege Read-Only Audit Roles for Enterprise Security
if (-not [string]::IsNullOrWhiteSpace($EnterpriseSecurityPrincipalId)) {
    Write-Host "`n=== Scoping Enterprise Security Read-Only Audit Roles ===" -ForegroundColor Cyan
    Grant-ScopedRole -PrincipalId $EnterpriseSecurityPrincipalId -RoleDefId $Role_AttrAssignReader -RoleName 'Attribute Assignment Reader' -DirectoryScopeId $attrSetScope
    Grant-ScopedRole -PrincipalId $EnterpriseSecurityPrincipalId -RoleDefId $Role_AttrLogReader    -RoleName 'Attribute Log Reader'        -DirectoryScopeId $attrSetScope
}

Write-Host "`nDone." -ForegroundColor Cyan
