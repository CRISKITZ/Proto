# Entra ID App-to-App Permission Governance Prototype (RFC Phase 1)

Pure-PowerShell prototype (zero external module dependencies; Windows PowerShell 5.1 & PowerShell 7+) implementing **"RFC - Governance of App to App permission granting in Entra ID (Phase 1)"**, plus a QA/PROD Entra Admin rollout script and a reference Terraform handoff blueprint for the Unity Deploy team.

## What Each File Does

| File | Audience | Purpose |
|---|---|---|
| `00-Create-Schema-For-QA-PROD.ps1` | **Entra ID Admin** | Peer-reviewable, one-time QA/PROD script (supports `-WhatIf`) to create `AppToAppAccess` (`maxAttributesPerSet=6`) + 6 definitions (4 collections, 2 predefined `Allow`/`Deny`) and assign scoped RBAC to Unity Deploy SP & Enterprise Security. |
| `01-Setup-DevEntra.ps1` | **Entra ID Engr** | One-time sandbox setup: creates schema, 6 `ProtoUnity-*` test apps, and validates the **MirroredExact** shared role/scope spike. Supports `-Cleanup`. |
| `02-Sync-ProducerRules.ps1` | **Entra ID Engr** | Validates producer rule JSON (naming, 64-char limit, 50-value SP budget) and writes `AppToAppAccess` attributes (`-Mode DryRun` or `-Mode LiveRun`). |
| `03-Invoke-ConsumerDeploy.ps1` | **Entra ID Engr** | Simulates Unity Deploy for a consumer (`-Mode DryRun` / `-Mode LiveRun`), applies grants/revocations, and writes JSON + Markdown evidence under `evidence/`. |
| `04-Run-LiveE2ETests.ps1` | **Entra ID Engr** | Full live Entra ID E2E QA POC suite (21 assertions across all 4 `APP_TYPE`s, SPA/Admin guardrails, Legacy Deny, Revocation, and real Client Credentials JWT `roles`/`idtyp` claims). |
| `05-Test-DelegatedScopeToken.ps1` | **Entra ID Engr** | Optional interactive check to acquire and decode a live delegated user JWT showing the `scp` claim with zero user consent prompt. |
| `06-Run-Demo.ps1` | **Entra ID Engr** | One-command demo script for presenting live to Identity, Enterprise Security, and the Unity team. |
| `QA-POC-Handoff-Report.md` | **Stakeholders** | Ready-to-share Confluence/email summary + clear split of Entra ID vs. Unity Deploy/Terraform responsibilities. |
| `tests/Invoke-UnitTests.ps1` | **Entra ID Engr** | 66 offline unit tests for the policy engine (Unity Deploy `APP_TYPE`s, Naming Standard bounds, case-sensitive matching, fail-closed invalid Deny rules, ES complete-AppID wildcard rule, SPA/Admin guardrails, Legacy non-standard permissions — no Entra connection required). |
| `terraform-bridge/` | **Unity Deploy Team** | Reference `main.tf` + `Evaluate-PolicyForTerraform.ps1` blueprint to hand over to the Terraform/Unity engineers. |

## Quick Commands
```powershell
# Run the full narrated stakeholder demo (takes ~45 seconds)
.\06-Run-Demo.ps1

# Optional: verify a live delegated user token ('scp' claim, zero consent prompt)
.\05-Test-DelegatedScopeToken.ps1 -ConsumerKey spaConsumer

# Preview QA/PROD schema & scoped RBAC setup without making changes
.\00-Create-Schema-For-QA-PROD.ps1 -WhatIf

# Clean up the 6 sandbox test apps when finished
.\01-Setup-DevEntra.ps1 -Cleanup
```
