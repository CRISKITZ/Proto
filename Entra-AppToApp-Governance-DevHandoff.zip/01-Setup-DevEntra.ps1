#Requires -Version 5.1
<#
.SYNOPSIS
    Step 0 / One-Time DEV Setup for the Entra ID App-to-App Permission Governance Prototype.
.DESCRIPTION
    1. Connects to Microsoft Graph as a tenant administrator (or via Service Principal env vars).
    2. Ensures Attribute Definition Administrator & Attribute Assignment Administrator roles.
    3. Idempotently creates Attribute Set 'AppToAppAccess' and all 6 RFC definitions (4 collections).
    4. Creates DEV test applications (Managed Producer, Legacy Producer, Service, WebApp, MiddleTierApi, SPA).
    5. Runs the RFC's #1 DEV technical spike: publishing identical permission names (documents.read/write/admin)
       as BOTH appRoles and Admin-consent oauth2PermissionScopes on the same App Registration,
       automatically recording whether MirroredExact works or FallbackSuffix (.asuser) is required.
    6. Saves fixture metadata to state/dev-fixtures.json.

    Use -Cleanup to delete all prototype test applications created by this script.
    (Note: Entra ID Custom Security Attribute definitions cannot be deleted once created; they remain in AppToAppAccess.)
#>
[CmdletBinding()]
param(
    [switch]$Cleanup,
    [string]$Prefix = 'ProtoUnity'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
Import-Module (Join-Path $root 'modules\AppToAppGovernance.psm1') -Force
Import-Module (Join-Path $root 'modules\EntraGraphClient.psm1') -Force

$stateDir = Join-Path $root 'state'
$fixturePath = Join-Path $stateDir 'dev-fixtures.json'

Write-Host '=== Connecting to Microsoft Graph ===' -ForegroundColor Cyan
$ctx = Connect-GovernanceGraph
Write-Host "Connected as: $($ctx.Account) | Tenant: $($ctx.TenantId)" -ForegroundColor Green

if ($Cleanup) {
    Write-Host "`n=== Cleaning Up Prototype Applications (Prefix: $Prefix) ===" -ForegroundColor Yellow
    if (-not (Test-Path $fixturePath)) {
        Write-Host "No fixture state found at $fixturePath." -ForegroundColor Yellow
        exit 0
    }
    $fixtures = Get-Content -Raw -Encoding UTF8 $fixturePath | ConvertFrom-Json
    foreach ($prop in $fixtures.apps.PSObject.Properties) {
        $a = $prop.Value
        try {
            Write-Host "  [-] Deleting app '$($a.DisplayName)' ($($a.AppObjectId)) ..." -ForegroundColor Yellow
            Invoke-Graph -Method DELETE -Uri "https://graph.microsoft.com/v1.0/applications/$($a.AppObjectId)" | Out-Null
        } catch {
            Write-Host "  [WARN] Could not delete '$($a.DisplayName)': $($_.Exception.Message)" -ForegroundColor DarkYellow
        }
    }
    Remove-Item -Force $fixturePath -ErrorAction SilentlyContinue
    Write-Host 'Cleanup complete. (Custom Security Attribute set AppToAppAccess is permanent in Entra ID.)' -ForegroundColor Green
    exit 0
}

Write-Host "`n=== 1. Ensuring Custom Security Attribute Admin Roles ===" -ForegroundColor Cyan
$roleRes = Initialize-AttributeAdminRoles
if ($roleRes.AssignedNew) {
    Write-Host '  [*] New directory roles assigned; waiting 15s and refreshing Graph token ...' -ForegroundColor Yellow
    Start-Sleep -Seconds 15
    $ctx = Connect-GovernanceGraph -ForceRefresh
}

Write-Host "`n=== 2. Ensuring AppToAppAccess Schema (6 Definitions, 4 Collections) ===" -ForegroundColor Cyan
$schemaReady = $false
for ($attempt = 1; $attempt -le 4; $attempt++) {
    try {
        Initialize-AppToAppAccessSchema
        $schemaReady = $true
        break
    } catch {
        if ($attempt -lt 4) {
            Write-Host "  [WARN] Attempt $attempt failed (likely role propagation delay): $($_.Exception.Message)" -ForegroundColor DarkYellow
            Start-Sleep -Seconds 15
        } else {
            throw
        }
    }
}

Write-Host "`n=== 3. Creating DEV Test Applications & Service Principals ===" -ForegroundColor Cyan
$managedProducer = Resolve-EntraApp -DisplayName "$Prefix-APP02830-docs-api-Producer" -Kind 'Producer'
$legacyProducer  = Resolve-EntraApp -DisplayName "$Prefix-APP09900-legacy-api-Producer" -Kind 'LegacyProducer'
$serviceConsumer = Resolve-EntraApp -DisplayName "$Prefix-APP12301_ledger_nightly-export" -Kind 'Service'
$webAppConsumer  = Resolve-EntraApp -DisplayName "$Prefix-APP12540_portal_client-web" -Kind 'WebApp'
$oboConsumer     = Resolve-EntraApp -DisplayName "$Prefix-APP12600_gateway_orders-api" -Kind 'MiddleTierApi'
$spaConsumer     = Resolve-EntraApp -DisplayName "$Prefix-APP12700_portal_client-spa" -Kind 'SPA'

Write-Host "`n=== 4. DEV Spike: Testing Shared Role + Scope Permission Publishing ===" -ForegroundColor Cyan
$perms = @('documents.read', 'documents.write', 'documents.admin')
$scopeSuffix = ''
$publishStrategyUsed = ''

Write-Host '  [Test A] Attempting MirroredExact (identical id + value + displayName + description) on Managed Producer...' -ForegroundColor White
$resMirror = Publish-ProducerPermissions -AppObjectId $managedProducer.AppObjectId -Permissions $perms -Strategy 'MirroredExact'
if ($resMirror.Success) {
    Write-Host '  [PASS] Entra ID ACCEPTED MirroredExact! Same permission name works for BOTH appRole and API scope.' -ForegroundColor Green
    $publishStrategyUsed = 'MirroredExact'
    $scopeSuffix = ''
} else {
    Write-Host "  [INFO] MirroredExact rejected by Entra ID: $($resMirror.Error)" -ForegroundColor Yellow
    Write-Host '  [Test B] Attempting DistinctIdsSameValue...' -ForegroundColor White
    $resDistinct = Publish-ProducerPermissions -AppObjectId $managedProducer.AppObjectId -Permissions $perms -Strategy 'DistinctIdsSameValue'
    if ($resDistinct.Success) {
        Write-Host '  [PASS] Entra ID ACCEPTED DistinctIdsSameValue!' -ForegroundColor Green
        $publishStrategyUsed = 'DistinctIdsSameValue'
        $scopeSuffix = ''
    } else {
        Write-Host "  [INFO] DistinctIdsSameValue rejected by Entra ID: $($resDistinct.Error)" -ForegroundColor Yellow
        Write-Host '  [Test C] Falling back to RFC alternative FallbackSuffix (.asuser)...' -ForegroundColor White
        $resFallback = Publish-ProducerPermissions -AppObjectId $managedProducer.AppObjectId -Permissions $perms -Strategy 'FallbackSuffix'
        if (-not $resFallback.Success) {
            throw "All permission publishing strategies failed: $($resFallback.Error)"
        }
        Write-Host '  [PASS] FallbackSuffix (.asuser) succeeded.' -ForegroundColor Green
        $publishStrategyUsed = 'FallbackSuffix'
        $scopeSuffix = '.asuser'
    }
}

Write-Host "  [*] Publishing same permissions on Legacy Producer using strategy '$publishStrategyUsed'..." -ForegroundColor White
$resLegacy = Publish-ProducerPermissions -AppObjectId $legacyProducer.AppObjectId -Permissions $perms -Strategy $publishStrategyUsed
if (-not $resLegacy.Success) {
    throw "Failed to publish permissions on Legacy Producer: $($resLegacy.Error)"
}

# Ensure Legacy Producer has NO AppToAppAccess metadata (true legacy state)
Write-Host '  [*] Ensuring Legacy Producer carries NO AppToAppAccess metadata...' -ForegroundColor White
Clear-ProducerSpMetadata -ServicePrincipalId $legacyProducer.ServicePrincipalId

Write-Host "`n=== 5. Saving Fixture State ===" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $stateDir | Out-Null

$fixtureData = [ordered]@{
    tenantId            = $ctx.TenantId
    adminAccount        = $ctx.Account
    createdUtc          = (Get-Date).ToUniversalTime().ToString('o')
    publishStrategyUsed = $publishStrategyUsed
    scopeSuffix         = $scopeSuffix
    apps                = [ordered]@{
        managedProducer = $managedProducer
        legacyProducer  = $legacyProducer
        serviceConsumer = $serviceConsumer
        webAppConsumer  = $webAppConsumer
        oboConsumer     = $oboConsumer
        spaConsumer     = $spaConsumer
    }
}

$fixtureData | ConvertTo-Json -Depth 10 | Out-File -Encoding UTF8 -FilePath $fixturePath
Write-Host "Saved fixture metadata to: $fixturePath" -ForegroundColor Green
Write-Host "Publish strategy validated in DEV: $publishStrategyUsed (scopeSuffix='$scopeSuffix')" -ForegroundColor Cyan
