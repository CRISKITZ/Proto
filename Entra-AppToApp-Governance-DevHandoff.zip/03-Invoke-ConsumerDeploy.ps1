#Requires -Version 5.1
<#
.SYNOPSIS
    Simulates Unity Deploy for a Consumer application (Steps 1-5 of RFC Phase 1).
.DESCRIPTION
    - DryRun (Steps 2-3): Derives role vs scope from APP_TYPE, validates naming, fetches live Producer
      AppToAppAccess metadata, runs fixed 4-step decision order, and prints the decision table + deciding rule.
    - LiveRun (Steps 4-5): Re-reads live Producer metadata, re-evaluates rules, grants ALLOWED permissions
      (appRoleAssignment or oauth2PermissionGrant AllPrincipals), REVOKES removed/denied permissions,
      and writes structured JSON + Markdown evidence under evidence/.
    - Use -StrictFailOnDeny to fail the deployment if ANY requested permission is denied (Unity Deploy default behavior),
      or leave unset to grant allowed permissions while reporting denied ones for prototype demonstrations.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ConfigPath,

    [Parameter(Mandatory = $false)]
    [ValidateSet('DryRun', 'LiveRun')]
    [string]$Mode = 'DryRun',

    [switch]$StrictFailOnDeny
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
Import-Module (Join-Path $root 'modules\AppToAppGovernance.psm1') -Force
Import-Module (Join-Path $root 'modules\EntraGraphClient.psm1') -Force

$fixturePath = Join-Path $root 'state\dev-fixtures.json'
if (-not (Test-Path $fixturePath)) {
    throw "Fixture file not found at $fixturePath. Run 01-Setup-DevEntra.ps1 first."
}

$fixtures = Get-Content -Raw -Encoding UTF8 $fixturePath | ConvertFrom-Json
$cfg = Get-Content -Raw -Encoding UTF8 $ConfigPath | ConvertFrom-Json
$consumerApp = $fixtures.apps.($cfg.consumerKey)
if ($null -eq $consumerApp) {
    throw "Consumer key '$($cfg.consumerKey)' not found in $fixturePath."
}

# Demo binding only: Unity Deploy proper reads the identity from the trusted Unity project record.
if (-not ([string]$consumerApp.DisplayName).EndsWith("-$($cfg.consumerIdentity)", [System.StringComparison]::Ordinal)) {
    throw "consumerIdentity '$($cfg.consumerIdentity)' does not belong to consumer '$($consumerApp.DisplayName)'."
}

$ctx = Connect-GovernanceGraph
Assert-AttributeReadAccess | Out-Null
$consumerSpLive = Get-ConsumerSpDetails -ServicePrincipalId $consumerApp.ServicePrincipalId
if (-not ([string]$consumerSpLive.DisplayName).EndsWith("-$($cfg.consumerIdentity)", [System.StringComparison]::Ordinal)) {
    throw "Live Entra consumer SP '$($consumerSpLive.DisplayName)' does not match consumerIdentity '$($cfg.consumerIdentity)'."
}
$grantInfo = Resolve-GrantType -AppType $cfg.appType

Write-Host "`n================================================================================" -ForegroundColor Cyan
Write-Host "UNITY DEPLOY PROTOTYPE [$Mode]" -ForegroundColor Cyan
Write-Host "Consumer : $($cfg.consumerIdentity) ($($consumerSpLive.DisplayName))"
Write-Host "APP_TYPE : $($cfg.appType) -> Derived: $($grantInfo.GrantType) ($($grantInfo.Flow)) | SPA=$($grantInfo.IsSpa)"
Write-Host "================================================================================" -ForegroundColor Cyan

$allDecisions = New-Object System.Collections.Generic.List[PSCustomObject]
$allActions   = New-Object System.Collections.Generic.List[PSCustomObject]
$declaredProducerSpIds = @{}

foreach ($dep in @($cfg.dependencies)) {
    $producerApp = $fixtures.apps.($dep.producerKey)
    if ($null -eq $producerApp) {
        throw "Producer key '$($dep.producerKey)' not found in $fixturePath."
    }
    $declaredProducerSpIds[$producerApp.ServicePrincipalId] = $true

    # Always read LIVE Producer metadata (RFC Step 2 & Step 4 re-evaluation)
    $spDetails = Get-ProducerSpDetails -ServicePrincipalId $producerApp.ServicePrincipalId
    $postureLabel = if ($spDetails.IsLegacy) { 'LEGACY (no AppToAppAccess metadata)' } else { 'MANAGED (AppToAppAccess present)' }
    Write-Host "`n--- Producer: $($spDetails.DisplayName) [$postureLabel] ---" -ForegroundColor White

    $allowedPermsForProducer = New-Object System.Collections.Generic.List[string]
    $deniedCountForProducer = 0

    foreach ($perm in @($dep.permissions)) {
        $decision = Invoke-GovernanceDecision `
            -ConsumerIdentity $cfg.consumerIdentity `
            -ConsumerAppType $cfg.appType `
            -ProducerDisplayName $spDetails.DisplayName `
            -ProducerAppId $spDetails.AppId `
            -ProducerOwnerContact 'Producer API Team (see Unity Compass)' `
            -Permission $perm `
            -ProducerAttributes $spDetails.AppToAppAccess

        $allDecisions.Add($decision)

        $color = if ($decision.Decision -eq 'ALLOW') { 'Green' } else { 'Red' }
        Write-Host ("  [{0,-5}] {1,-18} | Type={2,-8} | Step={3,-24} | Rule={4}" -f `
            $decision.Decision, $decision.Permission, $decision.GrantType, $decision.DecidingStep, $decision.DecidingRule) -ForegroundColor $color
        if ($decision.Decision -eq 'DENY') {
            $deniedCountForProducer++
            Write-Host "          Reason : $($decision.Reason)" -ForegroundColor DarkYellow
            Write-Host "          Next   : $($decision.ContactGuidance)" -ForegroundColor DarkGray
        } else {
            $allowedPermsForProducer.Add($perm)
        }
    }

    if ($StrictFailOnDeny -and $deniedCountForProducer -gt 0) {
        Write-Host "  [BLOCKED] StrictFailOnDeny is active; skipping grant application for $($spDetails.DisplayName)." -ForegroundColor Red
        continue
    }

    $isPreview = ($Mode -eq 'DryRun')
    if ($grantInfo.GrantType -eq 'AppRole') {
        $acts = Sync-ConsumerAppRoleGrants `
            -ConsumerSpId $consumerApp.ServicePrincipalId `
            -ProducerSpId $spDetails.ServicePrincipalId `
            -ProducerAppRoles $spDetails.AppRoles `
            -DesiredPermissions @($allowedPermsForProducer) `
            -PreviewOnly:$isPreview
    } else {
        $acts = Sync-ConsumerApiScopeGrants `
            -ConsumerSpId $consumerApp.ServicePrincipalId `
            -ProducerSpId $spDetails.ServicePrincipalId `
            -ProducerScopes $spDetails.OAuth2PermissionScopes `
            -DesiredPermissions @($allowedPermsForProducer) `
            -ScopeSuffix ([string]$fixtures.scopeSuffix) `
            -PreviewOnly:$isPreview
    }

    foreach ($a in @($acts)) {
        $a | Add-Member -NotePropertyName 'ProducerDisplayName' -NotePropertyValue $spDetails.DisplayName -Force
        $allActions.Add($a)
        $acColor = switch ($a.Action) {
            'GRANTED'      { 'Green' }
            'WOULD_GRANT'  { 'DarkGreen' }
            'REVOKED'      { 'Magenta' }
            'WOULD_REVOKE' { 'DarkMagenta' }
            'UNCHANGED'    { 'Gray' }
            default        { 'White' }
        }
        Write-Host ("  => {0,-16} {1,-8} {2} (GraphId={3})" -f $a.Action, $a.GrantType, $a.Permission, $a.Id) -ForegroundColor $acColor
    }
}

# Reconcile grants for producers NO LONGER declared in dependencies:
# - Known Unity-managed producers -> revoke in LiveRun (preview WOULD_REVOKE in DryRun)
# - Unmanaged / out-of-band grants (created outside Unity Deploy) -> preserve and report OUT_OF_BAND_REVIEW for Enterprise Security
$knownManagedProducers = @{}
foreach ($appProp in $fixtures.apps.PSObject.Properties) {
    $appObj = $appProp.Value
    if ($appObj.Kind -in @('Producer', 'LegacyProducer')) {
        $knownManagedProducers[$appObj.ServicePrincipalId] = $appObj
    }
}

$allCurrentGrants = Get-AllConsumerGrants -ConsumerSpId $consumerApp.ServicePrincipalId
$undeclaredRoles  = @($allCurrentGrants.AppRoleAssignments | Where-Object { -not $declaredProducerSpIds.ContainsKey($_['resourceId']) })
$undeclaredScopes = @($allCurrentGrants.OAuth2PermissionGrants | Where-Object { -not $declaredProducerSpIds.ContainsKey($_['resourceId']) })

if ($undeclaredRoles.Count -gt 0 -or $undeclaredScopes.Count -gt 0) {
    Write-Host "`n--- Undeclared / Removed Dependency Reconciliation ---" -ForegroundColor White

    foreach ($ra in $undeclaredRoles) {
        $resId = [string]$ra['resourceId']
        $permLabel = if ($ra.ContainsKey('appRoleId')) { [string]$ra['appRoleId'] } else { 'appRole' }
        if ($knownManagedProducers.ContainsKey($resId)) {
            $prodName = $knownManagedProducers[$resId].DisplayName
            if ($Mode -eq 'LiveRun') {
                Invoke-Graph -Method DELETE -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$($consumerApp.ServicePrincipalId)/appRoleAssignments/$($ra['id'])" | Out-Null
                $act = [PSCustomObject]@{ Action = 'REVOKED'; GrantType = 'AppRole'; Permission = "$permLabel (dependency removed)"; Id = $ra['id']; ResourceId = $resId; ProducerDisplayName = $prodName }
                Write-Host ("  => {0,-16} {1,-8} {2} on {3} (GraphId={4})" -f $act.Action, $act.GrantType, $act.Permission, $prodName, $act.Id) -ForegroundColor Magenta
            } else {
                $act = [PSCustomObject]@{ Action = 'WOULD_REVOKE'; GrantType = 'AppRole'; Permission = "$permLabel (dependency removed)"; Id = $ra['id']; ResourceId = $resId; ProducerDisplayName = $prodName }
                Write-Host ("  => {0,-16} {1,-8} {2} on {3} (GraphId={4})" -f $act.Action, $act.GrantType, $act.Permission, $prodName, $act.Id) -ForegroundColor DarkMagenta
            }
            $allActions.Add($act)
        } else {
            $resName = if ($ra.ContainsKey('resourceDisplayName') -and $ra['resourceDisplayName']) { [string]$ra['resourceDisplayName'] } else { $resId }
            $act = [PSCustomObject]@{ Action = 'OUT_OF_BAND_REVIEW'; GrantType = 'AppRole'; Permission = "$permLabel (not managed by Unity Deploy)"; Id = $ra['id']; ResourceId = $resId; ProducerDisplayName = $resName }
            Write-Host ("  => {0,-18} {1,-8} {2} on {3} (GraphId={4}) [Preserved for Enterprise Security review]" -f $act.Action, $act.GrantType, $act.Permission, $resName, $act.Id) -ForegroundColor Yellow
            $allActions.Add($act)
        }
    }

    foreach ($sg in $undeclaredScopes) {
        $resId = [string]$sg['resourceId']
        $scopeVal = if ($sg.ContainsKey('scope')) { ([string]$sg['scope']).Trim() } else { '' }
        if ($knownManagedProducers.ContainsKey($resId)) {
            $prodName = $knownManagedProducers[$resId].DisplayName
            if ($Mode -eq 'LiveRun') {
                Invoke-Graph -Method DELETE -Uri "https://graph.microsoft.com/v1.0/oauth2PermissionGrants/$($sg['id'])" | Out-Null
                $act = [PSCustomObject]@{ Action = 'REVOKED'; GrantType = 'ApiScope'; Permission = "$scopeVal (dependency removed)"; Id = $sg['id']; ResourceId = $resId; ProducerDisplayName = $prodName }
                Write-Host ("  => {0,-16} {1,-8} {2} on {3} (GraphId={4})" -f $act.Action, $act.GrantType, $act.Permission, $prodName, $act.Id) -ForegroundColor Magenta
            } else {
                $act = [PSCustomObject]@{ Action = 'WOULD_REVOKE'; GrantType = 'ApiScope'; Permission = "$scopeVal (dependency removed)"; Id = $sg['id']; ResourceId = $resId; ProducerDisplayName = $prodName }
                Write-Host ("  => {0,-16} {1,-8} {2} on {3} (GraphId={4})" -f $act.Action, $act.GrantType, $act.Permission, $prodName, $act.Id) -ForegroundColor DarkMagenta
            }
            $allActions.Add($act)
        } else {
            $act = [PSCustomObject]@{ Action = 'OUT_OF_BAND_REVIEW'; GrantType = 'ApiScope'; Permission = "$scopeVal (not managed by Unity Deploy)"; Id = $sg['id']; ResourceId = $resId; ProducerDisplayName = $resId }
            Write-Host ("  => {0,-18} {1,-8} {2} on {3} (GraphId={4}) [Preserved for Enterprise Security review]" -f $act.Action, $act.GrantType, $act.Permission, $resId, $act.Id) -ForegroundColor Yellow
            $allActions.Add($act)
        }
    }
}

# Step 5: Write Evidence
$evidenceDir = Join-Path $root 'evidence'
New-Item -ItemType Directory -Force -Path $evidenceDir | Out-Null
$stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss')
$safeName = $cfg.consumerIdentity -replace '[^A-Za-z0-9_\-]', '_'
$jsonPath = Join-Path $evidenceDir "$safeName-$Mode-$stamp.json"
$mdPath   = Join-Path $evidenceDir "$safeName-$Mode-$stamp.md"

$evidenceObj = [ordered]@{
    mode             = $Mode
    executedUtc      = (Get-Date).ToUniversalTime().ToString('o')
    executedBy       = $ctx.Account
    tenantId         = $ctx.TenantId
    consumerIdentity = $cfg.consumerIdentity
    consumerAppId    = $consumerApp.AppId
    consumerSpId     = $consumerApp.ServicePrincipalId
    consumerAppType  = $cfg.appType
    derivedGrantType = $grantInfo.GrantType
    decisions        = @($allDecisions)
    entraActions     = @($allActions)
}

$evidenceObj | ConvertTo-Json -Depth 10 | Out-File -Encoding UTF8 -FilePath $jsonPath

$mdLines = New-Object System.Collections.Generic.List[string]
$mdLines.Add("# Unity Deploy Evidence - $($cfg.consumerIdentity) ($Mode)")
$mdLines.Add('')
$mdLines.Add("- **Timestamp (UTC):** $($evidenceObj.executedUtc)")
$mdLines.Add("- **Actor:** $($evidenceObj.executedBy)")
$mdLines.Add("- **Consumer APP_TYPE:** $($cfg.appType) -> **$($grantInfo.GrantType)** ($($grantInfo.Flow))")
$mdLines.Add('')
$mdLines.Add('## Policy Evaluation Decisions')
$mdLines.Add('| Producer | Permission | Tier | Type | Decision | Deciding Step | Deciding Rule |')
$mdLines.Add('|---|---|---|---|---|---|---|')
foreach ($d in $allDecisions) {
    $mdLines.Add("| $($d.ProducerDisplayName) | ``$($d.Permission)`` | $($d.Tier) | $($d.GrantType) | **$($d.Decision)** | $($d.DecidingStep) | ``$($d.DecidingRule)`` |")
}
if ($allActions.Count -gt 0) {
    $mdLines.Add('')
    $actionsHeading = if ($Mode -eq 'DryRun') { '## Entra ID Grants / Revocations Preview (DryRun)' } else { '## Entra ID Grants / Revocations Applied' }
    $mdLines.Add($actionsHeading)
    $mdLines.Add('| Producer | Action | Grant Type | Permission | Graph Object ID |')
    $mdLines.Add('|---|---|---|---|---|')
    foreach ($a in $allActions) {
        $mdLines.Add("| $($a.ProducerDisplayName) | **$($a.Action)** | $($a.GrantType) | ``$($a.Permission)`` | ``$($a.Id)`` |")
    }
}
$mdLines | Out-File -Encoding UTF8 -FilePath $mdPath

Write-Host "`n[Step 5 Evidence] Written to:" -ForegroundColor Cyan
Write-Host "  JSON : $jsonPath"
Write-Host "  MD   : $mdPath"

$totalDenied = @($allDecisions | Where-Object { $_.Decision -eq 'DENY' }).Count
if ($StrictFailOnDeny -and $totalDenied -gt 0) {
    Write-Host "`n[EXIT 2] $totalDenied permission(s) denied under StrictFailOnDeny." -ForegroundColor Red
    exit 2
}

return $evidenceObj
