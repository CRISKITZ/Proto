#Requires -Version 5.1
<#
.SYNOPSIS
    Syncs declarative Producer rules (from config JSON) to Entra ID Custom Security Attributes (AppToAppAccess).
.DESCRIPTION
    Simulates the Producer side of Unity Deploy:
      - Reads producer rule JSON
      - Validates naming convention, 64-char limit, and 50-value SP budget (including other attribute sets)
      - DryRun shows what would be written; LiveRun writes AppToAppAccess attributes via Microsoft Graph
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'config\producer-managed.json'),

    [Parameter(Mandatory = $false)]
    [ValidateSet('DryRun', 'LiveRun')]
    [string]$Mode = 'DryRun'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
Import-Module (Join-Path $root 'modules\AppToAppGovernance.psm1') -Force
Import-Module (Join-Path $root 'modules\EntraGraphClient.psm1') -Force

$fixturePath = Join-Path $root 'state\dev-fixtures.json'
if (-not (Test-Path $fixturePath)) {
    throw "Fixture file not found at $fixturePath. Run 01-Setup-DevEntra.ps1 first."
}

$fixtures = Get-Content -Raw -Encoding UTF8 $fixturePath | ConvertFrom-Json
$cfg = Get-Content -Raw -Encoding UTF8 $ConfigPath | ConvertFrom-Json

$producerApp = $fixtures.apps.($cfg.producerKey)
if ($null -eq $producerApp) {
    throw "Producer key '$($cfg.producerKey)' not found in $fixturePath."
}

# Convert JSON rules object to hashtable
$rulesHash = @{}
foreach ($prop in $cfg.rules.PSObject.Properties) {
    $rulesHash[$prop.Name] = $prop.Value
}

Write-Host "=== Producer Rule Sync [$Mode] : $($producerApp.DisplayName) ===" -ForegroundColor Cyan
Connect-GovernanceGraph | Out-Null

$spDetails = Get-ProducerSpDetails -ServicePrincipalId $producerApp.ServicePrincipalId
Write-Host "  Existing non-AppToAppAccess attribute values on SP: $($spDetails.OtherAttributeValueCount)" -ForegroundColor Gray

# Pre-flight validation
$validation = Test-ProducerRuleConfig -Rules $rulesHash -ExistingOtherAttributeValueCount $spDetails.OtherAttributeValueCount
if (-not $validation.IsValid) {
    Write-Host '  [FAIL] Producer rule validation failed:' -ForegroundColor Red
    foreach ($e in $validation.Errors) {
        Write-Host "    - $e" -ForegroundColor Red
    }
    exit 1
}

Write-Host "  [OK] Validation passed. Total SP attribute values: $($validation.TotalValueCount)/50 (remaining: $($validation.RemainingBudget))." -ForegroundColor Green

foreach ($k in @('DefaultAppRole', 'AllowAppRole', 'DenyAppRole', 'DefaultScope', 'AllowScope', 'DenyScope')) {
    if ($rulesHash.ContainsKey($k)) {
        $v = $rulesHash[$k]
        $display = if ($v -is [System.Collections.IEnumerable] -and -not ($v -is [string])) { (@($v) -join ', ') } else { [string]$v }
        Write-Host ("  {0,-16}: {1}" -f $k, $display)
    }
}

if ($Mode -eq 'DryRun') {
    Write-Host "`n[DryRun] No changes written to Entra ID. Re-run with -Mode LiveRun to apply." -ForegroundColor Yellow
    exit 0
}

Set-ProducerSpMetadata -ServicePrincipalId $producerApp.ServicePrincipalId -Rules $rulesHash
Write-Host "`n[LiveRun] Successfully updated AppToAppAccess Custom Security Attributes on '$($producerApp.DisplayName)'." -ForegroundColor Green
