#Requires -Version 5.1
<#
.SYNOPSIS
    Offline unit test suite for AppToAppGovernance.psm1 covering every RFC rule,
    naming convention constraint, wildcard boundary, SPA/Admin guardrail, and legacy fallback.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path $PSScriptRoot '..\modules\AppToAppGovernance.psm1'
Import-Module $modulePath -Force

$passed = 0
$failed = 0

function Assert-Test {
    param(
        [string]$Name,
        [bool]$Condition,
        [string]$Details = ''
    )
    if ($Condition) {
        $script:passed++
        Write-Host "  [PASS] $Name" -ForegroundColor Green
    } else {
        $script:failed++
        Write-Host "  [FAIL] $Name $Details" -ForegroundColor Red
    }
}

Write-Host "`n=== 1. Naming Convention & Limit Validation ===" -ForegroundColor Cyan

$r = Test-PermissionName 'documents.read'
Assert-Test 'Valid read permission' ($r.IsValid -and $r.Tier -eq 'Read')

$r = Test-PermissionName 'audit-reports.write'
Assert-Test 'Valid hyphenated write permission' ($r.IsValid -and $r.Tier -eq 'Write')

$r = Test-PermissionName 'ledger.admin'
Assert-Test 'Valid admin permission' ($r.IsValid -and $r.Tier -eq 'Admin')

$r = Test-PermissionName 'documents.delete'
Assert-Test 'Reject unsupported verb (delete)' (-not $r.IsValid)

$r = Test-PermissionName 'Documents.Read'
Assert-Test 'Reject uppercase permission name' (-not $r.IsValid)

$r = Test-ConsumerIdentity 'APP12540_portal_client-web'
Assert-Test 'Valid consumer identity' ($r.IsValid)

$r = Test-ConsumerIdentity 'portal_client-web'
Assert-Test 'Reject consumer identity missing APPID' (-not $r.IsValid)

$r = Test-GovernanceRule 'APP12540_portal_client-web:documents.read'
Assert-Test 'Valid exact rule (41 chars)' ($r.IsValid -and -not $r.HasWildcard)

$r = Test-GovernanceRule 'APP12540_*:documents.*'
Assert-Test 'Valid wildcard rule with complete AppID + underscore' ($r.IsValid -and $r.HasWildcard)

$r = Test-GovernanceRule '*:documents.*'
Assert-Test 'Valid global consumer wildcard (* alone)' ($r.IsValid -and $r.HasWildcard)

$r = Test-GovernanceRule 'APP*:documents.*'
Assert-Test 'Reject partial AppID wildcard (APP*)' (-not $r.IsValid)

$r = Test-GovernanceRule 'APP123*:documents.read'
Assert-Test 'Reject partial numeric AppID wildcard (APP123*)' (-not $r.IsValid)

$r = Test-GovernanceRule 'APP12301*:documents.read'
Assert-Test 'Reject AppID wildcard missing underscore (APP12301*)' (-not $r.IsValid)

$r = Test-GovernanceRule '*portal*:documents.read'
Assert-Test 'Reject consumer wildcard without complete AppID + underscore' (-not $r.IsValid)

$r = Test-GovernanceRule 'APP12540*documents.read'
Assert-Test 'Reject wildcard spanning across missing colon' (-not $r.IsValid)

$longRule = 'APP12540_very-long-project-name_very-long-component-name:documents.read'
Assert-Test "Reject rule exceeding 64 chars (len=$($longRule.Length))" (-not (Test-GovernanceRule $longRule).IsValid)

$deprecatedCheck = Test-ProducerRuleConfig -Rules @{
    Default = 'Deny'
    Allow   = @('APP12301_*:documents.read')
}
Assert-Test 'Reject deprecated attribute names (Default/Allow/Deny)' (-not $deprecatedCheck.IsValid)

$budgetFail = Test-ProducerRuleConfig -Rules @{
    DefaultAppRole = 'Deny'
    DefaultScope   = 'Deny'
    AllowAppRole   = (1..49 | ForEach-Object { "APP100$($_)_proj_comp:docs.read" })
}
Assert-Test 'Reject producer config exceeding 50 SP attribute values' (-not $budgetFail.IsValid -and $budgetFail.TotalValueCount -eq 51)

$budgetWithOther = Test-ProducerRuleConfig -ExistingOtherAttributeValueCount 5 -Rules @{
    DefaultAppRole = 'Deny'
    AllowAppRole   = (1..45 | ForEach-Object { "APP100$($_)_proj_comp:docs.read" })
}
Assert-Test 'Reject producer config exceeding 50 values including other attribute sets' (-not $budgetWithOther.IsValid -and $budgetWithOther.TotalValueCount -eq 51)

Write-Host "`n=== 2. Wildcard Boundary (Never Crosses Colon) ===" -ForegroundColor Cyan

$m = Test-RuleMatch -Rule 'APP12540_*:documents.*' -ConsumerIdentity 'APP12540_portal_client-web' -Permission 'documents.read'
Assert-Test 'Wildcard matches per-side' ($m.Matched -and -not $m.IsExact)

$m = Test-RuleMatch -Rule 'APP12540_portal_client-web:documents.read' -ConsumerIdentity 'APP12540_portal_client-web' -Permission 'documents.read'
Assert-Test 'Exact match sets IsExact=true' ($m.Matched -and $m.IsExact)

$m = Test-RuleMatch -Rule '*:documents.read' -ConsumerIdentity 'APP99999_other_svc' -Permission 'documents.write'
Assert-Test 'Wildcard consumer does not match wrong permission' (-not $m.Matched)

Write-Host "`n=== 3. Consumer APP_TYPE Derivation ===" -ForegroundColor Cyan

Assert-Test 'Service -> AppRole (DefaultAppRole/AllowAppRole/DenyAppRole)' ((Resolve-GrantType 'Service').GrantType -eq 'AppRole' -and (Resolve-GrantType 'Service').AllowAttr -eq 'AllowAppRole')
Assert-Test 'WebApp -> ApiScope (DefaultScope/AllowScope/DenyScope)' ((Resolve-GrantType 'WebApp').GrantType -eq 'ApiScope' -and (Resolve-GrantType 'WebApp').AllowAttr -eq 'AllowScope' -and -not (Resolve-GrantType 'WebApp').IsSpa)
Assert-Test 'MiddleTierApi -> ApiScope (OBO)' ((Resolve-GrantType 'MiddleTierApi').GrantType -eq 'ApiScope' -and (Resolve-GrantType 'MiddleTierApi').Flow -eq 'OnBehalfOf')
Assert-Test 'SPA -> ApiScope with IsSpa=true' ((Resolve-GrantType 'SPA').GrantType -eq 'ApiScope' -and (Resolve-GrantType 'SPA').IsSpa)

Write-Host "`n=== 4. Fixed 4-Step Decision Order & Isolation ===" -ForegroundColor Cyan

$producerRules = @{
    DefaultAppRole = 'Deny'
    AllowAppRole   = @(
        'APP12301_*:documents.read',
        'APP12301_ledger_nightly-export:documents.admin',
        'APP12301_*:documents.admin'
    )
    DenyAppRole    = @(
        'APP12301_ledger_blocked-job:documents.read'
    )
    DefaultScope   = 'Deny'
    AllowScope     = @(
        'APP12540_portal_client-web:documents.read',
        'APP12540_portal_client-web:documents.admin',
        'APP12700_portal_client-spa:documents.read',
        'APP12700_portal_client-spa:documents.admin',
        'APP12600_*:documents.*'
    )
    DenyScope      = @(
        'APP12600_gateway_orders-api:documents.write'
    )
}

# Step 1: Deny overrides Allow
$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12301_ledger_blocked-job' -ConsumerAppType 'Service' -ProducerDisplayName 'ProducerB' -Permission 'documents.read' -ProducerAttributes $producerRules
Assert-Test 'DenyAppRole overrides wildcard AllowAppRole (AppRole)' ($d.Decision -eq 'DENY' -and $d.DecidingStep -eq '1-Deny')

$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12600_gateway_orders-api' -ConsumerAppType 'MiddleTierApi' -ProducerDisplayName 'ProducerB' -Permission 'documents.write' -ProducerAttributes $producerRules
Assert-Test 'DenyScope overrides wildcard AllowScope (ApiScope)' ($d.Decision -eq 'DENY' -and $d.DecidingStep -eq '1-Deny')

# Step 2: Admin tier rules
$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12301_ledger_nightly-export' -ConsumerAppType 'Service' -ProducerDisplayName 'ProducerB' -Permission 'documents.admin' -ProducerAttributes $producerRules
Assert-Test 'Admin granted on exact non-wildcard AllowAppRole (Service)' ($d.Decision -eq 'ALLOW' -and $d.DecidingStep -eq '2-AdminExactAllow')

$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12301_ledger_other-job' -ConsumerAppType 'Service' -ProducerDisplayName 'ProducerB' -Permission 'documents.admin' -ProducerAttributes $producerRules
Assert-Test 'Admin DENIED when only wildcard AllowAppRole matches (Service)' ($d.Decision -eq 'DENY' -and $d.DecidingStep -eq '2-AdminRequiresExactAllow')

$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12540_portal_client-web' -ConsumerAppType 'WebApp' -ProducerDisplayName 'ProducerB' -Permission 'documents.admin' -ProducerAttributes $producerRules
Assert-Test 'Admin granted on exact non-wildcard AllowScope (WebApp)' ($d.Decision -eq 'ALLOW' -and $d.DecidingStep -eq '2-AdminExactAllow')

$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12700_portal_client-spa' -ConsumerAppType 'SPA' -ProducerDisplayName 'ProducerB' -Permission 'documents.admin' -ProducerAttributes $producerRules
Assert-Test 'Admin ALWAYS DENIED for SPA even with exact AllowScope rule' ($d.Decision -eq 'DENY' -and $d.DecidingStep -eq '2-AdminSpaBlocked')

# Step 3: Allow & Attribute Isolation
$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12301_ledger_nightly-export' -ConsumerAppType 'Service' -ProducerDisplayName 'ProducerB' -Permission 'documents.read' -ProducerAttributes $producerRules
Assert-Test 'Wildcard AllowAppRole grants Read (AppRole)' ($d.Decision -eq 'ALLOW' -and $d.DecidingStep -eq '3-Allow')

$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12540_portal_client-web' -ConsumerAppType 'Service' -ProducerDisplayName 'ProducerB' -Permission 'documents.read' -ProducerAttributes $producerRules
Assert-Test 'Attribute isolation: AllowScope does NOT grant AppRole' ($d.Decision -eq 'DENY' -and $d.DecidingStep -eq '4-DefaultDeny')

$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12301_ledger_nightly-export' -ConsumerAppType 'WebApp' -ProducerDisplayName 'ProducerB' -Permission 'documents.read' -ProducerAttributes $producerRules
Assert-Test 'Attribute isolation: AllowAppRole does NOT grant ApiScope' ($d.Decision -eq 'DENY' -and $d.DecidingStep -eq '4-DefaultDeny')

# Step 4: Default Allow (still excludes Admin!)
$openProducer = @{ DefaultAppRole = 'Allow'; DefaultScope = 'Allow' }
$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP99999_any_app' -ConsumerAppType 'Service' -ProducerDisplayName 'OpenProducer' -Permission 'documents.write' -ProducerAttributes $openProducer
Assert-Test 'DefaultAppRole Allow grants Write' ($d.Decision -eq 'ALLOW' -and $d.DecidingStep -eq '4-DefaultAllow')

$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP99999_any_app' -ConsumerAppType 'Service' -ProducerDisplayName 'OpenProducer' -Permission 'documents.admin' -ProducerAttributes $openProducer
Assert-Test 'DefaultAppRole Allow NEVER grants Admin' ($d.Decision -eq 'DENY' -and $d.DecidingStep -eq '2-AdminRequiresExactAllow')

Write-Host "`n=== 5. Legacy Producer Behavior ===" -ForegroundColor Cyan

$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12540_portal_client-web' -ConsumerAppType 'WebApp' -ProducerDisplayName 'LegacyProducer' -Permission 'documents.read' -ProducerAttributes $null
Assert-Test 'Legacy producer (no metadata) defaults to Allow for read/write' ($d.Decision -eq 'ALLOW' -and $d.DecidingStep -eq '4-LegacyDefaultAllow')

$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12540_portal_client-web' -ConsumerAppType 'WebApp' -ProducerDisplayName 'LegacyProducer' -Permission 'documents.admin' -ProducerAttributes $null
Assert-Test 'Legacy producer (no metadata) STILL blocks Admin' ($d.Decision -eq 'DENY' -and $d.DecidingStep -eq '2-AdminRequiresExactAllow')

$legacyWithDeny = @{ DenyScope = @('APP12540_*:documents.*') }
$d = Invoke-GovernanceDecision -ConsumerIdentity 'APP12540_portal_client-web' -ConsumerAppType 'WebApp' -ProducerDisplayName 'LegacyProducer' -Permission 'documents.read' -ProducerAttributes $legacyWithDeny
Assert-Test 'Legacy producer with explicit DenyScope rule blocks consumer' ($d.Decision -eq 'DENY' -and $d.DecidingStep -eq '1-Deny')

Write-Host "`n=========================================" -ForegroundColor Cyan
Write-Host "UNIT TEST SUMMARY: $passed passed, $failed failed" -ForegroundColor $(if ($failed -eq 0) { 'Green' } else { 'Red' })
Write-Host "=========================================" -ForegroundColor Cyan

if ($failed -gt 0) { exit 1 }
