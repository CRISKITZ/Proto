# Reference Terraform module showing how Unity Deploy (HashiCorp Terraform + azuread provider)
# integrates the AppToAppGovernance policy engine during `terraform plan` (Dry Run)
# and `terraform apply` (Live Run).

terraform {
  required_providers {
    azuread  = { source = "hashicorp/azuread", version = ">= 2.47.0" }
    external = { source = "hashicorp/external", version = ">= 2.3.0" }
  }
}

# NOTE: In production Unity Deploy, consumer_identity and consumer_sp_object_id MUST be supplied
# from the trusted Unity project record (never from consumer-editable config files).
variable "consumer_identity" {
  type        = string
  description = "Consumer identity in Naming Standard format APP[0-9]{5}_project_component (15-41 chars, e.g. APP12540_portal_client-web)"

  validation {
    condition = (
      length(var.consumer_identity) >= 15 &&
      length(var.consumer_identity) <= 41 &&
      can(regex("^APP[0-9]{5}_[a-z0-9][a-z0-9-]{0,10}[a-z0-9]_[a-z0-9][a-z0-9-]+[a-z0-9]$", var.consumer_identity))
    )
    error_message = "consumer_identity must follow Naming Standard APP[0-9]{5}_project_component (15-41 chars; project 2-12 chars; component 3+ chars; lowercase alphanumeric/hyphens)."
  }
}

variable "consumer_app_type" {
  type        = string
  description = "Unity Deploy ENTRA_ID_APP_REGISTRATION APP_TYPE: oauth2_client_credentials | oauth2_auth_code | oauth2_on_behalf_of | oauth2_auth_code_pkce_browser (or prototype aliases: Service | WebApp | MiddleTierApi | SPA)"

  validation {
    condition = contains([
      "oauth2_client_credentials",
      "oauth2_auth_code",
      "oauth2_on_behalf_of",
      "oauth2_auth_code_pkce_browser",
      "Service",
      "WebApp",
      "MiddleTierApi",
      "SPA"
    ], var.consumer_app_type)
    error_message = "consumer_app_type must be one of the supported Phase 1 OAuth2 types: oauth2_client_credentials, oauth2_auth_code, oauth2_on_behalf_of, oauth2_auth_code_pkce_browser (saml and resource_api are not valid App-to-App consumers)."
  }
}

variable "consumer_sp_object_id" {
  type        = string
  description = "Consumer Service Principal Object ID (ENTRA_SERVICE_PRINCIPAL_OBJECT_ID output from ENTRA_ID_APP_REGISTRATION)"
}

variable "producer_sp_object_id" {
  type        = string
  description = "Producer Service Principal Object ID (ENTRA_SERVICE_PRINCIPAL_OBJECT_ID output from ENTRA_ID_APP_REGISTRATION)"
}

variable "requested_permissions" {
  type = set(string)
}

data "azuread_service_principal" "producer" {
  object_id = var.producer_sp_object_id
}

# Step 2 & 3 (Dry Run) and Step 4 (Live Run re-evaluation):
# Evaluates each requested permission against live Producer AppToAppAccess Custom Security Attributes
data "external" "policy_decision" {
  for_each = var.requested_permissions

  program = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "${path.module}/Evaluate-PolicyForTerraform.ps1"]

  query = {
    consumer_identity = var.consumer_identity
    consumer_app_type = var.consumer_app_type
    consumer_sp_id    = var.consumer_sp_object_id
    producer_sp_id    = var.producer_sp_object_id
    permission        = each.value
  }
}

locals {
  app_role_permissions = {
    for perm, res in data.external.policy_decision :
    perm => res.result if res.result.grant_type == "AppRole"
  }

  api_scope_permissions = {
    for perm, res in data.external.policy_decision :
    perm => res.result if res.result.grant_type == "ApiScope"
  }

  denied_permissions = {
    for perm, res in data.external.policy_decision :
    perm => res.result if res.result.decision != "ALLOW"
  }
}

# Case A: App Role Assignments (Client Credentials / Service consumers)
resource "azuread_app_role_assignment" "granted_roles" {
  for_each = local.app_role_permissions

  principal_object_id = var.consumer_sp_object_id
  resource_object_id  = var.producer_sp_object_id
  app_role_id         = data.azuread_service_principal.producer.app_role_ids[each.key]

  lifecycle {
    precondition {
      condition     = each.value.decision == "ALLOW"
      error_message = "DENIED [${each.key}] by ${each.value.deciding_rule}: ${each.value.reason} ${each.value.contact_guidance}"
    }
  }
}

# Case B: API Scope Admin Consent (WebApp / OBO / SPA consumers -> AllPrincipals)
resource "azuread_service_principal_delegated_permission_grant" "granted_scopes" {
  count = length(local.api_scope_permissions) > 0 ? 1 : 0

  service_principal_object_id          = var.consumer_sp_object_id
  resource_service_principal_object_id = var.producer_sp_object_id
  claim_values                         = keys(local.api_scope_permissions)

  lifecycle {
    precondition {
      condition     = length(local.denied_permissions) == 0
      error_message = "DENIED scope(s): ${join("; ", [for p, r in local.denied_permissions : "${p} (${r.deciding_rule}: ${r.reason})"])}"
    }
  }
}

# Step 5: Evidence output persisted in Unity Deploy / Terraform state
output "governance_evidence" {
  value = {
    for perm, res in data.external.policy_decision : perm => res.result
  }
}
