# Reference Terraform module showing how Unity Deploy (HashiCorp Terraform + azuread provider)
# integrates the AppToAppGovernance policy engine during `terraform plan` (Dry Run)
# and `terraform apply` (Live Run).

terraform {
  required_providers {
    azuread  = { source = "hashicorp/azuread", version = ">= 2.47.0" }
    external = { source = "hashicorp/external", version = ">= 2.3.0" }
  }
}

variable "consumer_identity" {
  type        = string
  description = "Consumer identity in APPID_project_component format (e.g. APP12540_portal_client-web)"
}

variable "consumer_app_type" {
  type        = string
  description = "Service | WebApp | MiddleTierApi | SPA"
}

variable "consumer_sp_object_id" {
  type = string
}

variable "producer_sp_object_id" {
  type = string
}

variable "requested_permissions" {
  type = set(string)
}

data "azuread_service_principal" "producer" {
  object_id = var.producer_sp_object_id
}

# Step 2 & 3 (Dry Run) and Step 4 (Live Run re-evaluation):
# Evaluates each requested permission against live Producer AppToAppAccess Custom Security Attributes
data "external" "policy_decision" {
  for_each = var.requested_permissions

  program = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "${path.module}/Evaluate-PolicyForTerraform.ps1"]

  query = {
    consumer_identity = var.consumer_identity
    consumer_app_type = var.consumer_app_type
    producer_sp_id    = var.producer_sp_object_id
    permission        = each.value
  }
}

locals {
  app_role_permissions = {
    for perm, res in data.external.policy_decision :
    perm => res.result if res.result.grant_type == "AppRole"
  }

  api_scope_permissions = {
    for perm, res in data.external.policy_decision :
    perm => res.result if res.result.grant_type == "ApiScope"
  }

  denied_permissions = {
    for perm, res in data.external.policy_decision :
    perm => res.result if res.result.decision != "ALLOW"
  }
}

# Case A: App Role Assignments (Client Credentials / Service consumers)
resource "azuread_app_role_assignment" "granted_roles" {
  for_each = local.app_role_permissions

  principal_object_id = var.consumer_sp_object_id
  resource_object_id  = var.producer_sp_object_id
  app_role_id         = data.azuread_service_principal.producer.app_role_ids[each.key]

  lifecycle {
    precondition {
      condition     = each.value.decision == "ALLOW"
      error_message = "DENIED [${each.key}] by ${each.value.deciding_rule}: ${each.value.reason} ${each.value.contact_guidance}"
    }
  }
}

# Case B: API Scope Admin Consent (WebApp / OBO / SPA consumers -> AllPrincipals)
resource "azuread_service_principal_delegated_permission_grant" "granted_scopes" {
  count = length(local.api_scope_permissions) > 0 ? 1 : 0

  service_principal_object_id          = var.consumer_sp_object_id
  resource_service_principal_object_id = var.producer_sp_object_id
  claim_values                         = keys(local.api_scope_permissions)

  lifecycle {
    precondition {
      condition     = length(local.denied_permissions) == 0
      error_message = "DENIED scope(s): ${join("; ", [for p, r in local.denied_permissions : "${p} (${r.deciding_rule}: ${r.reason})"])}"
    }
  }
}

# Step 5: Evidence output persisted in Unity Deploy / Terraform state
output "governance_evidence" {
  value = {
    for perm, res in data.external.policy_decision : perm => res.result
  }
}
