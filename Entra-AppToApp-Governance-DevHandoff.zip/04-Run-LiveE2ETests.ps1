#Requires -Version 5.1
<#
.SYNOPSIS
    End-to-End Live QA POC Test Runner against Microsoft Entra ID.
.DESCRIPTION
    Executes all Phase 1 QA POC scenarios from the RFC and security review:
      1. Shared Role + Scope definition check (already tested during Setup)
      2. Service consumer (Client Credentials) -> AppRole grant + LIVE JWT token claim check (roles & idtyp=app)
      3. WebApp & OBO consumers -> API Scope grant (oauth2PermissionGrant AllPrincipals) + DenyScope override
      4. Admin tier guardrails: exact Allow granted, wildcard Allow denied, SPA ALWAYS denied
      5. Attribute isolation: Allow (roles) never grants scopes; AllowScope never grants roles
      6. Legacy Producer: Default Allow for read/write, Admin blocked, then explicit Deny rule blocks access
      7. Reversal / Revocation: removing a declared dependency OR adding a producer Deny rule revokes live Entra grants
      8. Evidence artifacts generated for every run
#>
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
Import-Module (Join-Path $root 'modules\AppToAppGovernance.psm1') -Force
Import-Module (Join-Path $root 'modules\EntraGraphClient.psm1') -Force

$fixturePath = Join-Path $root 'state\dev-fixtures.json'
if (-not (Test-Path $fixturePath)) {
    throw "Fixture file not found at $fixturePath. Run 01-Setup-DevEntra.ps1 first."
}

$fixtures = Get-Content -Raw -Encoding UTF8 $fixturePath | ConvertFrom-Json
$ctx = Connect-GovernanceGraph
$suffix = [string]$fixtures.scopeSuffix

$passed = 0
$failed = 0

function Assert-Live {
    param(
        [string]$Name,
        [bool]$Condition,
        [string]$Details = ''
    )
    if ($Condition) {
        $script:passed++
        Write-Host "  [PASS] $Name" -ForegroundColor Green
    } else {
        $script:failed++
        Write-Host "  [FAIL] $Name $Details" -ForegroundColor Red
    }
}

Write-Host "`n==================================================================" -ForegroundColor Cyan
Write-Host "LIVE ENTRA ID END-TO-END QA POC SUITE" -ForegroundColor Cyan
Write-Host "Tenant: $($ctx.TenantId) | Admin: $($ctx.Account)" -ForegroundColor Cyan
Write-Host "Publish Strategy: $($fixtures.publishStrategyUsed) (scopeSuffix='$suffix')" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# Ensure clean baseline: Managed Producer rules synced, Legacy Producer has NO metadata
Write-Host "`n[Setup] Syncing Managed Producer rules & resetting Legacy Producer metadata..." -ForegroundColor Yellow
& (Join-Path $root '02-Sync-ProducerRules.ps1') -ConfigPath (Join-Path $root 'config\producer-managed.json') -Mode LiveRun
Clear-ProducerSpMetadata -ServicePrincipalId $fixtures.apps.legacyProducer.ServicePrincipalId

# Brief pause for Entra Custom Security Attribute replication
Start-Sleep -Seconds 3

# ------------------------------------------------------------------
# SCENARIO 1 & 2: Service Consumer (Client Credentials -> AppRole + JWT Token)
# ------------------------------------------------------------------
Write-Host "`n=== Scenario 1 & 2: Service Consumer (AppRole + Live JWT Verification) ===" -ForegroundColor Cyan
$evSvc = & (Join-Path $root '03-Invoke-ConsumerDeploy.ps1') -ConfigPath (Join-Path $root 'config\consumer-service.json') -Mode LiveRun

$svcManagedDecisions = @($evSvc.decisions | Where-Object { $_.ProducerAppId -eq $fixtures.apps.managedProducer.AppId })
$svcLegacyDecisions  = @($evSvc.decisions | Where-Object { $_.ProducerAppId -eq $fixtures.apps.legacyProducer.AppId })

Assert-Live 'Service -> Managed documents.read ALLOWED (wildcard Allow)' (($svcManagedDecisions | Where-Object { $_.Permission -eq 'documents.read' }).Decision -eq 'ALLOW')
Assert-Live 'Service -> Managed documents.write DENIED (explicit Deny)' (($svcManagedDecisions | Where-Object { $_.Permission -eq 'documents.write' }).Decision -eq 'DENY')
Assert-Live 'Service -> Managed documents.admin ALLOWED (exact Allow)' (($svcManagedDecisions | Where-Object { $_.Permission -eq 'documents.admin' }).Decision -eq 'ALLOW')
Assert-Live 'Service -> Legacy documents.read ALLOWED (Legacy Default Allow)' (($svcLegacyDecisions | Where-Object { $_.Permission -eq 'documents.read' }).Decision -eq 'ALLOW')
Assert-Live 'Service -> Legacy documents.admin DENIED (Admin blocked on Legacy)' (($svcLegacyDecisions | Where-Object { $_.Permission -eq 'documents.admin' }).Decision -eq 'DENY')

# Verify actual Entra ID AppRoleAssignments on Managed Producer
$svcGrants = Get-ConsumerGrantsForProducer -ConsumerSpId $fixtures.apps.serviceConsumer.ServicePrincipalId -ProducerSpId $fixtures.apps.managedProducer.ServicePrincipalId
Assert-Live 'Entra ID holds exactly 2 appRoleAssignments for Service -> Managed Producer' ($svcGrants.AppRoleAssignments.Count -eq 2)
Assert-Live 'Entra ID holds 0 oauth2PermissionGrants for Service consumer' ($null -eq $svcGrants.OAuth2PermissionGrant)

# Acquire REAL Client Credentials token and inspect JWT claims!
Write-Host '  [*] Creating temporary 7-day secret on Service Consumer to verify live Entra JWT claims...' -ForegroundColor Yellow
$secret = Add-AppClientSecret -AppObjectId $fixtures.apps.serviceConsumer.AppObjectId -DisplayName 'LiveE2EVerify'
# Wait for Entra secret & appRoleAssignment propagation
$claims = $null
for ($i = 1; $i -le 6; $i++) {
    Start-Sleep -Seconds 5
    try {
        $claims = Get-ClientCredentialsTokenClaims `
            -TenantId $ctx.TenantId `
            -ClientId $fixtures.apps.serviceConsumer.AppId `
            -ClientSecret $secret `
            -ProducerAppId $fixtures.apps.managedProducer.AppId
        if ($claims.PSObject.Properties['roles'] -and @($claims.roles).Count -ge 2) {
            break
        }
    } catch {
        Write-Host "    [retry $i/6] Waiting for secret propagation: $($_.Exception.Message)" -ForegroundColor DarkGray
    }
}

$tokenRoles = if ($claims -and $claims.PSObject.Properties['roles']) { @($claims.roles) } else { @() }
$tokenIdtyp = if ($claims -and $claims.PSObject.Properties['idtyp']) { [string]$claims.idtyp } else { '' }
Write-Host "  [*] Live JWT claims received -> idtyp='$tokenIdtyp' | roles=[$($tokenRoles -join ', ')] | azp=$($claims.azp)" -ForegroundColor White

Assert-Live 'Live Entra JWT contains documents.read in roles claim' ($tokenRoles -contains 'documents.read')
Assert-Live 'Live Entra JWT contains documents.admin in roles claim' ($tokenRoles -contains 'documents.admin')
Assert-Live 'Live Entra JWT does NOT contain denied documents.write' ($tokenRoles -notcontains 'documents.write')
Assert-Live 'Live Entra JWT contains idtyp=app optional claim' ($tokenIdtyp -eq 'app')

# ------------------------------------------------------------------
# SCENARIO 3: WebApp & MiddleTierApi (OBO) -> API Scopes (AllPrincipals)
# ------------------------------------------------------------------
Write-Host "`n=== Scenario 3: WebApp & OBO Consumers (API Scopes / Admin Consent) ===" -ForegroundColor Cyan
$evWeb = & (Join-Path $root '03-Invoke-ConsumerDeploy.ps1') -ConfigPath (Join-Path $root 'config\consumer-webapp.json') -Mode LiveRun
$evObo = & (Join-Path $root '03-Invoke-ConsumerDeploy.ps1') -ConfigPath (Join-Path $root 'config\consumer-obo.json') -Mode LiveRun

$webGrant = (Get-ConsumerGrantsForProducer -ConsumerSpId $fixtures.apps.webAppConsumer.ServicePrincipalId -ProducerSpId $fixtures.apps.managedProducer.ServicePrincipalId).OAuth2PermissionGrant
$webScopes = if ($webGrant) { @($webGrant['scope'].Trim() -split '\s+') } else { @() }
Assert-Live 'WebApp -> Managed oauth2PermissionGrant consentType=AllPrincipals' ($null -ne $webGrant -and $webGrant['consentType'] -eq 'AllPrincipals')
Assert-Live "WebApp granted documents.read$suffix and documents.admin$suffix" (($webScopes -contains "documents.read$suffix") -and ($webScopes -contains "documents.admin$suffix"))

$oboGrant = (Get-ConsumerGrantsForProducer -ConsumerSpId $fixtures.apps.oboConsumer.ServicePrincipalId -ProducerSpId $fixtures.apps.managedProducer.ServicePrincipalId).OAuth2PermissionGrant
$oboScopes = if ($oboGrant) { @($oboGrant['scope'].Trim() -split '\s+') } else { @() }
Assert-Live 'OBO -> Managed documents.read ALLOWED via wildcard AllowScope' ($oboScopes -contains "documents.read$suffix")
Assert-Live 'OBO -> Managed documents.write DENIED via DenyScope override' ($oboScopes -notcontains "documents.write$suffix")
Assert-Live 'OBO -> Managed documents.admin DENIED (wildcard AllowScope cannot grant Admin)' ($oboScopes -notcontains "documents.admin$suffix")

# ------------------------------------------------------------------
# SCENARIO 4: SPA Consumer (Admin ALWAYS blocked even with exact AllowScope!)
# ------------------------------------------------------------------
Write-Host "`n=== Scenario 4: SPA Consumer (Browser Admin Guardrail) ===" -ForegroundColor Cyan
$evSpa = & (Join-Path $root '03-Invoke-ConsumerDeploy.ps1') -ConfigPath (Join-Path $root 'config\consumer-spa.json') -Mode LiveRun
$spaGrant = (Get-ConsumerGrantsForProducer -ConsumerSpId $fixtures.apps.spaConsumer.ServicePrincipalId -ProducerSpId $fixtures.apps.managedProducer.ServicePrincipalId).OAuth2PermissionGrant
$spaScopes = if ($spaGrant) { @($spaGrant['scope'].Trim() -split '\s+') } else { @() }

Assert-Live 'SPA -> Managed documents.read ALLOWED' ($spaScopes -contains "documents.read$suffix")
Assert-Live 'SPA -> Managed documents.admin DENIED even with exact AllowScope' ($spaScopes -notcontains "documents.admin$suffix")

# ------------------------------------------------------------------
# SCENARIO 5 & 6: Legacy Producer Explicit Deny Rule + Revocation on Consumer Redeploy
# ------------------------------------------------------------------
Write-Host "`n=== Scenario 5 & 6: Legacy Producer Deny Rule + Revocation on Redeploy ===" -ForegroundColor Cyan
# Confirm WebApp currently has grant on Legacy Producer (from Default Allow)
$legGrantBefore = (Get-ConsumerGrantsForProducer -ConsumerSpId $fixtures.apps.webAppConsumer.ServicePrincipalId -ProducerSpId $fixtures.apps.legacyProducer.ServicePrincipalId).OAuth2PermissionGrant
Assert-Live 'Legacy Producer initially granted WebApp documents.read via Legacy Default Allow' ($null -ne $legGrantBefore -and $legGrantBefore['scope'] -match 'documents\.read')

# Now Identity team adds an explicit DenyScope rule to Legacy Producer (simulating ServiceNow request)
Write-Host '  [*] Adding explicit DenyScope rule to Legacy Producer (simulating ServiceNow ticket)...' -ForegroundColor Yellow
Set-ProducerSpMetadata -ServicePrincipalId $fixtures.apps.legacyProducer.ServicePrincipalId -Rules @{
    DenyScope = @('APP12540_portal_client-web:documents.read')
}
Start-Sleep -Seconds 3

# Re-run WebApp deploy -> should REVOKE the legacy grant automatically!
$evWebAfter = & (Join-Path $root '03-Invoke-ConsumerDeploy.ps1') -ConfigPath (Join-Path $root 'config\consumer-webapp.json') -Mode LiveRun
$legGrantAfter = (Get-ConsumerGrantsForProducer -ConsumerSpId $fixtures.apps.webAppConsumer.ServicePrincipalId -ProducerSpId $fixtures.apps.legacyProducer.ServicePrincipalId).OAuth2PermissionGrant
Assert-Live 'Legacy Producer DenyScope rule REVOKED WebApp grant on consumer redeploy' ($null -eq $legGrantAfter)

# ------------------------------------------------------------------
# SCENARIO 7: Revocation when Producer adds DenyAppRole for Service AppRole & Consumer Redeploys
# ------------------------------------------------------------------
Write-Host "`n=== Scenario 7: AppRole Revocation When Producer Adds DenyAppRole Rule ===" -ForegroundColor Cyan
Set-ProducerSpMetadata -ServicePrincipalId $fixtures.apps.managedProducer.ServicePrincipalId -Rules @{
    DefaultAppRole = 'Deny'
    AllowAppRole   = @('APP12301_*:documents.read', 'APP12301_ledger_nightly-export:documents.admin')
    DenyAppRole    = @('APP12301_ledger_nightly-export:documents.write', 'APP12301_ledger_nightly-export:documents.admin')
}
Start-Sleep -Seconds 3

$evSvcRevoke = & (Join-Path $root '03-Invoke-ConsumerDeploy.ps1') -ConfigPath (Join-Path $root 'config\consumer-service.json') -Mode LiveRun
$svcGrantsAfter = Get-ConsumerGrantsForProducer -ConsumerSpId $fixtures.apps.serviceConsumer.ServicePrincipalId -ProducerSpId $fixtures.apps.managedProducer.ServicePrincipalId
Assert-Live 'Service Consumer documents.admin AppRole REVOKED (now 1 assignment remaining)' ($svcGrantsAfter.AppRoleAssignments.Count -eq 1)

# Restore Managed Producer baseline & clear Legacy Producer metadata
Write-Host "`n[Cleanup] Restoring Managed Producer baseline rules & Legacy Producer clean state..." -ForegroundColor Yellow
& (Join-Path $root '02-Sync-ProducerRules.ps1') -ConfigPath (Join-Path $root 'config\producer-managed.json') -Mode LiveRun
Clear-ProducerSpMetadata -ServicePrincipalId $fixtures.apps.legacyProducer.ServicePrincipalId

Write-Host "`n==================================================================" -ForegroundColor Cyan
Write-Host "LIVE E2E QA POC SUMMARY: $passed passed, $failed failed" -ForegroundColor $(if ($failed -eq 0) { 'Green' } else { 'Red' })
Write-Host "==================================================================" -ForegroundColor Cyan

if ($failed -gt 0) { exit 1 }
