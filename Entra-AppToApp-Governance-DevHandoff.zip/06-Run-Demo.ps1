#Requires -Version 5.1
<#
.SYNOPSIS
    One-command stakeholder demo script for presenting the Entra ID App-to-App Governance Prototype
    to Identity, Enterprise Security, and the Unity Deploy team.
.DESCRIPTION
    Runs in ~45 seconds with clear narrated sections:
      1. Offline Policy Engine Unit Tests (40 cases)
      2. Producer Rule Sync (DryRun -> LiveRun) showing 50-value budget validation
      3. Consumer DryRun preview (showing zero Entra mutations + deciding rules)
      4. Full Live Entra ID E2E QA POC Suite (21 live assertions + real JWT roles/idtyp inspection)
      5. Prints exact Entra Admin Center blades to open during screen-share
#>
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
$fixturePath = Join-Path $root 'state\dev-fixtures.json'

Write-Host "`n##########################################################################" -ForegroundColor Cyan
Write-Host "#  DEMO: Entra ID App-to-App Permission Governance Prototype (Phase 1)   #" -ForegroundColor Cyan
Write-Host "##########################################################################`n" -ForegroundColor Cyan

Write-Host '>>> STEP 1: Offline Policy Engine Unit Tests (No Entra calls)' -ForegroundColor Yellow
& (Join-Path $root 'tests\Invoke-UnitTests.ps1')

if (-not (Test-Path $fixturePath)) {
    Write-Host "`n>>> STEP 2: Running Initial DEV Entra ID Setup (One-time)..." -ForegroundColor Yellow
    & (Join-Path $root '01-Setup-DevEntra.ps1')
}

Write-Host "`n>>> STEP 2: Producer Rule Sync [DryRun] (Pre-flight naming & 50-value budget check)" -ForegroundColor Yellow
& (Join-Path $root '02-Sync-ProducerRules.ps1') -ConfigPath (Join-Path $root 'config\producer-managed.json') -Mode DryRun

Write-Host "`n>>> STEP 3: Consumer Unity Deploy Simulation [DryRun] (SPA Consumer - shows Admin blocked)" -ForegroundColor Yellow
& (Join-Path $root '03-Invoke-ConsumerDeploy.ps1') -ConfigPath (Join-Path $root 'config\consumer-spa.json') -Mode DryRun | Out-Null

Write-Host "`n>>> STEP 4: Full Live Entra ID End-to-End QA POC Suite (All 4 APP_TYPEs, Legacy, Revocation, Live JWT)" -ForegroundColor Yellow
& (Join-Path $root '04-Run-LiveE2ETests.ps1')

$fixtures = Get-Content -Raw -Encoding UTF8 $fixturePath | ConvertFrom-Json
Write-Host "`n##########################################################################" -ForegroundColor Green
Write-Host "#  DEMO COMPLETE - WHERE TO SHOW RESULTS IN ENTRA ADMIN CENTER           #" -ForegroundColor Green
Write-Host "##########################################################################" -ForegroundColor Green
Write-Host "1. Custom Security Attributes Schema:"
Write-Host "   Entra Admin Center -> Protection -> Custom security attributes -> 'AppToAppAccess'"
Write-Host "   (Verify DefaultAppRole/DefaultScope = Single value; AllowAppRole/DenyAppRole/AllowScope/DenyScope = Multiple values)"
Write-Host ""
Write-Host "2. Producer Rules Stored Tamper-Resistantly on Service Principal:"
Write-Host "   Enterprise Applications -> '$($fixtures.apps.managedProducer.DisplayName)' -> Custom security attributes"
Write-Host ""
Write-Host "3. Mirrored App Roles + Admin-Consent API Scopes on Producer:"
Write-Host "   App Registrations -> '$($fixtures.apps.managedProducer.DisplayName)' -> 'App roles' & 'Expose an API'"
Write-Host ""
Write-Host "4. Automated AppRole Assignments & Tenant-Wide Admin Consent (AllPrincipals):"
Write-Host "   - Enterprise Applications -> '$($fixtures.apps.serviceConsumer.DisplayName)' -> Permissions"
Write-Host "   - Enterprise Applications -> '$($fixtures.apps.webAppConsumer.DisplayName)'  -> Permissions"
Write-Host "   - Enterprise Applications -> '$($fixtures.apps.spaConsumer.DisplayName)'     -> Permissions (no admin!)"
Write-Host ""
Write-Host "5. Optional Live Delegated User Token ('scp' claim) Test:"
Write-Host "   Run: .\05-Test-DelegatedScopeToken.ps1 -ConsumerKey spaConsumer"
Write-Host ""
Write-Host "6. Audit Evidence Artifacts (Step 5):"
Write-Host "   Folder: $(Join-Path $root 'evidence')"
