#Requires -Version 5.1
<#
.SYNOPSIS
    Zero-dependency Microsoft Graph v1.0 REST client for the Entra ID App-to-App Governance Prototype.
.DESCRIPTION
    Uses native Invoke-RestMethod (works identically in Windows PowerShell 5.1, PowerShell 7+, and CI runners).
    Supports:
      - OAuth 2.0 Device Code flow with DPAPI-encrypted refresh token cache (CurrentUser scope)
      - Silent token refresh (so role assignment refresh and subsequent scripts require zero re-prompts)
      - Service Principal (Client Credentials) auth via AZURE_TENANT_ID / AZURE_CLIENT_ID / AZURE_CLIENT_SECRET for CI/CD
#>

Set-StrictMode -Version Latest

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue

$script:AttributeSetName = 'AppToAppAccess'
$script:GraphPublicClientId = '14d82eec-204b-4c2f-b7e8-296a70dab67e' # Microsoft Graph Command Line Tools
$script:RoleTemplate_AttrDefAdmin    = '8424c6f0-a189-499e-bbd0-26c1753c96d4'
$script:RoleTemplate_AttrAssignAdmin = '58a13ea3-c632-46ae-9ee0-9c0d43cd7f3d'
$script:RoleTemplate_AttrAssignReader = 'ffd52fa5-98dc-465c-991d-fc073eb59f8f'

$script:RequiredScopes = @(
    'offline_access',
    'openid',
    'profile',
    'Application.ReadWrite.All',
    'AppRoleAssignment.ReadWrite.All',
    'DelegatedPermissionGrant.ReadWrite.All',
    'CustomSecAttributeDefinition.ReadWrite.All',
    'CustomSecAttributeAssignment.ReadWrite.All',
    'RoleManagement.ReadWrite.Directory',
    'Directory.Read.All'
)

$script:TokenCachePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'state\.token-cache.dat'
$script:CurrentSession = $null
$script:AttributeReadVerified = $false

function Test-IsWindowsPlatform {
    return ($env:OS -eq 'Windows_NT' -or [System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT)
}

function ConvertTo-DeepHashtable {
    param($InputObject)
    if ($null -eq $InputObject) { return $null }
    if ($InputObject -is [System.Collections.IDictionary]) {
        $ht = @{}
        foreach ($k in $InputObject.Keys) { $ht[$k] = ConvertTo-DeepHashtable $InputObject[$k] }
        return $ht
    }
    if ($InputObject -is [PSCustomObject]) {
        $ht = @{}
        foreach ($p in $InputObject.PSObject.Properties) {
            $ht[$p.Name] = ConvertTo-DeepHashtable $p.Value
        }
        return $ht
    }
    if ($InputObject -is [System.Collections.IEnumerable] -and -not ($InputObject -is [string])) {
        $list = New-Object System.Collections.Generic.List[object]
        foreach ($item in $InputObject) { $list.Add((ConvertTo-DeepHashtable $item)) }
        return ,$list.ToArray()
    }
    return $InputObject
}

function Decode-JwtPayload {
    param([string]$Jwt)
    $parts = $Jwt.Split('.')
    $payloadB64 = $parts[1].Replace('-', '+').Replace('_', '/')
    switch ($payloadB64.Length % 4) {
        2 { $payloadB64 += '==' }
        3 { $payloadB64 += '=' }
    }
    $json = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($payloadB64))
    return ($json | ConvertFrom-Json)
}

function Save-TokenCache {
    param([hashtable]$CacheData)
    # DPAPI ProtectedData is Windows-only; skip disk cache gracefully on Linux/macOS pwsh runners
    if (-not (Test-IsWindowsPlatform)) {
        return
    }
    try {
        $dir = Split-Path -Parent $script:TokenCachePath
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
        $jsonBytes = [System.Text.Encoding]::UTF8.GetBytes(($CacheData | ConvertTo-Json -Depth 5))
        $protected = [System.Security.Cryptography.ProtectedData]::Protect($jsonBytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        [System.IO.File]::WriteAllBytes($script:TokenCachePath, $protected)
    } catch {
        Write-Verbose "Skipping disk token cache write: $($_.Exception.Message)"
    }
}

function Load-TokenCache {
    if (-not (Test-IsWindowsPlatform)) { return $null }
    if (-not (Test-Path $script:TokenCachePath)) { return $null }
    try {
        $protected = [System.IO.File]::ReadAllBytes($script:TokenCachePath)
        $jsonBytes = [System.Security.Cryptography.ProtectedData]::Unprotect($protected, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        $json = [System.Text.Encoding]::UTF8.GetString($jsonBytes)
        return (ConvertTo-DeepHashtable ($json | ConvertFrom-Json))
    } catch {
        return $null
    }
}

function Get-HttpErrorDetails {
    param($ErrorRecord)
    $msg = $ErrorRecord.Exception.Message
    try {
        if ($null -ne $ErrorRecord.ErrorDetails -and -not [string]::IsNullOrWhiteSpace($ErrorRecord.ErrorDetails.Message)) {
            return "$msg | Body: $($ErrorRecord.ErrorDetails.Message)"
        }
    } catch { }
    try {
        if ($ErrorRecord.Exception.PSObject.Properties['Response'] -and $null -ne $ErrorRecord.Exception.Response) {
            $stream = $ErrorRecord.Exception.Response.GetResponseStream()
            if ($null -ne $stream) {
                $reader = New-Object System.IO.StreamReader($stream)
                $bodyText = $reader.ReadToEnd()
                $reader.Close()
                if (-not [string]::IsNullOrWhiteSpace($bodyText)) {
                    return "$msg | Body: $bodyText"
                }
            }
        }
    } catch { }
    return $msg
}

function Connect-GovernanceGraph {
    [CmdletBinding()]
    param(
        [switch]$ForceRefresh,
        [switch]$UseDeviceCode,
        [string]$TenantId = ''
    )

    $scopeStr = $script:RequiredScopes -join ' '
    $pinnedTenant = if (-not [string]::IsNullOrWhiteSpace($TenantId)) { $TenantId.Trim() } elseif ($env:AZURE_TENANT_ID) { $env:AZURE_TENANT_ID.Trim() } else { '' }
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()

    # 0. Pre-acquired bearer token (e.g., from az account get-access-token / browser WAM when Device Code is blocked by CA)
    if (-not [string]::IsNullOrWhiteSpace($env:GRAPH_ACCESS_TOKEN)) {
        $claims = Decode-JwtPayload -Jwt $env:GRAPH_ACCESS_TOKEN
        if (-not [string]::IsNullOrWhiteSpace($pinnedTenant) -and $claims.tid -ne $pinnedTenant) {
            throw "GRAPH_ACCESS_TOKEN belongs to tenant '$($claims.tid)', expected pinned tenant '$pinnedTenant'."
        }
        $oid = if ($claims.PSObject.Properties['oid']) { [string]$claims.oid } else { '' }
        $acct = if ($claims.PSObject.Properties['upn']) { [string]$claims.upn } elseif ($claims.PSObject.Properties['unique_name']) { [string]$claims.unique_name } elseif ($claims.PSObject.Properties['appid']) { "SP:$($claims.appid)" } else { 'PreAcquiredToken' }
        $script:CurrentSession = [PSCustomObject]@{
            AccessToken = $env:GRAPH_ACCESS_TOKEN
            Account     = $acct
            TenantId    = [string]$claims.tid
            ObjectId    = $oid
            ExpiresAt   = [int64]$claims.exp
            AuthType    = 'PreAcquiredToken'
        }
        $script:AttributeReadVerified = $false
        return $script:CurrentSession
    }

    # 1a. CI/CD Workload Identity Federation / Certificate client_assertion (preferred per RFC risk assessment)
    $clientAssertion = ''
    if (-not [string]::IsNullOrWhiteSpace($env:AZURE_FEDERATED_TOKEN)) {
        $clientAssertion = $env:AZURE_FEDERATED_TOKEN.Trim()
    } elseif (-not [string]::IsNullOrWhiteSpace($env:AZURE_FEDERATED_TOKEN_FILE) -and (Test-Path $env:AZURE_FEDERATED_TOKEN_FILE)) {
        $clientAssertion = (Get-Content -Raw -Encoding UTF8 $env:AZURE_FEDERATED_TOKEN_FILE).Trim()
    } elseif (-not [string]::IsNullOrWhiteSpace($env:AZURE_CLIENT_ASSERTION)) {
        $clientAssertion = $env:AZURE_CLIENT_ASSERTION.Trim()
    }

    if ($pinnedTenant -and $env:AZURE_CLIENT_ID -and $clientAssertion) {
        if (-not $ForceRefresh -and $null -ne $script:CurrentSession -and $script:CurrentSession.TenantId -eq $pinnedTenant -and $script:CurrentSession.ExpiresAt -gt ($now + 120)) {
            return $script:CurrentSession
        }
        $tokenResp = Invoke-RestMethod -Method POST `
            -Uri "https://login.microsoftonline.com/$pinnedTenant/oauth2/v2.0/token" `
            -Body @{
                client_id             = $env:AZURE_CLIENT_ID
                client_assertion_type = 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
                client_assertion      = $clientAssertion
                scope                 = 'https://graph.microsoft.com/.default'
                grant_type            = 'client_credentials'
            } -ContentType 'application/x-www-form-urlencoded'
        $claims = Decode-JwtPayload -Jwt $tokenResp.access_token
        $script:CurrentSession = [PSCustomObject]@{
            AccessToken = $tokenResp.access_token
            Account     = "SP:$($env:AZURE_CLIENT_ID)"
            TenantId    = [string]$claims.tid
            ObjectId    = if ($claims.PSObject.Properties['oid']) { [string]$claims.oid } else { '' }
            ExpiresAt   = [int64]$claims.exp
            AuthType    = 'ClientAssertion'
        }
        $script:AttributeReadVerified = $false
        return $script:CurrentSession
    }

    # 1b. CI/CD Service Principal Client Secret fallback (DEV / prototype convenience)
    if ($pinnedTenant -and $env:AZURE_CLIENT_ID -and $env:AZURE_CLIENT_SECRET) {
        if (-not $ForceRefresh -and $null -ne $script:CurrentSession -and $script:CurrentSession.TenantId -eq $pinnedTenant -and $script:CurrentSession.ExpiresAt -gt ($now + 120)) {
            return $script:CurrentSession
        }
        $tokenResp = Invoke-RestMethod -Method POST `
            -Uri "https://login.microsoftonline.com/$pinnedTenant/oauth2/v2.0/token" `
            -Body @{
                client_id     = $env:AZURE_CLIENT_ID
                client_secret = $env:AZURE_CLIENT_SECRET
                scope         = 'https://graph.microsoft.com/.default'
                grant_type    = 'client_credentials'
            } -ContentType 'application/x-www-form-urlencoded'
        $claims = Decode-JwtPayload -Jwt $tokenResp.access_token
        $script:CurrentSession = [PSCustomObject]@{
            AccessToken = $tokenResp.access_token
            Account     = "SP:$($env:AZURE_CLIENT_ID)"
            TenantId    = [string]$claims.tid
            ObjectId    = if ($claims.PSObject.Properties['oid']) { [string]$claims.oid } else { '' }
            ExpiresAt   = [int64]$claims.exp
            AuthType    = 'ClientCredentials'
        }
        $script:AttributeReadVerified = $false
        return $script:CurrentSession
    }

    # 2. Check in-memory session (respecting pinned tenant if specified)
    if (-not $ForceRefresh -and -not $UseDeviceCode -and $null -ne $script:CurrentSession -and $script:CurrentSession.ExpiresAt -gt ($now + 120)) {
        if ([string]::IsNullOrWhiteSpace($pinnedTenant) -or $script:CurrentSession.TenantId -eq $pinnedTenant) {
            return $script:CurrentSession
        }
    }

    # 3. Check Windows DPAPI-encrypted disk cache (and refresh silently via refresh_token)
    $cached = Load-TokenCache
    if ($null -ne $cached -and -not $UseDeviceCode) {
        $cacheTenantMatch = ([string]::IsNullOrWhiteSpace($pinnedTenant) -or ($cached.ContainsKey('tenantId') -and $cached['tenantId'] -eq $pinnedTenant))
        if ($cacheTenantMatch) {
            if (-not $ForceRefresh -and $cached.ContainsKey('expiresAt') -and [int64]$cached['expiresAt'] -gt ($now + 120)) {
                $cachedClaims = Decode-JwtPayload -Jwt $cached['accessToken']
                $script:CurrentSession = [PSCustomObject]@{
                    AccessToken = $cached['accessToken']
                    Account     = $cached['account']
                    TenantId    = [string]$cached['tenantId']
                    ObjectId    = if ($cachedClaims.PSObject.Properties['oid']) { [string]$cachedClaims.oid } else { '' }
                    ExpiresAt   = [int64]$cached['expiresAt']
                    AuthType    = 'DelegatedCached'
                }
                return $script:CurrentSession
            }

            if ($cached.ContainsKey('refreshToken') -and -not [string]::IsNullOrWhiteSpace($cached['refreshToken'])) {
                try {
                    $tid = if (-not [string]::IsNullOrWhiteSpace($pinnedTenant)) { $pinnedTenant } elseif ($cached.ContainsKey('tenantId') -and $cached['tenantId']) { $cached['tenantId'] } else { 'organizations' }
                    $refResp = Invoke-RestMethod -Method POST `
                        -Uri "https://login.microsoftonline.com/$tid/oauth2/v2.0/token" `
                        -Body @{
                            client_id     = $script:GraphPublicClientId
                            grant_type    = 'refresh_token'
                            refresh_token = $cached['refreshToken']
                            scope         = $scopeStr
                        } -ContentType 'application/x-www-form-urlencoded'

                    $claims = Decode-JwtPayload -Jwt $refResp.access_token
                    $account = if ($claims.PSObject.Properties['upn']) { $claims.upn } elseif ($claims.PSObject.Properties['unique_name']) { $claims.unique_name } else { $cached['account'] }
                    $newRefresh = if ($refResp.PSObject.Properties['refresh_token'] -and $refResp.refresh_token) { $refResp.refresh_token } else { $cached['refreshToken'] }

                    Save-TokenCache @{
                        accessToken  = $refResp.access_token
                        refreshToken = $newRefresh
                        account      = $account
                        tenantId     = $claims.tid
                        expiresAt    = [int64]$claims.exp
                    }

                    $script:CurrentSession = [PSCustomObject]@{
                        AccessToken = $refResp.access_token
                        Account     = $account
                        TenantId    = [string]$claims.tid
                        ObjectId    = if ($claims.PSObject.Properties['oid']) { [string]$claims.oid } else { '' }
                        ExpiresAt   = [int64]$claims.exp
                        AuthType    = 'DelegatedRefreshed'
                    }
                    $script:AttributeReadVerified = $false
                    return $script:CurrentSession
                } catch {
                    [Console]::Out.WriteLine("  [*] Cached refresh token expired or rejected; starting Device Code login...")
                    [Console]::Out.Flush()
                }
            }
        }
    }

    # 4. Interactive OAuth 2.0 Device Code Flow (DEV fallback; pinned to -TenantId when provided)
    $authTenant = if (-not [string]::IsNullOrWhiteSpace($pinnedTenant)) { $pinnedTenant } else { 'organizations' }
    $dcResp = Invoke-RestMethod -Method POST `
        -Uri "https://login.microsoftonline.com/$authTenant/oauth2/v2.0/devicecode" `
        -Body @{
            client_id = $script:GraphPublicClientId
            scope     = $scopeStr
        } -ContentType 'application/x-www-form-urlencoded'

    [Console]::Out.WriteLine('')
    [Console]::Out.WriteLine($dcResp.message)
    [Console]::Out.WriteLine('')
    [Console]::Out.Flush()

    $interval = if ($dcResp.interval) { [int]$dcResp.interval } else { 5 }
    $deadline = (Get-Date).AddSeconds([int]$dcResp.expires_in)

    $tokenResp = $null
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds $interval
        try {
            $tokenResp = Invoke-RestMethod -Method POST `
                -Uri "https://login.microsoftonline.com/$authTenant/oauth2/v2.0/token" `
                -Body @{
                    grant_type  = 'urn:ietf:params:oauth:grant-type:device_code'
                    client_id   = $script:GraphPublicClientId
                    device_code = $dcResp.device_code
                } -ContentType 'application/x-www-form-urlencoded'
            break
        } catch {
            $detail = Get-HttpErrorDetails $_
            if ($detail -match 'authorization_pending') {
                continue
            } elseif ($detail -match 'slow_down') {
                $interval += 5
                continue
            } else {
                throw "Device code authentication failed: $detail"
            }
        }
    }

    if ($null -eq $tokenResp) {
        throw 'Device code authentication timed out.'
    }

    $claims = Decode-JwtPayload -Jwt $tokenResp.access_token
    if (-not [string]::IsNullOrWhiteSpace($pinnedTenant) -and $claims.tid -ne $pinnedTenant) {
        throw "Signed in to tenant '$($claims.tid)', expected pinned tenant '$pinnedTenant'."
    }
    $account = if ($claims.PSObject.Properties['upn']) { $claims.upn } elseif ($claims.PSObject.Properties['unique_name']) { $claims.unique_name } else { 'unknown' }

    Save-TokenCache @{
        accessToken  = $tokenResp.access_token
        refreshToken = $tokenResp.refresh_token
        account      = $account
        tenantId     = $claims.tid
        expiresAt    = [int64]$claims.exp
    }

    $script:CurrentSession = [PSCustomObject]@{
        AccessToken = $tokenResp.access_token
        Account     = $account
        TenantId    = [string]$claims.tid
        ObjectId    = if ($claims.PSObject.Properties['oid']) { [string]$claims.oid } else { '' }
        ExpiresAt   = [int64]$claims.exp
        AuthType    = 'DeviceCode'
    }
    $script:AttributeReadVerified = $false
    return $script:CurrentSession
}

function Invoke-Graph {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet('GET', 'POST', 'PATCH', 'PUT', 'DELETE')]
        [string]$Method,

        [Parameter(Mandatory = $true)]
        [string]$Uri,

        [Parameter(Mandatory = $false)]
        $Body = $null
    )

    $session = Connect-GovernanceGraph
    $headers = @{
        Authorization = "Bearer $($session.AccessToken)"
        Accept        = 'application/json'
    }

    $params = @{
        Method  = $Method
        Uri     = $Uri
        Headers = $headers
    }

    if ($null -ne $Body) {
        $json = if ($Body -is [string]) { $Body } else { ($Body | ConvertTo-Json -Depth 12) }
        $params['Body'] = [System.Text.Encoding]::UTF8.GetBytes($json)
        $params['ContentType'] = 'application/json; charset=utf-8'
    }

    try {
        $resp = Invoke-RestMethod @params
        if ($null -eq $resp -or $resp -eq '') { return @{} }
        return (ConvertTo-DeepHashtable $resp)
    } catch {
        $detail = Get-HttpErrorDetails $_
        throw "Graph $Method $Uri failed: $detail"
    }
}

function Initialize-AttributeAdminRoles {
    <#
    .SYNOPSIS
        Ensures the signed-in admin holds Attribute Definition Administrator (tenant scope '/')
        and Attribute Assignment Administrator (scoped strictly to '/attributeSets/AppToAppAccess' per RFC).
    .DESCRIPTION
        Use -DefinitionOnly BEFORE creating the AppToAppAccess attribute set on a brand-new tenant,
        then -AssignmentOnly AFTER creating the set so Entra ID accepts the '/attributeSets/AppToAppAccess' scope.
    #>
    [CmdletBinding()]
    param(
        [switch]$DefinitionOnly,
        [switch]$AssignmentOnly
    )

    $session = Connect-GovernanceGraph
    if ($session.AuthType -in @('ClientCredentials', 'ClientAssertion')) {
        Write-Host "  [*] Service Principal ($($session.AuthType)) auth detected; skipping /me role check (ensure SP holds scoped Attribute Assignment Admin role)." -ForegroundColor Yellow
        return [PSCustomObject]@{
            UserId      = $session.ObjectId
            Upn         = $session.Account
            AssignedNew = $false
        }
    }

    $me = Invoke-Graph -Method GET -Uri 'https://graph.microsoft.com/v1.0/me?$select=id,userPrincipalName'
    $myId = $me['id']
    $myUpn = $me['userPrincipalName']

    $existing = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments?`$filter=principalId eq '$myId'"
    $existingAssignments = @()
    if ($existing.ContainsKey('value') -and $null -ne $existing['value']) {
        $existingAssignments = @($existing['value'])
    }

    $assignedNew = $false
    $rolesToEnsure = @()
    if (-not $AssignmentOnly) {
        $rolesToEnsure += @{ Name = 'Attribute Definition Administrator'; Id = $script:RoleTemplate_AttrDefAdmin; Scope = '/' }
    }
    if (-not $DefinitionOnly) {
        $rolesToEnsure += @{ Name = 'Attribute Assignment Administrator'; Id = $script:RoleTemplate_AttrAssignAdmin; Scope = "/attributeSets/$($script:AttributeSetName)" }
    }

    foreach ($r in $rolesToEnsure) {
        $alreadyHeld = (@($existingAssignments | Where-Object {
            $_['roleDefinitionId'] -eq $r.Id -and ($_['directoryScopeId'] -eq $r.Scope -or $_['directoryScopeId'] -eq '/')
        }).Count -gt 0)

        if ($alreadyHeld) {
            Write-Host "  [OK] $myUpn already holds '$($r.Name)' covering '$($r.Scope)'" -ForegroundColor Green
        } else {
            Write-Host "  [+] Assigning '$($r.Name)' to $myUpn on scope '$($r.Scope)' ..." -ForegroundColor Yellow
            $body = @{
                '@odata.type'    = '#microsoft.graph.unifiedRoleAssignment'
                roleDefinitionId = $r.Id
                principalId      = $myId
                directoryScopeId = $r.Scope
            }
            Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments' -Body $body | Out-Null
            $assignedNew = $true
        }
    }

    return [PSCustomObject]@{
        UserId      = $myId
        Upn         = $myUpn
        AssignedNew = $assignedNew
    }
}

function Assert-AttributeReadAccess {
    <#
    .SYNOPSIS
        Fail-closed preflight check verifying the active caller can actually read AppToAppAccess Custom Security Attributes.
    .DESCRIPTION
        Microsoft Graph silently returns customSecurityAttributes = null (HTTP 200) when the caller lacks
        CustomSecAttributeAssignment.Read(.Write).All or the Attribute Assignment Reader/Administrator Entra role.
        Without this preflight check, a managed producer with Default=Deny could be misclassified as Legacy.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$SentinelServicePrincipalId = '',

        [switch]$Force
    )

    if ($script:AttributeReadVerified -and -not $Force) {
        return $true
    }

    $session = Connect-GovernanceGraph
    $claims = Decode-JwtPayload -Jwt $session.AccessToken

    # 1. Verify token permission claim (roles for app-only, scp for delegated)
    $grantedPerms = @()
    if ($claims.PSObject.Properties['roles'] -and $null -ne $claims.roles) {
        $grantedPerms += @($claims.roles)
    }
    if ($claims.PSObject.Properties['scp'] -and -not [string]::IsNullOrWhiteSpace([string]$claims.scp)) {
        $grantedPerms += @(([string]$claims.scp).Trim() -split '\s+')
    }

    $hasGraphPerm = ($grantedPerms -contains 'CustomSecAttributeAssignment.Read.All') -or ($grantedPerms -contains 'CustomSecAttributeAssignment.ReadWrite.All')
    if (-not $hasGraphPerm) {
        throw "PREFLIGHT FAILED: Active Graph token for '$($session.Account)' lacks 'CustomSecAttributeAssignment.Read.All' or 'CustomSecAttributeAssignment.ReadWrite.All'. Stopping fail-closed to prevent misreading managed producers as Legacy."
    }

    # 2. Verify Entra RBAC access via Sentinel SP (if configured) OR scoped directory role assignment
    $sentinelId = if (-not [string]::IsNullOrWhiteSpace($SentinelServicePrincipalId)) { $SentinelServicePrincipalId.Trim() } elseif ($env:UNITY_SENTINEL_SP_ID) { $env:UNITY_SENTINEL_SP_ID.Trim() } else { '' }
    if (-not [string]::IsNullOrWhiteSpace($sentinelId)) {
        $sentinelSp = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$sentinelId`?`$select=id,displayName,customSecurityAttributes"
        $attrs = if ($sentinelSp.ContainsKey('customSecurityAttributes')) { $sentinelSp['customSecurityAttributes'] } else { $null }
        if ($null -eq $attrs -or -not ($attrs -is [hashtable]) -or -not $attrs.ContainsKey($script:AttributeSetName)) {
            throw "PREFLIGHT FAILED: Sentinel service principal '$sentinelId' returned null/missing '$($script:AttributeSetName)' customSecurityAttributes. Caller '$($session.Account)' likely lacks Attribute Assignment Reader/Administrator."
        }
        $script:AttributeReadVerified = $true
        return $true
    }

    $callerOid = $session.ObjectId
    if ([string]::IsNullOrWhiteSpace($callerOid) -and $claims.PSObject.Properties['oid']) {
        $callerOid = [string]$claims.oid
    }
    if ([string]::IsNullOrWhiteSpace($callerOid)) {
        throw "PREFLIGHT FAILED: Could not determine caller object ID (oid) from Graph token to verify Attribute Assignment Reader/Administrator role assignment."
    }

    $attrScope = "/attributeSets/$($script:AttributeSetName)"
    $validRoleIds = @($script:RoleTemplate_AttrAssignAdmin, $script:RoleTemplate_AttrAssignReader)
    $validScopes = @('/', $attrScope)

    $raRes = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments?`$filter=principalId eq '$callerOid'"
    $hasRole = $false
    if ($raRes.ContainsKey('value') -and $null -ne $raRes['value']) {
        $hasRole = (@($raRes['value'] | Where-Object {
            ($validRoleIds -contains $_['roleDefinitionId']) -and ($validScopes -contains $_['directoryScopeId'])
        }).Count -gt 0)
    }

    if (-not $hasRole) {
        throw "PREFLIGHT FAILED: Caller '$($session.Account)' (oid=$callerOid) does not hold 'Attribute Assignment Administrator' or 'Attribute Assignment Reader' on '/' or '$attrScope'. Stopping fail-closed to prevent misreading managed producers as Legacy."
    }

    $script:AttributeReadVerified = $true
    return $true
}

function Get-AppToAppAccessSchemaDefinition {
    <#
    .SYNOPSIS
        Returns the canonical RFC Phase 1 Custom Security Attribute definitions for AppToAppAccess.
        Shared by Initialize-AppToAppAccessSchema and 00-Create-Schema-For-QA-PROD.ps1.
    #>
    [CmdletBinding()]
    param()

    $defaultAllowedValues = @(
        @{ id = 'Allow'; isActive = $true },
        @{ id = 'Deny';  isActive = $true }
    )

    return @(
        @{ name = 'DefaultAppRole'; isCollection = $false; usePreDefinedValuesOnly = $true;  allowedValues = $defaultAllowedValues; description = 'Default posture for App Roles (Allow or Deny)' },
        @{ name = 'AllowAppRole';   isCollection = $true;  usePreDefinedValuesOnly = $false; allowedValues = $null;                 description = 'Allow rules for App Roles (APPID_project_component:resource.verb)' },
        @{ name = 'DenyAppRole';    isCollection = $true;  usePreDefinedValuesOnly = $false; allowedValues = $null;                 description = 'Deny rules for App Roles (overrides AllowAppRole and DefaultAppRole)' },
        @{ name = 'DefaultScope';   isCollection = $false; usePreDefinedValuesOnly = $true;  allowedValues = $defaultAllowedValues; description = 'Default posture for API Scopes (Allow or Deny)' },
        @{ name = 'AllowScope';     isCollection = $true;  usePreDefinedValuesOnly = $false; allowedValues = $null;                 description = 'Allow rules for API Scopes (APPID_project_component:resource.verb)' },
        @{ name = 'DenyScope';      isCollection = $true;  usePreDefinedValuesOnly = $false; allowedValues = $null;                 description = 'Deny rules for API Scopes (overrides AllowScope and DefaultScope)' }
    )
}

function Initialize-AppToAppAccessSchema {
    <#
    .SYNOPSIS
        Idempotently creates the AppToAppAccess Custom Security Attribute Set and all 6 RFC definitions.
        CRITICAL: AllowAppRole, DenyAppRole, AllowScope, DenyScope MUST be created with isCollection = $true (irreversible),
        and DefaultAppRole / DefaultScope MUST be created with usePreDefinedValuesOnly = $true (cannot change false -> true).
    #>
    [CmdletBinding()]
    param()

    # 1. Attribute Set
    $sets = Invoke-Graph -Method GET -Uri 'https://graph.microsoft.com/v1.0/directory/attributeSets'
    $setExists = $false
    if ($sets.ContainsKey('value') -and $null -ne $sets['value']) {
        $setExists = (@($sets['value'] | Where-Object { $_['id'] -eq $script:AttributeSetName }).Count -gt 0)
    }

    if ($setExists) {
        Write-Host "  [OK] Attribute Set '$($script:AttributeSetName)' already exists." -ForegroundColor Green
    } else {
        Write-Host "  [+] Creating Attribute Set '$($script:AttributeSetName)' ..." -ForegroundColor Yellow
        $setBody = @{
            id                  = $script:AttributeSetName
            description         = 'Producer-governed App-to-App permission rules (RFC Phase 1)'
            maxAttributesPerSet = 6
        }
        Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/directory/attributeSets' -Body $setBody | Out-Null
    }

    # 2. Six Attribute Definitions
    $defs = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/directory/customSecurityAttributeDefinitions?`$filter=attributeSet eq '$($script:AttributeSetName)'"
    $existingDefs = @{}
    if ($defs.ContainsKey('value') -and $null -ne $defs['value']) {
        foreach ($d in @($defs['value'])) {
            $existingDefs[$d['name']] = $d
        }
    }

    $requiredDefs = Get-AppToAppAccessSchemaDefinition

    foreach ($rd in $requiredDefs) {
        if ($existingDefs.ContainsKey($rd.name)) {
            $cur = $existingDefs[$rd.name]
            if ([bool]$cur['isCollection'] -ne [bool]$rd.isCollection) {
                throw "SCHEMA MISMATCH: Attribute '$($rd.name)' exists with isCollection=$($cur['isCollection']), expected $($rd.isCollection)!"
            }
            if ([bool]$cur['usePreDefinedValuesOnly'] -ne [bool]$rd.usePreDefinedValuesOnly) {
                throw "SCHEMA MISMATCH: Attribute '$($rd.name)' exists with usePreDefinedValuesOnly=$($cur['usePreDefinedValuesOnly']), expected $($rd.usePreDefinedValuesOnly)!"
            }
            Write-Host "  [OK] Definition '$($rd.name)' exists (isCollection=$($cur['isCollection']), usePreDefinedValuesOnly=$($cur['usePreDefinedValuesOnly']))." -ForegroundColor Green
        } else {
            Write-Host "  [+] Creating definition '$($rd.name)' (isCollection=$($rd.isCollection), usePreDefinedValuesOnly=$($rd.usePreDefinedValuesOnly)) ..." -ForegroundColor Yellow
            $defBody = @{
                attributeSet            = $script:AttributeSetName
                name                    = $rd.name
                description             = $rd.description
                type                    = 'String'
                status                  = 'Available'
                isCollection            = [bool]$rd.isCollection
                isSearchable            = $true
                usePreDefinedValuesOnly = [bool]$rd.usePreDefinedValuesOnly
            }
            if ($null -ne $rd.allowedValues) {
                $defBody['allowedValues'] = $rd.allowedValues
            }
            Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/directory/customSecurityAttributeDefinitions' -Body $defBody | Out-Null
        }
    }
}

function Resolve-EntraApp {
    <#
    .SYNOPSIS
        Idempotently creates an Entra ID Application Registration + Service Principal.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$DisplayName,

        [Parameter(Mandatory = $false)]
        [ValidateSet('Producer', 'LegacyProducer', 'Service', 'WebApp', 'MiddleTierApi', 'SPA')]
        [string]$Kind = 'Service'
    )

    $escapedName = $DisplayName.Replace("'", "''")
    $existingApps = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/applications?`$filter=displayName eq '$escapedName'"
    $app = $null
    if ($existingApps.ContainsKey('value') -and @($existingApps['value']).Count -gt 0) {
        $app = @($existingApps['value'])[0]
        Write-Host "  [OK] Application '$DisplayName' already exists (appId=$($app['appId']))." -ForegroundColor Green
    } else {
        Write-Host "  [+] Creating Application '$DisplayName' ($Kind) ..." -ForegroundColor Yellow
        $appBody = @{
            displayName    = $DisplayName
            signInAudience = 'AzureADMyOrg'
            api            = @{ requestedAccessTokenVersion = 2 }
        }
        if ($Kind -eq 'SPA') {
            $appBody['spa'] = @{ redirectUris = @('http://localhost:3000/callback') }
        } elseif ($Kind -eq 'WebApp') {
            $appBody['web'] = @{ redirectUris = @('https://localhost:5001/signin-oidc') }
        }
        $app = Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/applications' -Body $appBody

        # For Producers, set Application ID URI (api://<appId>) and optional idtyp claim
        if ($Kind -in @('Producer', 'LegacyProducer')) {
            $patchBody = @{
                identifierUris = @("api://$($app['appId'])")
                optionalClaims = @{
                    accessToken = @(
                        @{ name = 'idtyp'; essential = $false }
                    )
                }
            }
            Invoke-Graph -Method PATCH -Uri "https://graph.microsoft.com/v1.0/applications/$($app['id'])" -Body $patchBody | Out-Null
            $app = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/applications/$($app['id'])"
        }
    }

    # Ensure Service Principal exists
    $appId = $app['appId']
    $existingSps = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/servicePrincipals?`$filter=appId eq '$appId'"
    $sp = $null
    if ($existingSps.ContainsKey('value') -and @($existingSps['value']).Count -gt 0) {
        $sp = @($existingSps['value'])[0]
    } else {
        Write-Host "  [+] Creating Service Principal for '$DisplayName' ..." -ForegroundColor Yellow
        $sp = Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/servicePrincipals' -Body @{ appId = $appId }
    }

    return [PSCustomObject]@{
        DisplayName        = $DisplayName
        Kind               = $Kind
        AppObjectId        = $app['id']
        AppId              = $app['appId']
        ServicePrincipalId = $sp['id']
    }
}

function Publish-ProducerPermissions {
    <#
    .SYNOPSIS
        Publishes permissions on a Producer App Registration as BOTH App Roles and Admin-consent API Scopes.
        Tests the RFC's DEV hypothesis: whether identical value strings work across appRoles and oauth2PermissionScopes.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AppObjectId,

        [Parameter(Mandatory = $true)]
        [string[]]$Permissions,

        [Parameter(Mandatory = $false)]
        [ValidateSet('MirroredExact', 'DistinctIdsSameValue', 'FallbackSuffix')]
        [string]$Strategy = 'MirroredExact'
    )

    $app = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/applications/$AppObjectId"
    $existingRoles = @{}
    if ($app.ContainsKey('appRoles') -and $null -ne $app['appRoles']) {
        foreach ($r in @($app['appRoles'])) { $existingRoles[$r['value']] = $r }
    }
    $existingScopes = @{}
    if ($app.ContainsKey('api') -and $null -ne $app['api'] -and $app['api'].ContainsKey('oauth2PermissionScopes') -and $null -ne $app['api']['oauth2PermissionScopes']) {
        foreach ($s in @($app['api']['oauth2PermissionScopes'])) { $existingScopes[$s['value']] = $s }
    }

    $appRoles = New-Object System.Collections.Generic.List[hashtable]
    $oauth2Scopes = New-Object System.Collections.Generic.List[hashtable]

    foreach ($perm in $Permissions) {
        $scopeValue = if ($Strategy -eq 'FallbackSuffix') { "$perm.asuser" } else { $perm }

        $roleId = if ($existingRoles.ContainsKey($perm)) { $existingRoles[$perm]['id'] } else { [guid]::NewGuid().ToString() }
        $scopeId = if ($Strategy -eq 'MirroredExact') {
            $roleId
        } elseif ($existingScopes.ContainsKey($scopeValue)) {
            $existingScopes[$scopeValue]['id']
        } else {
            [guid]::NewGuid().ToString()
        }

        $displayName = "Access $perm"
        $description = "Allows access for $perm"

        $appRoles.Add(@{
            allowedMemberTypes = @('Application')
            description        = $description
            displayName        = $displayName
            id                 = $roleId
            isEnabled          = $true
            value              = $perm
        })

        $oauth2Scopes.Add(@{
            adminConsentDescription = $description
            adminConsentDisplayName = $displayName
            id                      = $scopeId
            isEnabled               = $true
            type                    = 'Admin'
            value                   = $scopeValue
        })
    }

    $patchBody = @{
        appRoles = @($appRoles)
        api      = @{
            requestedAccessTokenVersion = 2
            oauth2PermissionScopes      = @($oauth2Scopes)
        }
    }

    try {
        Invoke-Graph -Method PATCH -Uri "https://graph.microsoft.com/v1.0/applications/$AppObjectId" -Body $patchBody | Out-Null
        return [PSCustomObject]@{
            Success  = $true
            Strategy = $Strategy
            Error    = $null
        }
    } catch {
        return [PSCustomObject]@{
            Success  = $false
            Strategy = $Strategy
            Error    = $_.Exception.Message
        }
    }
}

function Get-ConsumerSpDetails {
    <#
    .SYNOPSIS
        Retrieves a Consumer Service Principal and enforces RFC tenant-ownership and single-tenant guardrails.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServicePrincipalId
    )

    $session = Connect-GovernanceGraph
    $tenantId = $session.TenantId
    $uri = "https://graph.microsoft.com/v1.0/servicePrincipals/$ServicePrincipalId`?`$select=id,appId,displayName,appOwnerOrganizationId"
    $sp = Invoke-Graph -Method GET -Uri $uri

    if ([string]$sp['appOwnerOrganizationId'] -ne [string]$tenantId) {
        throw "Consumer service principal '$ServicePrincipalId' ($($sp['displayName'])) belongs to an application owned by '$($sp['appOwnerOrganizationId'])', not this tenant ('$tenantId'). External consumers are not permitted."
    }

    $appId = [string]$sp['appId']
    $app = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/applications(appId='$appId')?`$select=id,appId,signInAudience"
    $audience = [string]$app['signInAudience']
    if ($audience -ne 'AzureADMyOrg') {
        throw "Consumer application '$($sp['displayName'])' (appId=$appId) has signInAudience='$audience'; RFC Phase 1 permits only single-tenant ('AzureADMyOrg') consumers."
    }

    return [PSCustomObject]@{
        ServicePrincipalId     = $sp['id']
        AppId                  = $appId
        DisplayName            = $sp['displayName']
        AppOwnerOrganizationId = $sp['appOwnerOrganizationId']
        SignInAudience         = $audience
    }
}

function Get-ProducerSpDetails {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServicePrincipalId,

        [switch]$SkipPreflight
    )

    if (-not $SkipPreflight) {
        Assert-AttributeReadAccess | Out-Null
    }

    $uri = "https://graph.microsoft.com/v1.0/servicePrincipals/$ServicePrincipalId`?`$select=id,appId,displayName,appOwnerOrganizationId,appRoles,oauth2PermissionScopes,customSecurityAttributes"
    $sp = Invoke-Graph -Method GET -Uri $uri

    $tenantId = (Connect-GovernanceGraph).TenantId
    if ([string]$sp['appOwnerOrganizationId'] -ne [string]$tenantId) {
        throw "Service principal '$ServicePrincipalId' ($($sp['displayName'])) belongs to an application owned by '$($sp['appOwnerOrganizationId'])', not this tenant ('$tenantId'). Unity Deploy refuses external and Microsoft first-party producers."
    }

    $allCustomAttrs = if ($sp.ContainsKey('customSecurityAttributes')) { $sp['customSecurityAttributes'] } else { $null }
    $appToApp = $null
    $otherCount = 0

    $validAttrNames = @('DefaultAppRole', 'AllowAppRole', 'DenyAppRole', 'DefaultScope', 'AllowScope', 'DenyScope')

    if ($allCustomAttrs -is [hashtable]) {
        foreach ($setKey in $allCustomAttrs.Keys) {
            if ($setKey -eq $script:AttributeSetName) {
                $rawSet = $allCustomAttrs[$setKey]
                $clean = @{}
                foreach ($k in $rawSet.Keys) {
                    if ($k -notlike '*@odata*') {
                        if ($validAttrNames -contains $k) {
                            $clean[$k] = $rawSet[$k]
                        } elseif ($null -ne $rawSet[$k]) {
                            # Any non-RFC / deprecated attributes still assigned on this SP count toward the 50-value SP ceiling
                            if ($rawSet[$k] -is [System.Collections.IEnumerable] -and -not ($rawSet[$k] -is [string])) {
                                $otherCount += @($rawSet[$k]).Count
                            } else {
                                $otherCount++
                            }
                        }
                    }
                }
                $appToApp = $clean
            } elseif ($setKey -notlike '*@odata*') {
                $otherSet = $allCustomAttrs[$setKey]
                if ($otherSet -is [hashtable]) {
                    foreach ($ok in $otherSet.Keys) {
                        if ($ok -notlike '*@odata*' -and $null -ne $otherSet[$ok]) {
                            if ($otherSet[$ok] -is [System.Collections.IEnumerable] -and -not ($otherSet[$ok] -is [string])) {
                                $otherCount += @($otherSet[$ok]).Count
                            } else {
                                $otherCount++
                            }
                        }
                    }
                }
            }
        }
    }

    return [PSCustomObject]@{
        ServicePrincipalId       = $sp['id']
        AppId                    = $sp['appId']
        DisplayName              = $sp['displayName']
        AppRoles                 = if ($sp.ContainsKey('appRoles') -and $null -ne $sp['appRoles']) { @($sp['appRoles']) } else { @() }
        OAuth2PermissionScopes   = if ($sp.ContainsKey('oauth2PermissionScopes') -and $null -ne $sp['oauth2PermissionScopes']) { @($sp['oauth2PermissionScopes']) } else { @() }
        AppToAppAccess           = $appToApp
        OtherAttributeValueCount = $otherCount
        IsLegacy                 = ($null -eq $appToApp -or $appToApp.Count -eq 0)
    }
}

function Set-ProducerSpMetadata {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServicePrincipalId,

        [Parameter(Mandatory = $true)]
        [hashtable]$Rules
    )

    $attrPayload = [ordered]@{
        '@odata.type' = '#Microsoft.DirectoryServices.CustomSecurityAttributeValue'
    }

    # Always send all six attributes so any key removed from producer config is cleared in Entra ID.
    foreach ($singleAttr in @('DefaultAppRole', 'DefaultScope')) {
        $val = if ($Rules.ContainsKey($singleAttr)) { [string]$Rules[$singleAttr] } else { '' }
        $attrPayload[$singleAttr] = if ([string]::IsNullOrWhiteSpace($val)) { $null } else { $val }
    }

    foreach ($listAttr in @('AllowAppRole', 'DenyAppRole', 'AllowScope', 'DenyScope')) {
        $items = @()
        if ($Rules.ContainsKey($listAttr) -and $null -ne $Rules[$listAttr]) {
            $items = @($Rules[$listAttr] | ForEach-Object { [string]$_ })
        }
        $attrPayload["$listAttr@odata.type"] = '#Collection(String)'
        $attrPayload[$listAttr] = [string[]]$items
    }

    $body = @{
        customSecurityAttributes = @{
            $script:AttributeSetName = $attrPayload
        }
    }

    Invoke-Graph -Method PATCH -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$ServicePrincipalId" -Body $body | Out-Null
}

function Clear-ProducerSpMetadata {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServicePrincipalId
    )

    Set-ProducerSpMetadata -ServicePrincipalId $ServicePrincipalId -Rules @{}
}

function Get-AllConsumerGrants {
    <#
    .SYNOPSIS
        Lists ALL App Role assignments and AllPrincipals OAuth2 permission grants currently held by a consumer SP.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ConsumerSpId
    )

    $roleRes = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$ConsumerSpId/appRoleAssignments"
    $allRoles = if ($roleRes.ContainsKey('value') -and $null -ne $roleRes['value']) { @($roleRes['value']) } else { @() }

    $grantRes = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/oauth2PermissionGrants?`$filter=clientId eq '$ConsumerSpId'"
    $allScopes = @()
    if ($grantRes.ContainsKey('value') -and $null -ne $grantRes['value']) {
        $allScopes = @($grantRes['value'] | Where-Object { $_['consentType'] -eq 'AllPrincipals' })
    }

    return [PSCustomObject]@{
        AppRoleAssignments     = $allRoles
        OAuth2PermissionGrants = $allScopes
    }
}

function Get-ConsumerGrantsForProducer {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ConsumerSpId,

        [Parameter(Mandatory = $true)]
        [string]$ProducerSpId
    )

    $roleRes = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$ConsumerSpId/appRoleAssignments"
    $rolesForProducer = @()
    if ($roleRes.ContainsKey('value') -and $null -ne $roleRes['value']) {
        $rolesForProducer = @($roleRes['value'] | Where-Object { $_['resourceId'] -eq $ProducerSpId })
    }

    $grantRes = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/oauth2PermissionGrants?`$filter=clientId eq '$ConsumerSpId' and resourceId eq '$ProducerSpId'"
    $scopeGrants = @()
    if ($grantRes.ContainsKey('value') -and $null -ne $grantRes['value']) {
        $scopeGrants = @($grantRes['value'] | Where-Object { $_['consentType'] -eq 'AllPrincipals' })
    }

    return [PSCustomObject]@{
        AppRoleAssignments    = $rolesForProducer
        OAuth2PermissionGrant = if ($scopeGrants.Count -gt 0) { $scopeGrants[0] } else { $null }
    }
}

function Sync-ConsumerAppRoleGrants {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ConsumerSpId,

        [Parameter(Mandatory = $true)]
        [string]$ProducerSpId,

        [Parameter(Mandatory = $true)]
        [array]$ProducerAppRoles,

        [Parameter(Mandatory = $false)]
        [string[]]$DesiredPermissions = @(),

        [switch]$PreviewOnly
    )

    $actions = New-Object System.Collections.Generic.List[PSCustomObject]
    $current = Get-ConsumerGrantsForProducer -ConsumerSpId $ConsumerSpId -ProducerSpId $ProducerSpId

    $roleByValue = @{}
    $roleById = @{}
    foreach ($r in $ProducerAppRoles) {
        if ($r['value']) { $roleByValue[$r['value']] = $r }
        if ($r['id']) { $roleById[$r['id']] = $r }
    }

    $desiredRoleIds = @{}
    foreach ($perm in $DesiredPermissions) {
        if (-not $roleByValue.ContainsKey($perm)) {
            throw "Producer service principal '$ProducerSpId' does not publish an appRole with value '$perm'."
        }
        $desiredRoleIds[$roleByValue[$perm]['id']] = $perm
    }

    $existingRoleIds = @{}
    foreach ($a in @($current.AppRoleAssignments)) {
        $rid = $a['appRoleId']
        $existingRoleIds[$rid] = $a
        if (-not $desiredRoleIds.ContainsKey($rid)) {
            $permName = if ($roleById.ContainsKey($rid)) { $roleById[$rid]['value'] } else { $rid }
            if ($PreviewOnly) {
                $actions.Add([PSCustomObject]@{ Action = 'WOULD_REVOKE'; GrantType = 'AppRole'; Permission = $permName; Id = $a['id']; ResourceId = $ProducerSpId })
            } else {
                Invoke-Graph -Method DELETE -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$ConsumerSpId/appRoleAssignments/$($a['id'])" | Out-Null
                $actions.Add([PSCustomObject]@{ Action = 'REVOKED'; GrantType = 'AppRole'; Permission = $permName; Id = $a['id']; ResourceId = $ProducerSpId })
            }
        }
    }

    foreach ($rid in $desiredRoleIds.Keys) {
        $permName = $desiredRoleIds[$rid]
        if ($existingRoleIds.ContainsKey($rid)) {
            $actions.Add([PSCustomObject]@{ Action = 'UNCHANGED'; GrantType = 'AppRole'; Permission = $permName; Id = $existingRoleIds[$rid]['id']; ResourceId = $ProducerSpId })
        } elseif ($PreviewOnly) {
            $actions.Add([PSCustomObject]@{ Action = 'WOULD_GRANT'; GrantType = 'AppRole'; Permission = $permName; Id = 'preview'; ResourceId = $ProducerSpId })
        } else {
            $body = @{
                principalId = $ConsumerSpId
                resourceId  = $ProducerSpId
                appRoleId   = $rid
            }
            $created = Invoke-Graph -Method POST -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$ConsumerSpId/appRoleAssignments" -Body $body
            $actions.Add([PSCustomObject]@{ Action = 'GRANTED'; GrantType = 'AppRole'; Permission = $permName; Id = $created['id']; ResourceId = $ProducerSpId })
        }
    }

    return @($actions)
}

function Sync-ConsumerApiScopeGrants {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ConsumerSpId,

        [Parameter(Mandatory = $true)]
        [string]$ProducerSpId,

        [Parameter(Mandatory = $true)]
        [array]$ProducerScopes,

        [Parameter(Mandatory = $false)]
        [string[]]$DesiredPermissions = @(),

        [Parameter(Mandatory = $false)]
        [string]$ScopeSuffix = '',

        [switch]$PreviewOnly
    )

    $actions = New-Object System.Collections.Generic.List[PSCustomObject]
    $current = Get-ConsumerGrantsForProducer -ConsumerSpId $ConsumerSpId -ProducerSpId $ProducerSpId

    $publishedScopeValues = @($ProducerScopes | ForEach-Object { $_['value'] })
    $desiredScopeNames = New-Object System.Collections.Generic.List[string]
    foreach ($perm in $DesiredPermissions) {
        $actualScope = "$perm$ScopeSuffix"
        if ($publishedScopeValues -notcontains $actualScope) {
            throw "Producer service principal '$ProducerSpId' does not publish an oauth2PermissionScope with value '$actualScope'."
        }
        $desiredScopeNames.Add($actualScope)
    }

    $existingGrant = $current.OAuth2PermissionGrant
    $existingScopes = @()
    if ($null -ne $existingGrant -and -not [string]::IsNullOrWhiteSpace([string]$existingGrant['scope'])) {
        $existingScopes = @(($existingGrant['scope'].Trim() -split '\s+') | Where-Object { $_ -ne '' })
    }

    $desiredSorted = @($desiredScopeNames | Sort-Object -Unique)
    $existingSorted = @($existingScopes | Sort-Object -Unique)

    foreach ($es in $existingSorted) {
        if ($desiredSorted -notcontains $es) {
            $actName = if ($PreviewOnly) { 'WOULD_REVOKE' } else { 'REVOKED' }
            $actions.Add([PSCustomObject]@{ Action = $actName; GrantType = 'ApiScope'; Permission = $es; Id = $existingGrant['id']; ResourceId = $ProducerSpId })
        }
    }
    foreach ($ds in $desiredSorted) {
        if ($existingSorted -contains $ds) {
            $actions.Add([PSCustomObject]@{ Action = 'UNCHANGED'; GrantType = 'ApiScope'; Permission = $ds; Id = $existingGrant['id']; ResourceId = $ProducerSpId })
        } else {
            $actName = if ($PreviewOnly) { 'WOULD_GRANT' } else { 'GRANTED' }
            $actId   = if ($PreviewOnly) { 'preview' } else { 'pending' }
            $actions.Add([PSCustomObject]@{ Action = $actName; GrantType = 'ApiScope'; Permission = $ds; Id = $actId; ResourceId = $ProducerSpId })
        }
    }

    if ($PreviewOnly) {
        return @($actions)
    }

    $desiredScopeStr = ($desiredSorted -join ' ')
    $existingScopeStr = ($existingSorted -join ' ')

    if ($desiredSorted.Count -eq 0) {
        if ($null -ne $existingGrant) {
            Invoke-Graph -Method DELETE -Uri "https://graph.microsoft.com/v1.0/oauth2PermissionGrants/$($existingGrant['id'])" | Out-Null
        }
    } elseif ($null -eq $existingGrant) {
        $body = @{
            clientId    = $ConsumerSpId
            consentType = 'AllPrincipals'
            resourceId  = $ProducerSpId
            scope       = $desiredScopeStr
        }
        $created = Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/oauth2PermissionGrants' -Body $body
        foreach ($act in $actions) { if ($act.Id -eq 'pending') { $act.Id = $created['id'] } }
    } elseif ($desiredScopeStr -ne $existingScopeStr) {
        $body = @{ scope = $desiredScopeStr }
        Invoke-Graph -Method PATCH -Uri "https://graph.microsoft.com/v1.0/oauth2PermissionGrants/$($existingGrant['id'])" -Body $body | Out-Null
        foreach ($act in $actions) { if ($act.Id -eq 'pending') { $act.Id = $existingGrant['id'] } }
    }

    return @($actions)
}

function Add-AppClientSecret {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AppObjectId,

        [string]$DisplayName = 'ProtoTestSecret'
    )

    $body = @{
        passwordCredential = @{
            displayName = $DisplayName
            endDateTime = (Get-Date).ToUniversalTime().AddDays(7).ToString('o')
        }
    }
    $res = Invoke-Graph -Method POST -Uri "https://graph.microsoft.com/v1.0/applications/$AppObjectId/addPassword" -Body $body
    return $res['secretText']
}

function Get-ClientCredentialsTokenClaims {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TenantId,

        [Parameter(Mandatory = $true)]
        [string]$ClientId,

        [Parameter(Mandatory = $true)]
        [string]$ClientSecret,

        [Parameter(Mandatory = $true)]
        [string]$ProducerAppId
    )

    $tokenUrl = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
    $form = @{
        client_id     = $ClientId
        client_secret = $ClientSecret
        scope         = "api://$ProducerAppId/.default"
        grant_type    = 'client_credentials'
    }

    $resp = Invoke-RestMethod -Method POST -Uri $tokenUrl -Body $form -ContentType 'application/x-www-form-urlencoded'
    return (Decode-JwtPayload -Jwt $resp.access_token)
}

Export-ModuleMember -Function @(
    'Connect-GovernanceGraph',
    'Invoke-Graph',
    'Initialize-AttributeAdminRoles',
    'Assert-AttributeReadAccess',
    'Get-AppToAppAccessSchemaDefinition',
    'Initialize-AppToAppAccessSchema',
    'Resolve-EntraApp',
    'Publish-ProducerPermissions',
    'Get-ConsumerSpDetails',
    'Get-ProducerSpDetails',
    'Set-ProducerSpMetadata',
    'Clear-ProducerSpMetadata',
    'Get-AllConsumerGrants',
    'Get-ConsumerGrantsForProducer',
    'Sync-ConsumerAppRoleGrants',
    'Sync-ConsumerApiScopeGrants',
    'Add-AppClientSecret',
    'Get-ClientCredentialsTokenClaims'
)
