#Requires -Version 5.1
<#
.SYNOPSIS
    Zero-dependency Microsoft Graph v1.0 REST client for the Entra ID App-to-App Governance Prototype.
.DESCRIPTION
    Uses native Invoke-RestMethod (works identically in Windows PowerShell 5.1, PowerShell 7+, and CI runners).
    Supports:
      - OAuth 2.0 Device Code flow with DPAPI-encrypted refresh token cache (CurrentUser scope)
      - Silent token refresh (so role assignment refresh and subsequent scripts require zero re-prompts)
      - Service Principal (Client Credentials) auth via AZURE_TENANT_ID / AZURE_CLIENT_ID / AZURE_CLIENT_SECRET for CI/CD
#>

Set-StrictMode -Version Latest

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue

$script:AttributeSetName = 'AppToAppAccess'
$script:GraphPublicClientId = '14d82eec-204b-4c2f-b7e8-296a70dab67e' # Microsoft Graph Command Line Tools
$script:RoleTemplate_AttrDefAdmin    = '8424c6f0-a189-499e-bbd0-26c1753c96d4'
$script:RoleTemplate_AttrAssignAdmin = '58a13ea3-c632-46ae-9ee0-9c0d43cd7f3d'

$script:RequiredScopes = @(
    'offline_access',
    'openid',
    'profile',
    'Application.ReadWrite.All',
    'AppRoleAssignment.ReadWrite.All',
    'DelegatedPermissionGrant.ReadWrite.All',
    'CustomSecAttributeDefinition.ReadWrite.All',
    'CustomSecAttributeAssignment.ReadWrite.All',
    'RoleManagement.ReadWrite.Directory',
    'Directory.Read.All'
)

$script:TokenCachePath = Join-Path (Split-Path -Parent $PSScriptRoot) 'state\.token-cache.dat'
$script:CurrentSession = $null

function ConvertTo-DeepHashtable {
    param($InputObject)
    if ($null -eq $InputObject) { return $null }
    if ($InputObject -is [System.Collections.IDictionary]) {
        $ht = @{}
        foreach ($k in $InputObject.Keys) { $ht[$k] = ConvertTo-DeepHashtable $InputObject[$k] }
        return $ht
    }
    if ($InputObject -is [PSCustomObject]) {
        $ht = @{}
        foreach ($p in $InputObject.PSObject.Properties) {
            $ht[$p.Name] = ConvertTo-DeepHashtable $p.Value
        }
        return $ht
    }
    if ($InputObject -is [System.Collections.IEnumerable] -and -not ($InputObject -is [string])) {
        $list = New-Object System.Collections.Generic.List[object]
        foreach ($item in $InputObject) { $list.Add((ConvertTo-DeepHashtable $item)) }
        return ,$list.ToArray()
    }
    return $InputObject
}

function Decode-JwtPayload {
    param([string]$Jwt)
    $parts = $Jwt.Split('.')
    $payloadB64 = $parts[1].Replace('-', '+').Replace('_', '/')
    switch ($payloadB64.Length % 4) {
        2 { $payloadB64 += '==' }
        3 { $payloadB64 += '=' }
    }
    $json = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($payloadB64))
    return ($json | ConvertFrom-Json)
}

function Save-TokenCache {
    param([hashtable]$CacheData)
    $dir = Split-Path -Parent $script:TokenCachePath
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $jsonBytes = [System.Text.Encoding]::UTF8.GetBytes(($CacheData | ConvertTo-Json -Depth 5))
    $protected = [System.Security.Cryptography.ProtectedData]::Protect($jsonBytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
    [System.IO.File]::WriteAllBytes($script:TokenCachePath, $protected)
}

function Load-TokenCache {
    if (-not (Test-Path $script:TokenCachePath)) { return $null }
    try {
        $protected = [System.IO.File]::ReadAllBytes($script:TokenCachePath)
        $jsonBytes = [System.Security.Cryptography.ProtectedData]::Unprotect($protected, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        $json = [System.Text.Encoding]::UTF8.GetString($jsonBytes)
        return (ConvertTo-DeepHashtable ($json | ConvertFrom-Json))
    } catch {
        return $null
    }
}

function Get-HttpErrorDetails {
    param($ErrorRecord)
    $msg = $ErrorRecord.Exception.Message
    try {
        if ($null -ne $ErrorRecord.ErrorDetails -and -not [string]::IsNullOrWhiteSpace($ErrorRecord.ErrorDetails.Message)) {
            return "$msg | Body: $($ErrorRecord.ErrorDetails.Message)"
        }
    } catch { }
    try {
        if ($ErrorRecord.Exception.PSObject.Properties['Response'] -and $null -ne $ErrorRecord.Exception.Response) {
            $stream = $ErrorRecord.Exception.Response.GetResponseStream()
            if ($null -ne $stream) {
                $reader = New-Object System.IO.StreamReader($stream)
                $bodyText = $reader.ReadToEnd()
                $reader.Close()
                if (-not [string]::IsNullOrWhiteSpace($bodyText)) {
                    return "$msg | Body: $bodyText"
                }
            }
        }
    } catch { }
    return $msg
}

function Connect-GovernanceGraph {
    [CmdletBinding()]
    param(
        [switch]$ForceRefresh,
        [switch]$UseDeviceCode
    )

    $scopeStr = $script:RequiredScopes -join ' '

    # 1. CI/CD Service Principal mode if environment variables are set
    if ($env:AZURE_TENANT_ID -and $env:AZURE_CLIENT_ID -and $env:AZURE_CLIENT_SECRET) {
        $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        if (-not $ForceRefresh -and $null -ne $script:CurrentSession -and $script:CurrentSession.ExpiresAt -gt ($now + 120)) {
            return $script:CurrentSession
        }
        $tokenResp = Invoke-RestMethod -Method POST `
            -Uri "https://login.microsoftonline.com/$($env:AZURE_TENANT_ID)/oauth2/v2.0/token" `
            -Body @{
                client_id     = $env:AZURE_CLIENT_ID
                client_secret = $env:AZURE_CLIENT_SECRET
                scope         = 'https://graph.microsoft.com/.default'
                grant_type    = 'client_credentials'
            } -ContentType 'application/x-www-form-urlencoded'
        $claims = Decode-JwtPayload -Jwt $tokenResp.access_token
        $script:CurrentSession = [PSCustomObject]@{
            AccessToken = $tokenResp.access_token
            Account     = "SP:$($env:AZURE_CLIENT_ID)"
            TenantId    = $claims.tid
            ExpiresAt   = [int64]$claims.exp
            AuthType    = 'ClientCredentials'
        }
        return $script:CurrentSession
    }

    # 2. Check in-memory session
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    if (-not $ForceRefresh -and -not $UseDeviceCode -and $null -ne $script:CurrentSession -and $script:CurrentSession.ExpiresAt -gt ($now + 120)) {
        return $script:CurrentSession
    }

    # 3. Check DPAPI-encrypted disk cache (and refresh silently via refresh_token)
    $cached = Load-TokenCache
    if ($null -ne $cached -and -not $UseDeviceCode) {
        if (-not $ForceRefresh -and $cached.ContainsKey('expiresAt') -and [int64]$cached['expiresAt'] -gt ($now + 120)) {
            $script:CurrentSession = [PSCustomObject]@{
                AccessToken = $cached['accessToken']
                Account     = $cached['account']
                TenantId    = $cached['tenantId']
                ExpiresAt   = [int64]$cached['expiresAt']
                AuthType    = 'DelegatedCached'
            }
            return $script:CurrentSession
        }

        if ($cached.ContainsKey('refreshToken') -and -not [string]::IsNullOrWhiteSpace($cached['refreshToken'])) {
            try {
                $tid = if ($cached.ContainsKey('tenantId') -and $cached['tenantId']) { $cached['tenantId'] } else { 'organizations' }
                $refResp = Invoke-RestMethod -Method POST `
                    -Uri "https://login.microsoftonline.com/$tid/oauth2/v2.0/token" `
                    -Body @{
                        client_id     = $script:GraphPublicClientId
                        grant_type    = 'refresh_token'
                        refresh_token = $cached['refreshToken']
                        scope         = $scopeStr
                    } -ContentType 'application/x-www-form-urlencoded'

                $claims = Decode-JwtPayload -Jwt $refResp.access_token
                $account = if ($claims.PSObject.Properties['upn']) { $claims.upn } elseif ($claims.PSObject.Properties['unique_name']) { $claims.unique_name } else { $cached['account'] }
                $newRefresh = if ($refResp.PSObject.Properties['refresh_token'] -and $refResp.refresh_token) { $refResp.refresh_token } else { $cached['refreshToken'] }

                Save-TokenCache @{
                    accessToken  = $refResp.access_token
                    refreshToken = $newRefresh
                    account      = $account
                    tenantId     = $claims.tid
                    expiresAt    = [int64]$claims.exp
                }

                $script:CurrentSession = [PSCustomObject]@{
                    AccessToken = $refResp.access_token
                    Account     = $account
                    TenantId    = $claims.tid
                    ExpiresAt   = [int64]$claims.exp
                    AuthType    = 'DelegatedRefreshed'
                }
                return $script:CurrentSession
            } catch {
                [Console]::Out.WriteLine("  [*] Cached refresh token expired or rejected; starting Device Code login...")
                [Console]::Out.Flush()
            }
        }
    }

    # 4. Interactive OAuth 2.0 Device Code Flow (pure REST, zero SDK EventSource/WAM issues)
    $dcResp = Invoke-RestMethod -Method POST `
        -Uri 'https://login.microsoftonline.com/organizations/oauth2/v2.0/devicecode' `
        -Body @{
            client_id = $script:GraphPublicClientId
            scope     = $scopeStr
        } -ContentType 'application/x-www-form-urlencoded'

    [Console]::Out.WriteLine('')
    [Console]::Out.WriteLine($dcResp.message)
    [Console]::Out.WriteLine('')
    [Console]::Out.Flush()

    $interval = if ($dcResp.interval) { [int]$dcResp.interval } else { 5 }
    $deadline = (Get-Date).AddSeconds([int]$dcResp.expires_in)

    $tokenResp = $null
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds $interval
        try {
            $tokenResp = Invoke-RestMethod -Method POST `
                -Uri 'https://login.microsoftonline.com/organizations/oauth2/v2.0/token' `
                -Body @{
                    grant_type  = 'urn:ietf:params:oauth:grant-type:device_code'
                    client_id   = $script:GraphPublicClientId
                    device_code = $dcResp.device_code
                } -ContentType 'application/x-www-form-urlencoded'
            break
        } catch {
            $detail = Get-HttpErrorDetails $_
            if ($detail -match 'authorization_pending') {
                continue
            } elseif ($detail -match 'slow_down') {
                $interval += 5
                continue
            } else {
                throw "Device code authentication failed: $detail"
            }
        }
    }

    if ($null -eq $tokenResp) {
        throw 'Device code authentication timed out.'
    }

    $claims = Decode-JwtPayload -Jwt $tokenResp.access_token
    $account = if ($claims.PSObject.Properties['upn']) { $claims.upn } elseif ($claims.PSObject.Properties['unique_name']) { $claims.unique_name } else { 'unknown' }

    Save-TokenCache @{
        accessToken  = $tokenResp.access_token
        refreshToken = $tokenResp.refresh_token
        account      = $account
        tenantId     = $claims.tid
        expiresAt    = [int64]$claims.exp
    }

    $script:CurrentSession = [PSCustomObject]@{
        AccessToken = $tokenResp.access_token
        Account     = $account
        TenantId    = $claims.tid
        ExpiresAt   = [int64]$claims.exp
        AuthType    = 'DeviceCode'
    }
    return $script:CurrentSession
}

function Invoke-Graph {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet('GET', 'POST', 'PATCH', 'PUT', 'DELETE')]
        [string]$Method,

        [Parameter(Mandatory = $true)]
        [string]$Uri,

        [Parameter(Mandatory = $false)]
        $Body = $null
    )

    $session = Connect-GovernanceGraph
    $headers = @{
        Authorization = "Bearer $($session.AccessToken)"
        Accept        = 'application/json'
    }

    $params = @{
        Method  = $Method
        Uri     = $Uri
        Headers = $headers
    }

    if ($null -ne $Body) {
        $json = if ($Body -is [string]) { $Body } else { ($Body | ConvertTo-Json -Depth 12) }
        $params['Body'] = [System.Text.Encoding]::UTF8.GetBytes($json)
        $params['ContentType'] = 'application/json; charset=utf-8'
    }

    try {
        $resp = Invoke-RestMethod @params
        if ($null -eq $resp -or $resp -eq '') { return @{} }
        return (ConvertTo-DeepHashtable $resp)
    } catch {
        $detail = Get-HttpErrorDetails $_
        throw "Graph $Method $Uri failed: $detail"
    }
}

function Initialize-AttributeAdminRoles {
    <#
    .SYNOPSIS
        Ensures the signed-in admin holds Attribute Definition Administrator
        and Attribute Assignment Administrator (even Global Admins lack these by default in Entra ID).
    #>
    [CmdletBinding()]
    param()

    $session = Connect-GovernanceGraph
    if ($session.AuthType -eq 'ClientCredentials') {
        Write-Host "  [*] Service Principal (ClientCredentials) auth detected; skipping /me role check (ensure SP holds Attribute Definition & Assignment Admin roles)." -ForegroundColor Yellow
        return [PSCustomObject]@{
            UserId      = $null
            Upn         = $session.Account
            AssignedNew = $false
        }
    }

    $me = Invoke-Graph -Method GET -Uri 'https://graph.microsoft.com/v1.0/me?$select=id,userPrincipalName'
    $myId = $me['id']
    $myUpn = $me['userPrincipalName']

    $existing = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments?`$filter=principalId eq '$myId'"
    $existingRoleIds = @()
    if ($existing.ContainsKey('value') -and $null -ne $existing['value']) {
        $existingRoleIds = @($existing['value'] | ForEach-Object { $_['roleDefinitionId'] })
    }

    $assignedNew = $false
    $rolesToEnsure = @(
        @{ Name = 'Attribute Definition Administrator'; Id = $script:RoleTemplate_AttrDefAdmin; Scope = '/' },
        @{ Name = 'Attribute Assignment Administrator'; Id = $script:RoleTemplate_AttrAssignAdmin; Scope = '/' }
    )

    foreach ($r in $rolesToEnsure) {
        if ($existingRoleIds -contains $r.Id) {
            Write-Host "  [OK] $myUpn already holds '$($r.Name)'" -ForegroundColor Green
        } else {
            Write-Host "  [+] Assigning '$($r.Name)' to $myUpn ..." -ForegroundColor Yellow
            $body = @{
                '@odata.type'    = '#microsoft.graph.unifiedRoleAssignment'
                roleDefinitionId = $r.Id
                principalId      = $myId
                directoryScopeId = $r.Scope
            }
            Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/roleManagement/directory/roleAssignments' -Body $body | Out-Null
            $assignedNew = $true
        }
    }

    return [PSCustomObject]@{
        UserId      = $myId
        Upn         = $myUpn
        AssignedNew = $assignedNew
    }
}

function Initialize-AppToAppAccessSchema {
    <#
    .SYNOPSIS
        Idempotently creates the AppToAppAccess Custom Security Attribute Set and all 6 RFC definitions.
        CRITICAL: AllowAppRole, DenyAppRole, AllowScope, DenyScope MUST be created with isCollection = $true (irreversible).
    #>
    [CmdletBinding()]
    param()

    # 1. Attribute Set
    $sets = Invoke-Graph -Method GET -Uri 'https://graph.microsoft.com/v1.0/directory/attributeSets'
    $setExists = $false
    if ($sets.ContainsKey('value') -and $null -ne $sets['value']) {
        $setExists = (@($sets['value'] | Where-Object { $_['id'] -eq $script:AttributeSetName }).Count -gt 0)
    }

    if ($setExists) {
        Write-Host "  [OK] Attribute Set '$($script:AttributeSetName)' already exists." -ForegroundColor Green
    } else {
        Write-Host "  [+] Creating Attribute Set '$($script:AttributeSetName)' ..." -ForegroundColor Yellow
        $setBody = @{
            id                  = $script:AttributeSetName
            description         = 'Producer-governed App-to-App permission rules (RFC Phase 1)'
            maxAttributesPerSet = 10
        }
        Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/directory/attributeSets' -Body $setBody | Out-Null
    }

    # 2. Six Attribute Definitions
    $defs = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/directory/customSecurityAttributeDefinitions?`$filter=attributeSet eq '$($script:AttributeSetName)'"
    $existingDefs = @{}
    if ($defs.ContainsKey('value') -and $null -ne $defs['value']) {
        foreach ($d in @($defs['value'])) {
            $existingDefs[$d['name']] = $d
        }
    }

    $requiredDefs = @(
        @{ name = 'DefaultAppRole'; isCollection = $false; description = 'Default posture for App Roles (Allow or Deny)' },
        @{ name = 'AllowAppRole';   isCollection = $true;  description = 'Allow rules for App Roles (APPID_project_component:resource.verb)' },
        @{ name = 'DenyAppRole';    isCollection = $true;  description = 'Deny rules for App Roles (overrides AllowAppRole and DefaultAppRole)' },
        @{ name = 'DefaultScope';   isCollection = $false; description = 'Default posture for API Scopes (Allow or Deny)' },
        @{ name = 'AllowScope';     isCollection = $true;  description = 'Allow rules for API Scopes (APPID_project_component:resource.verb)' },
        @{ name = 'DenyScope';      isCollection = $true;  description = 'Deny rules for API Scopes (overrides AllowScope and DefaultScope)' }
    )

    foreach ($rd in $requiredDefs) {
        if ($existingDefs.ContainsKey($rd.name)) {
            $cur = $existingDefs[$rd.name]
            if ([bool]$cur['isCollection'] -ne [bool]$rd.isCollection) {
                throw "SCHEMA MISMATCH: Attribute '$($rd.name)' exists with isCollection=$($cur['isCollection']), expected $($rd.isCollection)!"
            }
            Write-Host "  [OK] Definition '$($rd.name)' exists (isCollection=$($cur['isCollection']))." -ForegroundColor Green
        } else {
            Write-Host "  [+] Creating definition '$($rd.name)' (isCollection=$($rd.isCollection)) ..." -ForegroundColor Yellow
            $defBody = @{
                attributeSet            = $script:AttributeSetName
                name                    = $rd.name
                description             = $rd.description
                type                    = 'String'
                status                  = 'Available'
                isCollection            = $rd.isCollection
                isSearchable            = $true
                usePreDefinedValuesOnly = $false
            }
            Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/directory/customSecurityAttributeDefinitions' -Body $defBody | Out-Null
        }
    }
}

function Resolve-EntraApp {
    <#
    .SYNOPSIS
        Idempotently creates an Entra ID Application Registration + Service Principal.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$DisplayName,

        [Parameter(Mandatory = $false)]
        [ValidateSet('Producer', 'LegacyProducer', 'Service', 'WebApp', 'MiddleTierApi', 'SPA')]
        [string]$Kind = 'Service'
    )

    $escapedName = $DisplayName.Replace("'", "''")
    $existingApps = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/applications?`$filter=displayName eq '$escapedName'"
    $app = $null
    if ($existingApps.ContainsKey('value') -and @($existingApps['value']).Count -gt 0) {
        $app = @($existingApps['value'])[0]
        Write-Host "  [OK] Application '$DisplayName' already exists (appId=$($app['appId']))." -ForegroundColor Green
    } else {
        Write-Host "  [+] Creating Application '$DisplayName' ($Kind) ..." -ForegroundColor Yellow
        $appBody = @{
            displayName    = $DisplayName
            signInAudience = 'AzureADMyOrg'
            api            = @{ requestedAccessTokenVersion = 2 }
        }
        if ($Kind -eq 'SPA') {
            $appBody['spa'] = @{ redirectUris = @('http://localhost:3000/callback') }
        } elseif ($Kind -eq 'WebApp') {
            $appBody['web'] = @{ redirectUris = @('https://localhost:5001/signin-oidc') }
        }
        $app = Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/applications' -Body $appBody

        # For Producers, set Application ID URI (api://<appId>) and optional idtyp claim
        if ($Kind -in @('Producer', 'LegacyProducer')) {
            $patchBody = @{
                identifierUris = @("api://$($app['appId'])")
                optionalClaims = @{
                    accessToken = @(
                        @{ name = 'idtyp'; essential = $false }
                    )
                }
            }
            Invoke-Graph -Method PATCH -Uri "https://graph.microsoft.com/v1.0/applications/$($app['id'])" -Body $patchBody | Out-Null
            $app = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/applications/$($app['id'])"
        }
    }

    # Ensure Service Principal exists
    $appId = $app['appId']
    $existingSps = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/servicePrincipals?`$filter=appId eq '$appId'"
    $sp = $null
    if ($existingSps.ContainsKey('value') -and @($existingSps['value']).Count -gt 0) {
        $sp = @($existingSps['value'])[0]
    } else {
        Write-Host "  [+] Creating Service Principal for '$DisplayName' ..." -ForegroundColor Yellow
        $sp = Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/servicePrincipals' -Body @{ appId = $appId }
    }

    return [PSCustomObject]@{
        DisplayName        = $DisplayName
        Kind               = $Kind
        AppObjectId        = $app['id']
        AppId              = $app['appId']
        ServicePrincipalId = $sp['id']
    }
}

function Publish-ProducerPermissions {
    <#
    .SYNOPSIS
        Publishes permissions on a Producer App Registration as BOTH App Roles and Admin-consent API Scopes.
        Tests the RFC's DEV hypothesis: whether identical value strings work across appRoles and oauth2PermissionScopes.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AppObjectId,

        [Parameter(Mandatory = $true)]
        [string[]]$Permissions,

        [Parameter(Mandatory = $false)]
        [ValidateSet('MirroredExact', 'DistinctIdsSameValue', 'FallbackSuffix')]
        [string]$Strategy = 'MirroredExact'
    )

    $app = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/applications/$AppObjectId"
    $existingRoles = @{}
    if ($app.ContainsKey('appRoles') -and $null -ne $app['appRoles']) {
        foreach ($r in @($app['appRoles'])) { $existingRoles[$r['value']] = $r }
    }
    $existingScopes = @{}
    if ($app.ContainsKey('api') -and $null -ne $app['api'] -and $app['api'].ContainsKey('oauth2PermissionScopes') -and $null -ne $app['api']['oauth2PermissionScopes']) {
        foreach ($s in @($app['api']['oauth2PermissionScopes'])) { $existingScopes[$s['value']] = $s }
    }

    $appRoles = New-Object System.Collections.Generic.List[hashtable]
    $oauth2Scopes = New-Object System.Collections.Generic.List[hashtable]

    foreach ($perm in $Permissions) {
        $scopeValue = if ($Strategy -eq 'FallbackSuffix') { "$perm.asuser" } else { $perm }

        $roleId = if ($existingRoles.ContainsKey($perm)) { $existingRoles[$perm]['id'] } else { [guid]::NewGuid().ToString() }
        $scopeId = if ($Strategy -eq 'MirroredExact') {
            $roleId
        } elseif ($existingScopes.ContainsKey($scopeValue)) {
            $existingScopes[$scopeValue]['id']
        } else {
            [guid]::NewGuid().ToString()
        }

        $displayName = "Access $perm"
        $description = "Allows access for $perm"

        $appRoles.Add(@{
            allowedMemberTypes = @('Application')
            description        = $description
            displayName        = $displayName
            id                 = $roleId
            isEnabled          = $true
            value              = $perm
        })

        $oauth2Scopes.Add(@{
            adminConsentDescription = $description
            adminConsentDisplayName = $displayName
            id                      = $scopeId
            isEnabled               = $true
            type                    = 'Admin'
            value                   = $scopeValue
        })
    }

    $patchBody = @{
        appRoles = @($appRoles)
        api      = @{
            requestedAccessTokenVersion = 2
            oauth2PermissionScopes      = @($oauth2Scopes)
        }
    }

    try {
        Invoke-Graph -Method PATCH -Uri "https://graph.microsoft.com/v1.0/applications/$AppObjectId" -Body $patchBody | Out-Null
        return [PSCustomObject]@{
            Success  = $true
            Strategy = $Strategy
            Error    = $null
        }
    } catch {
        return [PSCustomObject]@{
            Success  = $false
            Strategy = $Strategy
            Error    = $_.Exception.Message
        }
    }
}

function Get-ProducerSpDetails {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServicePrincipalId
    )

    $uri = "https://graph.microsoft.com/v1.0/servicePrincipals/$ServicePrincipalId`?`$select=id,appId,displayName,appRoles,oauth2PermissionScopes,customSecurityAttributes"
    $sp = Invoke-Graph -Method GET -Uri $uri

    $allCustomAttrs = if ($sp.ContainsKey('customSecurityAttributes')) { $sp['customSecurityAttributes'] } else { $null }
    $appToApp = $null
    $otherCount = 0

    $validAttrNames = @('DefaultAppRole', 'AllowAppRole', 'DenyAppRole', 'DefaultScope', 'AllowScope', 'DenyScope')

    if ($allCustomAttrs -is [hashtable]) {
        foreach ($setKey in $allCustomAttrs.Keys) {
            if ($setKey -eq $script:AttributeSetName) {
                $rawSet = $allCustomAttrs[$setKey]
                $clean = @{}
                foreach ($k in $rawSet.Keys) {
                    if ($k -notlike '*@odata*') {
                        if ($validAttrNames -contains $k) {
                            $clean[$k] = $rawSet[$k]
                        } elseif ($null -ne $rawSet[$k]) {
                            # Any non-RFC / deprecated attributes still assigned on this SP count toward the 50-value SP ceiling
                            if ($rawSet[$k] -is [System.Collections.IEnumerable] -and -not ($rawSet[$k] -is [string])) {
                                $otherCount += @($rawSet[$k]).Count
                            } else {
                                $otherCount++
                            }
                        }
                    }
                }
                $appToApp = $clean
            } elseif ($setKey -notlike '*@odata*') {
                $otherSet = $allCustomAttrs[$setKey]
                if ($otherSet -is [hashtable]) {
                    foreach ($ok in $otherSet.Keys) {
                        if ($ok -notlike '*@odata*' -and $null -ne $otherSet[$ok]) {
                            if ($otherSet[$ok] -is [System.Collections.IEnumerable] -and -not ($otherSet[$ok] -is [string])) {
                                $otherCount += @($otherSet[$ok]).Count
                            } else {
                                $otherCount++
                            }
                        }
                    }
                }
            }
        }
    }

    return [PSCustomObject]@{
        ServicePrincipalId       = $sp['id']
        AppId                    = $sp['appId']
        DisplayName              = $sp['displayName']
        AppRoles                 = if ($sp.ContainsKey('appRoles') -and $null -ne $sp['appRoles']) { @($sp['appRoles']) } else { @() }
        OAuth2PermissionScopes   = if ($sp.ContainsKey('oauth2PermissionScopes') -and $null -ne $sp['oauth2PermissionScopes']) { @($sp['oauth2PermissionScopes']) } else { @() }
        AppToAppAccess           = $appToApp
        OtherAttributeValueCount = $otherCount
        IsLegacy                 = ($null -eq $appToApp -or $appToApp.Count -eq 0)
    }
}

function Set-ProducerSpMetadata {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServicePrincipalId,

        [Parameter(Mandatory = $true)]
        [hashtable]$Rules
    )

    $attrPayload = [ordered]@{
        '@odata.type' = '#Microsoft.DirectoryServices.CustomSecurityAttributeValue'
    }

    foreach ($singleAttr in @('DefaultAppRole', 'DefaultScope')) {
        if ($Rules.ContainsKey($singleAttr)) {
            $val = $Rules[$singleAttr]
            if ([string]::IsNullOrWhiteSpace([string]$val)) {
                $attrPayload[$singleAttr] = $null
            } else {
                $attrPayload[$singleAttr] = [string]$val
            }
        }
    }

    foreach ($listAttr in @('AllowAppRole', 'DenyAppRole', 'AllowScope', 'DenyScope')) {
        if ($Rules.ContainsKey($listAttr)) {
            $items = @()
            if ($null -ne $Rules[$listAttr]) {
                $items = @($Rules[$listAttr] | ForEach-Object { [string]$_ })
            }
            $attrPayload["$listAttr@odata.type"] = '#Collection(String)'
            $attrPayload[$listAttr] = [string[]]$items
        }
    }

    $body = @{
        customSecurityAttributes = @{
            $script:AttributeSetName = $attrPayload
        }
    }

    Invoke-Graph -Method PATCH -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$ServicePrincipalId" -Body $body | Out-Null
}

function Clear-ProducerSpMetadata {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServicePrincipalId
    )

    Set-ProducerSpMetadata -ServicePrincipalId $ServicePrincipalId -Rules @{
        DefaultAppRole = $null
        AllowAppRole   = @()
        DenyAppRole    = @()
        DefaultScope   = $null
        AllowScope     = @()
        DenyScope      = @()
    }
}

function Get-ConsumerGrantsForProducer {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ConsumerSpId,

        [Parameter(Mandatory = $true)]
        [string]$ProducerSpId
    )

    $roleRes = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$ConsumerSpId/appRoleAssignments"
    $rolesForProducer = @()
    if ($roleRes.ContainsKey('value') -and $null -ne $roleRes['value']) {
        $rolesForProducer = @($roleRes['value'] | Where-Object { $_['resourceId'] -eq $ProducerSpId })
    }

    $grantRes = Invoke-Graph -Method GET -Uri "https://graph.microsoft.com/v1.0/oauth2PermissionGrants?`$filter=clientId eq '$ConsumerSpId' and resourceId eq '$ProducerSpId'"
    $scopeGrants = @()
    if ($grantRes.ContainsKey('value') -and $null -ne $grantRes['value']) {
        $scopeGrants = @($grantRes['value'] | Where-Object { $_['consentType'] -eq 'AllPrincipals' })
    }

    return [PSCustomObject]@{
        AppRoleAssignments    = $rolesForProducer
        OAuth2PermissionGrant = if ($scopeGrants.Count -gt 0) { $scopeGrants[0] } else { $null }
    }
}

function Sync-ConsumerAppRoleGrants {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ConsumerSpId,

        [Parameter(Mandatory = $true)]
        [string]$ProducerSpId,

        [Parameter(Mandatory = $true)]
        [array]$ProducerAppRoles,

        [Parameter(Mandatory = $false)]
        [string[]]$DesiredPermissions = @()
    )

    $actions = New-Object System.Collections.Generic.List[PSCustomObject]
    $current = Get-ConsumerGrantsForProducer -ConsumerSpId $ConsumerSpId -ProducerSpId $ProducerSpId

    $roleByValue = @{}
    $roleById = @{}
    foreach ($r in $ProducerAppRoles) {
        if ($r['value']) { $roleByValue[$r['value']] = $r }
        if ($r['id']) { $roleById[$r['id']] = $r }
    }

    $desiredRoleIds = @{}
    foreach ($perm in $DesiredPermissions) {
        if (-not $roleByValue.ContainsKey($perm)) {
            throw "Producer service principal '$ProducerSpId' does not publish an appRole with value '$perm'."
        }
        $desiredRoleIds[$roleByValue[$perm]['id']] = $perm
    }

    $existingRoleIds = @{}
    foreach ($a in @($current.AppRoleAssignments)) {
        $rid = $a['appRoleId']
        $existingRoleIds[$rid] = $a
        if (-not $desiredRoleIds.ContainsKey($rid)) {
            $permName = if ($roleById.ContainsKey($rid)) { $roleById[$rid]['value'] } else { $rid }
            Invoke-Graph -Method DELETE -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$ConsumerSpId/appRoleAssignments/$($a['id'])" | Out-Null
            $actions.Add([PSCustomObject]@{ Action = 'REVOKED'; GrantType = 'AppRole'; Permission = $permName; Id = $a['id'] })
        }
    }

    foreach ($rid in $desiredRoleIds.Keys) {
        $permName = $desiredRoleIds[$rid]
        if ($existingRoleIds.ContainsKey($rid)) {
            $actions.Add([PSCustomObject]@{ Action = 'UNCHANGED'; GrantType = 'AppRole'; Permission = $permName; Id = $existingRoleIds[$rid]['id'] })
        } else {
            $body = @{
                principalId = $ConsumerSpId
                resourceId  = $ProducerSpId
                appRoleId   = $rid
            }
            $created = Invoke-Graph -Method POST -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$ConsumerSpId/appRoleAssignments" -Body $body
            $actions.Add([PSCustomObject]@{ Action = 'GRANTED'; GrantType = 'AppRole'; Permission = $permName; Id = $created['id'] })
        }
    }

    return @($actions)
}

function Sync-ConsumerApiScopeGrants {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ConsumerSpId,

        [Parameter(Mandatory = $true)]
        [string]$ProducerSpId,

        [Parameter(Mandatory = $true)]
        [array]$ProducerScopes,

        [Parameter(Mandatory = $false)]
        [string[]]$DesiredPermissions = @(),

        [Parameter(Mandatory = $false)]
        [string]$ScopeSuffix = ''
    )

    $actions = New-Object System.Collections.Generic.List[PSCustomObject]
    $current = Get-ConsumerGrantsForProducer -ConsumerSpId $ConsumerSpId -ProducerSpId $ProducerSpId

    $publishedScopeValues = @($ProducerScopes | ForEach-Object { $_['value'] })
    $desiredScopeNames = New-Object System.Collections.Generic.List[string]
    foreach ($perm in $DesiredPermissions) {
        $actualScope = "$perm$ScopeSuffix"
        if ($publishedScopeValues -notcontains $actualScope) {
            throw "Producer service principal '$ProducerSpId' does not publish an oauth2PermissionScope with value '$actualScope'."
        }
        $desiredScopeNames.Add($actualScope)
    }

    $existingGrant = $current.OAuth2PermissionGrant
    $existingScopes = @()
    if ($null -ne $existingGrant -and -not [string]::IsNullOrWhiteSpace([string]$existingGrant['scope'])) {
        $existingScopes = @(($existingGrant['scope'].Trim() -split '\s+') | Where-Object { $_ -ne '' })
    }

    $desiredSorted = @($desiredScopeNames | Sort-Object -Unique)
    $existingSorted = @($existingScopes | Sort-Object -Unique)

    foreach ($es in $existingSorted) {
        if ($desiredSorted -notcontains $es) {
            $actions.Add([PSCustomObject]@{ Action = 'REVOKED'; GrantType = 'ApiScope'; Permission = $es; Id = $existingGrant['id'] })
        }
    }
    foreach ($ds in $desiredSorted) {
        if ($existingSorted -contains $ds) {
            $actions.Add([PSCustomObject]@{ Action = 'UNCHANGED'; GrantType = 'ApiScope'; Permission = $ds; Id = $existingGrant['id'] })
        } else {
            $actions.Add([PSCustomObject]@{ Action = 'GRANTED'; GrantType = 'ApiScope'; Permission = $ds; Id = 'pending' })
        }
    }

    $desiredScopeStr = ($desiredSorted -join ' ')
    $existingScopeStr = ($existingSorted -join ' ')

    if ($desiredSorted.Count -eq 0) {
        if ($null -ne $existingGrant) {
            Invoke-Graph -Method DELETE -Uri "https://graph.microsoft.com/v1.0/oauth2PermissionGrants/$($existingGrant['id'])" | Out-Null
        }
    } elseif ($null -eq $existingGrant) {
        $body = @{
            clientId    = $ConsumerSpId
            consentType = 'AllPrincipals'
            resourceId  = $ProducerSpId
            scope       = $desiredScopeStr
        }
        $created = Invoke-Graph -Method POST -Uri 'https://graph.microsoft.com/v1.0/oauth2PermissionGrants' -Body $body
        foreach ($act in $actions) { if ($act.Id -eq 'pending') { $act.Id = $created['id'] } }
    } elseif ($desiredScopeStr -ne $existingScopeStr) {
        $body = @{ scope = $desiredScopeStr }
        Invoke-Graph -Method PATCH -Uri "https://graph.microsoft.com/v1.0/oauth2PermissionGrants/$($existingGrant['id'])" -Body $body | Out-Null
        foreach ($act in $actions) { if ($act.Id -eq 'pending') { $act.Id = $existingGrant['id'] } }
    }

    return @($actions)
}

function Add-AppClientSecret {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$AppObjectId,

        [string]$DisplayName = 'ProtoTestSecret'
    )

    $body = @{
        passwordCredential = @{
            displayName = $DisplayName
            endDateTime = (Get-Date).ToUniversalTime().AddDays(7).ToString('o')
        }
    }
    $res = Invoke-Graph -Method POST -Uri "https://graph.microsoft.com/v1.0/applications/$AppObjectId/addPassword" -Body $body
    return $res['secretText']
}

function Get-ClientCredentialsTokenClaims {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TenantId,

        [Parameter(Mandatory = $true)]
        [string]$ClientId,

        [Parameter(Mandatory = $true)]
        [string]$ClientSecret,

        [Parameter(Mandatory = $true)]
        [string]$ProducerAppId
    )

    $tokenUrl = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
    $form = @{
        client_id     = $ClientId
        client_secret = $ClientSecret
        scope         = "api://$ProducerAppId/.default"
        grant_type    = 'client_credentials'
    }

    $resp = Invoke-RestMethod -Method POST -Uri $tokenUrl -Body $form -ContentType 'application/x-www-form-urlencoded'
    return (Decode-JwtPayload -Jwt $resp.access_token)
}

Export-ModuleMember -Function @(
    'Connect-GovernanceGraph',
    'Invoke-Graph',
    'Initialize-AttributeAdminRoles',
    'Initialize-AppToAppAccessSchema',
    'Resolve-EntraApp',
    'Publish-ProducerPermissions',
    'Get-ProducerSpDetails',
    'Set-ProducerSpMetadata',
    'Clear-ProducerSpMetadata',
    'Get-ConsumerGrantsForProducer',
    'Sync-ConsumerAppRoleGrants',
    'Sync-ConsumerApiScopeGrants',
    'Add-AppClientSecret',
    'Get-ClientCredentialsTokenClaims'
)
