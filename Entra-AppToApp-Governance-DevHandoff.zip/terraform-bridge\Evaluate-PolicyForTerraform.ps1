#Requires -Version 5.1
<#
.SYNOPSIS
    Terraform `data "external"` adapter for Unity Deploy.
.DESCRIPTION
    Reads a JSON object from stdin (as required by HashiCorp Terraform's `external` data source):
      {
        "consumer_identity": "APP12540_portal_client-web",
        "consumer_app_type": "WebApp",
        "producer_sp_id": "<guid>",
        "permission": "documents.read"
      }
    Queries live Producer AppToAppAccess Custom Security Attributes via Microsoft Graph,
    evaluates the RFC's 4-step decision order using AppToAppGovernance.psm1, and outputs a flat
    string-map JSON object to stdout for Terraform `lifecycle { precondition }` enforcement.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $root 'modules\AppToAppGovernance.psm1') -Force
Import-Module (Join-Path $root 'modules\EntraGraphClient.psm1') -Force

# Read stdin JSON passed by Terraform data "external"
$stdinText = [Console]::In.ReadToEnd()
$query = $stdinText | ConvertFrom-Json

Connect-GovernanceGraph | Out-Null
$sp = Get-ProducerSpDetails -ServicePrincipalId $query.producer_sp_id

$decision = Invoke-GovernanceDecision `
    -ConsumerIdentity $query.consumer_identity `
    -ConsumerAppType $query.consumer_app_type `
    -ProducerDisplayName $sp.DisplayName `
    -ProducerAppId $sp.AppId `
    -Permission $query.permission `
    -ProducerAttributes $sp.AppToAppAccess

# Terraform external data source requires all output values to be strings
$result = [ordered]@{
    decision         = [string]$decision.Decision
    grant_type       = [string]$decision.GrantType
    tier             = [string]$decision.Tier
    deciding_step    = [string]$decision.DecidingStep
    deciding_rule    = [string]$decision.DecidingRule
    reason           = [string]$decision.Reason
    contact_guidance = [string]$decision.ContactGuidance
    evaluated_utc    = [string]$decision.TimestampUtc
}

$result | ConvertTo-Json -Compress
