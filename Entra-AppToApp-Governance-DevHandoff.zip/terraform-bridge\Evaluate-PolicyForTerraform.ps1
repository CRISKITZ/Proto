#Requires -Version 5.1
<#
.SYNOPSIS
    Terraform `data "external"` adapter for Unity Deploy.
.DESCRIPTION
    Reads a JSON object from stdin (as required by HashiCorp Terraform's `external` data source):
      {
        "consumer_identity": "APP12540_portal_client-web",
        "consumer_app_type": "WebApp",
        "consumer_sp_id": "<guid>",
        "producer_sp_id": "<guid>",
        "permission": "documents.read"
      }
    Runs fail-closed preflight verification, enforces tenant ownership + single-tenant checks on both
    consumer and producer SPs, binds consumer_identity to the consumer SP, evaluates the RFC's 4-step
    decision order using AppToAppGovernance.psm1, and outputs a flat string-map JSON object to stdout.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $root 'modules\AppToAppGovernance.psm1') -Force
Import-Module (Join-Path $root 'modules\EntraGraphClient.psm1') -Force

# Read stdin JSON passed by Terraform data "external"
$stdinText = [Console]::In.ReadToEnd()
$query = $stdinText | ConvertFrom-Json

Connect-GovernanceGraph | Out-Null
Assert-AttributeReadAccess | Out-Null

# Enforce tenant-ownership, single-tenant, and identity binding on Consumer SP
if ($query.PSObject.Properties['consumer_sp_id'] -and -not [string]::IsNullOrWhiteSpace([string]$query.consumer_sp_id)) {
    $consumerSp = Get-ConsumerSpDetails -ServicePrincipalId ([string]$query.consumer_sp_id)
    $cid = [string]$query.consumer_identity
    $idParts = $cid.Split('_')
    if ($idParts.Count -eq 3) {
        $appIdPart = $idParts[0]
        $projPart  = $idParts[1]
        $compPart  = $idParts[2]
        # Accept either real Unity format (<project>-<component>-<env>-<APPID>) or prototype fixture format (.*-<APPID>_<project>_<component>)
        $unityPattern = '^' + [regex]::Escape("$projPart-$compPart-") + '[a-z0-9\-]+-' + [regex]::Escape($appIdPart) + '$'
        $matchesUnityName = ([string]$consumerSp.DisplayName -cmatch $unityPattern)
        $matchesProtoName = ([string]$consumerSp.DisplayName).EndsWith("-$cid", [System.StringComparison]::Ordinal)
        if (-not ($matchesUnityName -or $matchesProtoName)) {
            throw "consumer_identity '$cid' does not match consumer service principal '$($consumerSp.DisplayName)' ($($consumerSp.ServicePrincipalId))."
        }
    }
}

$sp = Get-ProducerSpDetails -ServicePrincipalId $query.producer_sp_id

$decision = Invoke-GovernanceDecision `
    -ConsumerIdentity $query.consumer_identity `
    -ConsumerAppType $query.consumer_app_type `
    -ProducerDisplayName $sp.DisplayName `
    -ProducerAppId $sp.AppId `
    -Permission $query.permission `
    -ProducerAttributes $sp.AppToAppAccess

# Terraform external data source requires all output values to be strings
$result = [ordered]@{
    decision         = [string]$decision.Decision
    grant_type       = [string]$decision.GrantType
    tier             = [string]$decision.Tier
    deciding_step    = [string]$decision.DecidingStep
    deciding_rule    = [string]$decision.DecidingRule
    reason           = [string]$decision.Reason
    contact_guidance = [string]$decision.ContactGuidance
    evaluated_utc    = [string]$decision.TimestampUtc
}

$result | ConvertTo-Json -Compress
